package com.maniplus.notcoin;

import android.app.Application;
import android.content.Context;

import com.adivery.sdk.Adivery;
import com.adivery.sdk.AdiveryAdListener;
import com.adivery.sdk.AdiveryBannerAdView;
import com.adivery.sdk.BannerSize;

public final class AdiveryManager {
    public static final String APP_ID = "1ed3d9f1-ccaf-40a7-808f-aaee6ccd422f";
    public static final String BANNER_ZONE_ID = "4fb16d31-bfcd-4c85-9a0f-f787d8fc34f4";
    public static final String INTERSTITIAL_ZONE_ID = "d027cb9f-ad5b-410e-a716-287fd8ec61e1";

    private static boolean initialized;
    private static boolean interstitialAttemptedThisProcess;

    private AdiveryManager() { }

    public static synchronized void initialize(Context context) {
        if (initialized) return;
        Context appContext = context.getApplicationContext();
        if (appContext instanceof Application) {
            Adivery.configure((Application) appContext, APP_ID);
            initialized = true;
        }
    }

    public static void prepareInterstitial(Context context) {
        initialize(context);
        Adivery.prepareInterstitialAd(context, INTERSTITIAL_ZONE_ID);
    }

    public static synchronized boolean tryShowInterstitialOnce(Context context) {
        if (interstitialAttemptedThisProcess) return true;
        initialize(context);
        if (!Adivery.isLoaded(INTERSTITIAL_ZONE_ID)) {
            Adivery.prepareInterstitialAd(context, INTERSTITIAL_ZONE_ID);
            return false;
        }
        interstitialAttemptedThisProcess = true;
        Adivery.showAd(INTERSTITIAL_ZONE_ID);
        return true;
    }

    public static AdiveryBannerAdView createBanner(Context context, BannerSize size, AdiveryAdListener listener) {
        initialize(context);
        AdiveryBannerAdView banner = new AdiveryBannerAdView(context);
        if (listener != null) banner.setBannerAdListener(listener);
        banner.setPlacementId(BANNER_ZONE_ID);
        banner.setBannerSize(size);
        return banner;
    }
}
