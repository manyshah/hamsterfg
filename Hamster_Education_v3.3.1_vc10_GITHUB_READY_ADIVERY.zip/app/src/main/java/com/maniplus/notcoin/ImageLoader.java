package com.maniplus.notcoin;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ImageLoader {
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final File diskDir;
    private final LruCache<String, Bitmap> memory = new LruCache<String, Bitmap>(20 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getByteCount(); }
    };

    public ImageLoader(Context context) {
        diskDir = new File(context.getCacheDir(), "hamster_images");
        if (!diskDir.exists()) diskDir.mkdirs();
    }

    public void load(ImageView target, String url) {
        if (url == null || url.trim().isEmpty()) return;
        final String key = url.trim();
        target.setTag(key);
        Bitmap cached = memory.get(key);
        if (cached != null) {
            target.setImageBitmap(cached);
            return;
        }
        pool.execute(() -> {
            Bitmap bitmap = readDisk(key);
            if (bitmap == null) bitmap = download(key);
            if (bitmap == null) return;
            memory.put(key, bitmap);
            Bitmap finalBitmap = bitmap;
            main.post(() -> {
                Object tag = target.getTag();
                if (tag != null && key.equals(tag.toString())) target.setImageBitmap(finalBitmap);
            });
        });
    }

    private Bitmap readDisk(String url) {
        try {
            File f = new File(diskDir, sha256(url) + ".img");
            if (!f.isFile() || f.length() <= 0) return null;
            return BitmapFactory.decodeFile(f.getAbsolutePath());
        } catch (Exception ignored) { return null; }
    }

    private Bitmap download(String url) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(10_000);
            c.setReadTimeout(15_000);
            c.setDoInput(true);
            c.setUseCaches(true);
            c.connect();
            if (c.getResponseCode() < 200 || c.getResponseCode() >= 300) return null;
            byte[] bytes;
            try (InputStream in = c.getInputStream()) {
                bytes = readAll(in);
            }
            Bitmap b = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            if (b != null) {
                try (FileOutputStream out = new FileOutputStream(new File(diskDir, sha256(url) + ".img"))) {
                    out.write(bytes);
                } catch (Exception ignored) { }
            }
            return b;
        } catch (Exception ignored) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        return out.toByteArray();
    }

    private static String sha256(String s) throws Exception {
        MessageDigest d = MessageDigest.getInstance("SHA-256");
        byte[] h = d.digest(s.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte b : h) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
