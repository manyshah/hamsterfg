package com.maniplus.notcoin;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import java.util.UUID;

public final class UsageTracker {
    private final ApiClient api;
    private final SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running;
    private final Runnable beat = new Runnable() {
        @Override public void run() {
            if (!running) return;
            send(false);
            handler.postDelayed(this, 60_000L);
        }
    };

    public UsageTracker(Context context, ApiClient api) {
        this.api = api;
        prefs = context.getSharedPreferences("hamster_education_device", Context.MODE_PRIVATE);
        if (prefs.getString("device_id", "").isEmpty()) {
            prefs.edit().putString("device_id", UUID.randomUUID().toString()).apply();
        }
    }

    public String deviceId() { return prefs.getString("device_id", ""); }

    public void start() {
        if (running) return;
        running = true;
        send(true);
        handler.removeCallbacks(beat);
        handler.postDelayed(beat, 60_000L);
    }

    public void stop() {
        running = false;
        handler.removeCallbacks(beat);
    }

    private void send(boolean sessionStart) {
        JSONObject b = new JSONObject();
        try {
            b.put("deviceId", deviceId());
            b.put("appVersion", BuildConfig.VERSION_NAME);
            b.put("versionCode", BuildConfig.VERSION_CODE);
            b.put("sessionStart", sessionStart);
        } catch (Exception ignored) { }
        api.post("app.php?action=heartbeat", b, null, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) { }
            @Override public void fail(String message) { }
        });
    }
}
