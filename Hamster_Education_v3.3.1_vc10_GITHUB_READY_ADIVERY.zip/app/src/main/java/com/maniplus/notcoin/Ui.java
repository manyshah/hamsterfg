package com.maniplus.notcoin;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    public static final int BG = Color.rgb(247, 248, 253);
    public static final int SURFACE = Color.WHITE;
    public static final int SURFACE_SOFT = Color.rgb(243, 245, 252);
    public static final int TEXT = Color.rgb(27, 31, 45);
    public static final int MUTED = Color.rgb(112, 119, 142);
    public static final int MUTED2 = Color.rgb(148, 154, 174);
    public static final int PRIMARY = Color.rgb(80, 73, 224);
    public static final int PRIMARY_DARK = Color.rgb(53, 48, 185);
    public static final int PURPLE = Color.rgb(123, 77, 236);
    public static final int BLUE = Color.rgb(65, 119, 230);
    public static final int GREEN = Color.rgb(28, 167, 119);
    public static final int RED = Color.rgb(225, 73, 94);
    public static final int ORANGE = Color.rgb(235, 145, 55);
    public static final int LINE = Color.rgb(229, 232, 242);

    private Ui() {}

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static LinearLayout vertical(Context c) {
        LinearLayout v = new LinearLayout(c);
        v.setOrientation(LinearLayout.VERTICAL);
        if (Build.VERSION.SDK_INT >= 17) v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return v;
    }

    public static LinearLayout horizontal(Context c) {
        LinearLayout v = new LinearLayout(c);
        v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL);
        if (Build.VERSION.SDK_INT >= 17) v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return v;
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s == null ? "" : s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setLineSpacing(0, 1.28f);
        if (Build.VERSION.SDK_INT >= 21) t.setLetterSpacing(0f);
        return t;
    }

    public static TextView title(Context c, String s) { return text(c, s, 22, TEXT, true); }

    public static GradientDrawable bg(int color, float radius, int strokeColor, int strokeDp, Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radius));
        if (strokeDp > 0) d.setStroke(dp(c, strokeDp), strokeColor);
        return d;
    }

    public static GradientDrawable gradient(int c1, int c2, float radius, int strokeColor, int strokeDp, Context c) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        d.setCornerRadius(dp(c, radius));
        if (strokeDp > 0) d.setStroke(dp(c, strokeDp), strokeColor);
        return d;
    }

    public static LinearLayout card(Context c) {
        LinearLayout v = vertical(c);
        v.setPadding(dp(c, 14), dp(c, 14), dp(c, 14), dp(c, 14));
        v.setBackground(bg(SURFACE, 20, LINE, 1, c));
        if (Build.VERSION.SDK_INT >= 21) v.setElevation(dp(c, 1.5f));
        return v;
    }

    public static LinearLayout softCard(Context c) {
        LinearLayout v = vertical(c);
        v.setPadding(dp(c, 13), dp(c, 13), dp(c, 13), dp(c, 13));
        v.setBackground(bg(SURFACE_SOFT, 18, LINE, 1, c));
        return v;
    }

    public static LinearLayout heroCard(Context c) {
        LinearLayout v = vertical(c);
        v.setPadding(dp(c, 18), dp(c, 18), dp(c, 18), dp(c, 18));
        v.setBackground(gradient(Color.rgb(74,68,219), Color.rgb(112,73,229), 26, Color.TRANSPARENT, 0, c));
        return v;
    }

    public static Button button(Context c, String s, boolean primary) {
        Button b = new Button(c);
        b.setText(s);
        b.setTextSize(12.5f);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(c, 44));
        b.setPadding(dp(c, 14), 0, dp(c, 14), 0);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        if (Build.VERSION.SDK_INT >= 21) { b.setStateListAnimator(null); b.setElevation(0); }
        if (primary) {
            b.setTextColor(Color.WHITE);
            b.setBackground(gradient(PRIMARY, PURPLE, 14, Color.TRANSPARENT, 0, c));
        } else {
            b.setTextColor(PRIMARY_DARK);
            b.setBackground(bg(Color.WHITE, 14, LINE, 1, c));
        }
        return b;
    }

    public static TextView pill(Context c, String text, int fg, int bgColor) {
        TextView t = text(c, text, 10.5f, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 10), dp(c, 5), dp(c, 10), dp(c, 5));
        t.setBackground(bg(bgColor, 99, Color.TRANSPARENT, 0, c));
        return t;
    }

    public static LinearLayout.LayoutParams lpMatchWrap(Context c, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(c, top), 0, dp(c, bottom));
        return p;
    }

    public static LinearLayout.LayoutParams lpWeight(float w) {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w);
    }

    public static void gap(LinearLayout parent, Context c, int dp) {
        View g = new View(c);
        parent.addView(g, new LinearLayout.LayoutParams(dp(c, dp), dp(c, dp)));
    }
}
