package com.maniplus.notcoin;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import com.adivery.sdk.AdiveryAdListener;
import com.adivery.sdk.AdiveryBannerAdView;
import com.adivery.sdk.BannerSize;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class TutorialsController {
    private static final String TAB_HOME = "home";
    private static final String TAB_FAVORITES = "favorites";
    private static final String TAB_NEWS = "news";
    private static final int NEWS_PAGE_SIZE = 10;

    private final MainActivity activity;
    private final ApiClient api;
    private final ImageLoader images;
    private final SharedPreferences prefs;
    private final String deviceId;
    private final Runnable initialSettled;
    private final FrameLayout content;
    private final LinearLayout root;
    private final LinearLayout bottomNav;

    private JSONArray categories = new JSONArray();
    private JSONArray tutorials = new JSONArray();
    private JSONArray sliders = new JSONArray();
    private JSONArray news = new JSONArray();
    private JSONObject uiImages = new JSONObject();
    private final Map<String, JSONObject> tutorialIndex = new HashMap<>();
    private final Map<String, JSONObject> categoryIndex = new HashMap<>();
    private final Map<String, JSONObject> newsIndex = new HashMap<>();
    private Set<String> favorites = new HashSet<>();

    private String activeTab = TAB_HOME;
    private boolean subPageOpen;
    private Runnable subpageRenderer;
    private boolean replacingSubPage;
    private final List<PageState> pageStack = new ArrayList<>();
    private boolean initialCallbackSent;

    private static final class PageState {
        final View view;
        final Runnable renderer;
        PageState(View view, Runnable renderer) {
            this.view = view;
            this.renderer = renderer;
        }
    }
    private long lastLoadedAt;
    private String contentVersion = "";

    private boolean newsLoading;
    private boolean newsHasMore = true;
    private int newsTotal = -1;
    private LinearLayout newsListHost;
    private LinearLayout newsFooterHost;
    private PullRefreshLayout newsPull;

    public TutorialsController(MainActivity activity, ApiClient api, ImageLoader images, String deviceId, Runnable initialSettled) {
        this.activity = activity;
        this.api = api;
        this.images = images;
        this.deviceId = deviceId == null ? "" : deviceId;
        this.initialSettled = initialSettled;
        this.prefs = activity.getSharedPreferences("hamster_education_v35", Context.MODE_PRIVATE);
        this.favorites = new HashSet<>(prefs.getStringSet("favorites", new HashSet<>()));
        loadCaches();
        indexData();

        root = Ui.vertical(activity);
        root.setBackgroundColor(Ui.BG);
        content = new FrameLayout(activity);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        bottomNav = Ui.horizontal(activity);
        root.addView(bottomNav, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 70)));
        rebuildBottomNav();

        if (hasBootstrapCache()) {
            showTab(TAB_HOME);
            settleInitial();
            checkForUpdates();
        } else {
            showInitialLoading();
            syncAll(true, true, null);
        }
    }

    public View view() { return root; }

    public void refreshIfNeeded() {
        if (SystemClock.elapsedRealtime() - lastLoadedAt > 60_000L) checkForUpdates();
    }

    public boolean goBack() {
        if (!pageStack.isEmpty()) {
            PageState previous = pageStack.remove(pageStack.size() - 1);
            content.removeAllViews();
            ViewGroup parent = (ViewGroup) previous.view.getParent();
            if (parent != null) parent.removeView(previous.view);
            content.addView(previous.view);
            subpageRenderer = previous.renderer;
            subPageOpen = previous.renderer != null || !pageStack.isEmpty();
            return true;
        }
        if (!TAB_HOME.equals(activeTab)) {
            showTab(TAB_HOME);
            return true;
        }
        return false;
    }

    private void beginSubPage(Runnable renderer) {
        if (!replacingSubPage && content.getChildCount() > 0) {
            View current = content.getChildAt(0);
            content.removeView(current);
            pageStack.add(new PageState(current, subpageRenderer));
        } else {
            content.removeAllViews();
        }
        subPageOpen = true;
        subpageRenderer = renderer;
    }

    private void replaceCurrentSubPage(Runnable action) {
        boolean old = replacingSubPage;
        replacingSubPage = true;
        try { action.run(); } finally { replacingSubPage = old; }
    }

    private boolean hasBootstrapCache() {
        return prefs.getBoolean("bootstrap_ok", false);
    }

    private void settleInitial() {
        if (initialCallbackSent) return;
        initialCallbackSent = true;
        if (initialSettled != null) initialSettled.run();
    }

    private void loadCaches() {
        try {
            String c = prefs.getString("categories_cache", "");
            String t = prefs.getString("tutorials_cache", "");
            String s = prefs.getString("sliders_cache", "");
            String n = prefs.getString("news_cache", "");
            String u = prefs.getString("ui_images_cache", "");
            if (!c.isEmpty()) categories = new JSONArray(c);
            if (!t.isEmpty()) tutorials = new JSONArray(t);
            if (!s.isEmpty()) sliders = new JSONArray(s);
            if (!n.isEmpty()) news = new JSONArray(n);
            if (!u.isEmpty()) uiImages = new JSONObject(u);
            contentVersion = prefs.getString("content_version", "");
            newsTotal = prefs.getInt("news_total", news.length());
            newsHasMore = prefs.getBoolean("news_has_more", news.length() < newsTotal);
        } catch (Exception ignored) { }
    }

    private void saveCaches() {
        prefs.edit()
                .putString("categories_cache", categories.toString())
                .putString("tutorials_cache", tutorials.toString())
                .putString("sliders_cache", sliders.toString())
                .putString("news_cache", news.toString())
                .putString("ui_images_cache", uiImages.toString())
                .putString("content_version", contentVersion)
                .putInt("news_total", newsTotal)
                .putBoolean("news_has_more", newsHasMore)
                .putBoolean("bootstrap_ok", true)
                .apply();
    }

    private void indexData() {
        tutorialIndex.clear();
        categoryIndex.clear();
        newsIndex.clear();
        for (int i = 0; i < tutorials.length(); i++) {
            JSONObject x = tutorials.optJSONObject(i);
            if (x != null) tutorialIndex.put(x.optString("id"), x);
        }
        for (int i = 0; i < categories.length(); i++) {
            JSONObject x = categories.optJSONObject(i);
            if (x != null) categoryIndex.put(x.optString("id"), x);
        }
        for (int i = 0; i < news.length(); i++) {
            JSONObject x = news.optJSONObject(i);
            if (x != null) newsIndex.put(x.optString("id"), x);
        }
    }

    private void rebuildBottomNav() {
        bottomNav.removeAllViews();
        bottomNav.setGravity(Gravity.CENTER);
        bottomNav.setPadding(Ui.dp(activity, 8), Ui.dp(activity, 7), Ui.dp(activity, 8), Ui.dp(activity, 7));
        bottomNav.setBackground(Ui.bg(Color.WHITE, 0, Ui.LINE, 1, activity));
        bottomNav.addView(navButton("navHome", "⌂", "خانه", TAB_HOME), Ui.lpWeight(1));
        bottomNav.addView(navButton("navFavorites", "♡", "علاقه‌مندی", TAB_FAVORITES), Ui.lpWeight(1));
        bottomNav.addView(navButton("navNews", "▤", "اخبار آنلاین", TAB_NEWS), Ui.lpWeight(1));
        updateBottomNav();
    }

    private View navButton(String imageKey, String fallback, String label, String tab) {
        LinearLayout b = Ui.vertical(activity);
        b.setGravity(Gravity.CENTER);
        View icon = interfaceIcon(imageKey, fallback, 27);
        icon.setTag("nav_icon");
        b.addView(icon, new LinearLayout.LayoutParams(Ui.dp(activity, 30), Ui.dp(activity, 30)));
        TextView t = Ui.text(activity, label, 10.5f, Ui.MUTED, true);
        t.setGravity(Gravity.CENTER);
        t.setTag("label");
        b.addView(t);
        b.setTag(tab);
        b.setOnClickListener(v -> showTab(tab));
        return b;
    }

    private View interfaceIcon(String key, String fallback, int sizeDp) {
        String url = ApiClient.absolute(uiImages.optString(key));
        if (!url.isEmpty()) {
            ImageView iv = new ImageView(activity);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            images.load(iv, url);
            return iv;
        }
        TextView tv = Ui.text(activity, fallback, sizeDp * .8f, Ui.PRIMARY, true);
        tv.setGravity(Gravity.CENTER);
        return tv;
    }

    private void updateBottomNav() {
        if (bottomNav == null) return;
        for (int i = 0; i < bottomNav.getChildCount(); i++) {
            View v = bottomNav.getChildAt(i);
            if (!(v instanceof LinearLayout)) continue;
            boolean selected = activeTab.equals(v.getTag());
            LinearLayout l = (LinearLayout) v;
            for (int j = 0; j < l.getChildCount(); j++) {
                View child = l.getChildAt(j);
                if (child instanceof TextView && "label".equals(child.getTag())) {
                    ((TextView) child).setTextColor(selected ? Ui.PRIMARY : Ui.MUTED);
                }
            }
            l.setAlpha(selected ? 1f : .82f);
        }
    }

    private void showTab(String tab) {
        activeTab = tab;
        subPageOpen = false;
        subpageRenderer = null;
        pageStack.clear();
        updateBottomNav();
        content.removeAllViews();
        if (TAB_FAVORITES.equals(tab)) content.addView(buildFavoritesPage());
        else if (TAB_NEWS.equals(tab)) content.addView(buildNewsPage());
        else content.addView(buildHomePage());
    }

    private void showInitialLoading() {
        content.removeAllViews();
        LinearLayout page = Ui.vertical(activity);
        page.setGravity(Gravity.CENTER);
        ProgressBar p = new ProgressBar(activity);
        page.addView(p, new LinearLayout.LayoutParams(Ui.dp(activity, 44), Ui.dp(activity, 44)));
        TextView t = Ui.text(activity, "در حال دریافت اطلاعات اولیه…", 13, Ui.TEXT, true);
        t.setGravity(Gravity.CENTER);
        page.addView(t, margin(16, 0));
        content.addView(page);
    }

    private void showInitialOffline() {
        content.removeAllViews();
        PullRefreshLayout pull = new PullRefreshLayout(activity);
        LinearLayout page = Ui.vertical(activity);
        page.setGravity(Gravity.CENTER);
        page.setPadding(Ui.dp(activity, 26), Ui.dp(activity, 36), Ui.dp(activity, 26), Ui.dp(activity, 36));
        TextView icon = Ui.text(activity, "◌", 50, Ui.PRIMARY, true);
        icon.setGravity(Gravity.CENTER);
        page.addView(icon);
        TextView title = Ui.text(activity, "برای دریافت اطلاعات اولیه، اینترنت را فعال کنید", 17, Ui.TEXT, true);
        title.setGravity(Gravity.CENTER);
        page.addView(title, margin(14, 7));
        TextView sub = Ui.text(activity, "بعد از اتصال، صفحه را به پایین بکشید تا دوباره تلاش شود.", 11.5f, Ui.MUTED, false);
        sub.setGravity(Gravity.CENTER);
        page.addView(sub);
        pull.setContent(page);
        pull.setOnRefreshListener(() -> syncAll(true, true, pull));
        content.addView(pull);
    }

    private View buildHomePage() {
        LinearLayout page = pageBody();
        page.addView(buildTopBar("آموزش همستر", true));
        View slider = buildSlider();
        if (slider != null) page.addView(slider, margin(12, 8));
        page.addView(sectionHeader("دسته‌بندی‌ها", "مشاهده همه", v -> openAllCategories()), margin(18, 6));
        page.addView(buildHomeCategories());
        page.addView(sectionHeader("آموزش‌های محبوب", "مشاهده همه", v -> openPopular()), margin(20, 8));
        LinearLayout popular = Ui.vertical(activity);
        for (JSONObject t : popularTutorials(5)) popular.addView(tutorialRow(t), margin(0, 10));
        if (popular.getChildCount() == 0) popular.addView(emptyState("هنوز آموزشی منتشر نشده است."));
        page.addView(popular);
        page.addView(space(24));
        return wrapPull(page, pull -> syncAll(true, false, pull), null);
    }

    private LinearLayout buildTopBar(String title, boolean search) {
        LinearLayout bar = Ui.horizontal(activity);
        bar.setPadding(Ui.dp(activity, 4), Ui.dp(activity, 10), Ui.dp(activity, 4), Ui.dp(activity, 5));
        TextView titleView = Ui.text(activity, title, 22, Ui.TEXT, true);
        bar.addView(titleView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (search) {
            FrameLayout action = circleImageAction("search", "⌕");
            action.setOnClickListener(v -> openSearch());
            bar.addView(action, new LinearLayout.LayoutParams(Ui.dp(activity, 46), Ui.dp(activity, 46)));
        }
        return bar;
    }

    private FrameLayout circleImageAction(String imageKey, String fallback) {
        FrameLayout f = new FrameLayout(activity);
        f.setBackground(Ui.bg(Color.WHITE, 99, Ui.LINE, 1, activity));
        if (Build.VERSION.SDK_INT >= 21) f.setElevation(Ui.dp(activity, 1));
        View v = interfaceIcon(imageKey, fallback, 25);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(Ui.dp(activity, 25), Ui.dp(activity, 25));
        p.gravity = Gravity.CENTER;
        f.addView(v, p);
        return f;
    }

    private View buildSlider() {
        List<JSONObject> active = new ArrayList<>();
        boolean hasAdiverySlide = false;
        for (int i = 0; i < sliders.length(); i++) {
            JSONObject s = sliders.optJSONObject(i);
            if (s == null || !s.optBoolean("active", true) || s.optBoolean("deleted", false)) continue;
            boolean adivery = "adivery".equals(s.optString("kind", "normal"));
            if (!adivery && s.optString("image").trim().isEmpty()) continue;
            active.add(s);
            if (adivery) hasAdiverySlide = true;
        }
        if (active.isEmpty()) return null;

        final boolean adLayout = hasAdiverySlide;
        final int cardWidth = activity.getResources().getDisplayMetrics().widthPixels - Ui.dp(activity, 28);
        final int cardHeight = Ui.dp(activity, adLayout ? 250 : 118);
        final int gap = Ui.dp(activity, 9);
        HorizontalScrollView hsv = new HorizontalScrollView(activity);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setFillViewport(false);
        if (Build.VERSION.SDK_INT >= 17) hsv.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout row = new LinearLayout(activity);
        row.setOrientation(LinearLayout.HORIZONTAL);
        if (Build.VERSION.SDK_INT >= 17) row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        Map<Integer, AdiveryBannerAdView> adBanners = new HashMap<>();
        Set<Integer> loadedAdPages = new HashSet<>();
        for (int i = 0; i < active.size(); i++) {
            final int pageIndex = i;
            JSONObject slide = active.get(i);
            FrameLayout card = new FrameLayout(activity);
            card.setBackground(Ui.bg(Color.rgb(232, 234, 244), 22, Color.TRANSPARENT, 0, activity));
            if (Build.VERSION.SDK_INT >= 21) card.setClipToOutline(true);

            if ("adivery".equals(slide.optString("kind", "normal"))) {
                TextView placeholder = Ui.text(activity, "تبلیغ", 11, Ui.MUTED, true);
                placeholder.setGravity(Gravity.CENTER);
                card.addView(placeholder, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                AdiveryBannerAdView banner = AdiveryManager.createBanner(activity, BannerSize.MEDIUM_RECTANGLE, new AdiveryAdListener() {
                    @Override public void onAdShown() { trackSliderEvent(slide.optString("id"), "impression"); }
                    @Override public void onAdClicked() { trackSliderEvent(slide.optString("id"), "click"); }
                });
                adBanners.put(pageIndex, banner);
                FrameLayout.LayoutParams adp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                adp.gravity = Gravity.CENTER;
                card.addView(banner, adp);
            } else {
                ImageView iv = new ImageView(activity);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                images.load(iv, ApiClient.absolute(slide.optString("image")));
                card.addView(iv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                card.setOnClickListener(v -> {
                    trackSliderEvent(slide.optString("id"), "click");
                    followTarget(slide);
                });
            }

            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(cardWidth, cardHeight);
            if (i < active.size() - 1) cp.rightMargin = gap;
            row.addView(card, cp);
        }
        hsv.addView(row, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, cardHeight));

        LinearLayout dots = Ui.horizontal(activity);
        dots.setGravity(Gravity.CENTER);
        if (Build.VERSION.SDK_INT >= 17) dots.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        List<TextView> dotViews = new ArrayList<>();
        for (int i = 0; i < active.size(); i++) {
            TextView d = Ui.text(activity, "●", 10, adLayout ? Ui.PRIMARY : Color.WHITE, true);
            d.setGravity(Gravity.CENTER);
            d.setAlpha(i == 0 ? 1f : .48f);
            dotViews.add(d);
            dots.addView(d, new LinearLayout.LayoutParams(Ui.dp(activity, 15), Ui.dp(activity, 20)));
        }

        View sliderRoot;
        if (adLayout) {
            LinearLayout outer = Ui.vertical(activity);
            outer.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, cardHeight));
            outer.addView(dots, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 24)));
            sliderRoot = outer;
        } else {
            FrameLayout frame = new FrameLayout(activity);
            frame.addView(hsv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, cardHeight));
            FrameLayout.LayoutParams dp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(activity, 24));
            dp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            dp.bottomMargin = Ui.dp(activity, 4);
            frame.addView(dots, dp);
            sliderRoot = frame;
        }

        final int[] currentPage = {-1};
        sliderRoot.post(() -> activateSliderPage(active, adBanners, loadedAdPages, currentPage, 0));
        hsv.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                int page = Math.max(0, Math.min(active.size() - 1, Math.round((float) hsv.getScrollX() / (cardWidth + gap))));
                hsv.smoothScrollTo(page * (cardWidth + gap), 0);
                updateDots(dotViews, page);
                activateSliderPage(active, adBanners, loadedAdPages, currentPage, page);
            }
            return false;
        });
        if (Build.VERSION.SDK_INT >= 23) {
            hsv.setOnScrollChangeListener((v, sx, sy, ox, oy) -> {
                int page = Math.max(0, Math.min(active.size() - 1, Math.round((float) sx / (cardWidth + gap))));
                updateDots(dotViews, page);
            });
        }
        return sliderRoot;
    }

    private void activateSliderPage(List<JSONObject> active, Map<Integer, AdiveryBannerAdView> adBanners, Set<Integer> loadedAdPages, int[] currentPage, int page) {
        if (page < 0 || page >= active.size() || currentPage[0] == page) return;
        currentPage[0] = page;
        JSONObject slide = active.get(page);
        if ("adivery".equals(slide.optString("kind", "normal"))) {
            AdiveryBannerAdView banner = adBanners.get(page);
            if (banner != null && loadedAdPages.add(page)) banner.loadAd();
        } else {
            trackSliderEvent(slide.optString("id"), "impression");
        }
    }

    private void trackSliderEvent(String id, String event) {
        if (id == null || id.trim().isEmpty()) return;
        JSONObject body = new JSONObject();
        try {
            body.put("id", id);
            body.put("event", event);
            body.put("deviceId", deviceId);
        } catch (Exception ignored) { }
        api.post("app.php?action=slider_event", body, null, new ApiClient.Callback() {
            @Override public void ok(JSONObject j) { }
            @Override public void fail(String m) { }
        });
    }

    private void updateDots(List<TextView> dots, int current) {
        for (int i = 0; i < dots.size(); i++) dots.get(i).setAlpha(i == current ? 1f : .48f);
    }

    private View buildHomeCategories() {
        HorizontalScrollView hsv = new HorizontalScrollView(activity);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = Ui.horizontal(activity);
        row.setPadding(Ui.dp(activity, 8), 0, Ui.dp(activity, 8), 0);
        int added = 0;
        for (int i = 0; i < categories.length() && added < 4; i++) {
            JSONObject c = categories.optJSONObject(i);
            if (!isActiveRootCategory(c)) continue;
            row.addView(homeCategoryCard(c));
            added++;
        }
        if (added == 0) row.addView(emptyState("هنوز دسته‌بندی منتشر نشده است."));
        hsv.addView(row, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return hsv;
    }

    private boolean isActiveRootCategory(JSONObject c) {
        return c != null && c.optBoolean("active", true) && !c.optBoolean("deleted", false) && c.optString("parentId").isEmpty();
    }

    private View homeCategoryCard(JSONObject c) {
        LinearLayout card = Ui.vertical(activity);
        card.setGravity(Gravity.CENTER);
        card.setPadding(Ui.dp(activity, 9), Ui.dp(activity, 9), Ui.dp(activity, 9), Ui.dp(activity, 10));
        card.setBackground(Ui.bg(categoryTint(c.optString("id")), 19, Color.TRANSPARENT, 0, activity));
        View visual = categoryVisual(c, 58);
        card.addView(visual, new LinearLayout.LayoutParams(Ui.dp(activity, 62), Ui.dp(activity, 62)));
        TextView title = Ui.text(activity, c.optString("name"), 10.5f, Ui.TEXT, true);
        title.setGravity(Gravity.CENTER);
        title.setMaxLines(2);
        card.addView(title, margin(7, 0));
        card.setOnClickListener(v -> openCategory(c));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(activity, 116), Ui.dp(activity, 126));
        p.setMargins(Ui.dp(activity, 5), 0, Ui.dp(activity, 5), 0);
        card.setLayoutParams(p);
        return card;
    }

    private LinearLayout sectionHeader(String title, String action, View.OnClickListener click) {
        LinearLayout row = Ui.horizontal(activity);
        TextView t = Ui.text(activity, title, 17, Ui.TEXT, true);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView a = Ui.text(activity, action, 11, Ui.PRIMARY, true);
        a.setPadding(Ui.dp(activity, 8), Ui.dp(activity, 8), Ui.dp(activity, 8), Ui.dp(activity, 8));
        a.setOnClickListener(click);
        row.addView(a);
        return row;
    }

    private View tutorialRow(JSONObject t) {
        LinearLayout card = Ui.horizontal(activity);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(Ui.dp(activity, 10), Ui.dp(activity, 10), Ui.dp(activity, 10), Ui.dp(activity, 10));
        card.setBackground(Ui.bg(Color.WHITE, 19, Ui.LINE, 1, activity));
        View image = coverVisual(t, 112, 78);
        card.addView(image, new LinearLayout.LayoutParams(Ui.dp(activity, 112), Ui.dp(activity, 78)));
        LinearLayout text = Ui.vertical(activity);
        text.setPadding(Ui.dp(activity, 12), 0, Ui.dp(activity, 8), 0);
        TextView title = Ui.text(activity, t.optString("title"), 13.5f, Ui.TEXT, true);
        title.setMaxLines(2);
        text.addView(title);
        TextView summary = Ui.text(activity, t.optString("summary"), 10.5f, Ui.MUTED, false);
        summary.setMaxLines(2);
        text.addView(summary, margin(4, 5));
        LinearLayout meta = Ui.horizontal(activity);
        meta.addView(Ui.pill(activity, t.optString("level", "مبتدی"), Ui.PRIMARY_DARK, Color.rgb(239, 238, 255)));
        Ui.gap(meta, activity, 5);
        meta.addView(Ui.pill(activity, t.optInt("duration", 5) + " دقیقه", Ui.MUTED, Ui.SURFACE_SOFT));
        text.addView(meta);
        card.addView(text, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.setOnClickListener(v -> openTutorial(t));
        return card;
    }

    private List<JSONObject> popularTutorials(int limit) {
        List<JSONObject> list = new ArrayList<>();
        for (int i = 0; i < tutorials.length(); i++) {
            JSONObject t = tutorials.optJSONObject(i);
            if (t != null && t.optBoolean("active", true) && !t.optBoolean("deleted", false)) list.add(t);
        }
        Collections.sort(list, new Comparator<JSONObject>() {
            @Override public int compare(JSONObject a, JSONObject b) {
                int av = a.optInt("views", 0) + (a.optBoolean("featured", false) ? 1_000_000 : 0);
                int bv = b.optInt("views", 0) + (b.optBoolean("featured", false) ? 1_000_000 : 0);
                if (av != bv) return Integer.compare(bv, av);
                return Integer.compare(a.optInt("sortOrder", 0), b.optInt("sortOrder", 0));
            }
        });
        return list.subList(0, Math.min(limit, list.size()));
    }

    private void openAllCategories() {
        beginSubPage(this::openAllCategories);
        LinearLayout page = pageBody();
        page.addView(backBar("همه دسته‌بندی‌ها"));
        TextView intro = Ui.text(activity, "موضوع موردنظرت را انتخاب کن؛ داخل هر دسته آموزش‌های ریز و مرحله‌به‌مرحله قرار دارد.", 11.5f, Ui.MUTED, false);
        page.addView(intro, margin(4, 14));
        GridLayout grid = new GridLayout(activity);
        grid.setColumnCount(2);
        int idx = 0;
        for (int i = 0; i < categories.length(); i++) {
            JSONObject c = categories.optJSONObject(i);
            if (!isActiveRootCategory(c)) continue;
            View card = fullCategoryCard(c);
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = 0;
            gp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            gp.columnSpec = GridLayout.spec(idx % 2, 1, 1f);
            gp.setMargins(Ui.dp(activity, 5), Ui.dp(activity, 5), Ui.dp(activity, 5), Ui.dp(activity, 5));
            card.setLayoutParams(gp);
            grid.addView(card);
            idx++;
        }
        if (idx == 0) page.addView(emptyState("دسته‌بندی‌ای منتشر نشده است."));
        else page.addView(grid);
        page.addView(space(22));
        content.addView(wrapPull(page, pull -> syncAll(true, false, pull), null));
    }

    private View fullCategoryCard(JSONObject c) {
        LinearLayout card = Ui.vertical(activity);
        card.setPadding(Ui.dp(activity, 10), Ui.dp(activity, 10), Ui.dp(activity, 10), Ui.dp(activity, 12));
        card.setBackground(Ui.bg(Color.WHITE, 20, Ui.LINE, 1, activity));
        View visual = categoryBanner(c);
        card.addView(visual, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 112)));
        TextView title = Ui.text(activity, c.optString("name"), 13.5f, Ui.TEXT, true);
        card.addView(title, margin(9, 3));
        String desc = c.optString("description");
        if (desc.isEmpty()) desc = "آموزش‌ها و راهنماهای این موضوع";
        TextView d = Ui.text(activity, desc, 10.2f, Ui.MUTED, false);
        d.setMaxLines(3);
        card.addView(d);
        card.setOnClickListener(v -> openCategory(c));
        return card;
    }

    private void openCategory(JSONObject category) {
        final String categoryId = category.optString("id");
        Runnable renderer = () -> { JSONObject fresh = categoryIndex.get(categoryId); if (fresh != null) openCategory(fresh); else showTab(activeTab); };
        beginSubPage(renderer);
        LinearLayout page = pageBody();
        page.addView(backBar(category.optString("name")));
        page.addView(categoryBanner(category), sizedMargin(Ui.dp(activity, 150), 6, 10));
        String desc = category.optString("description");
        if (!desc.isEmpty()) page.addView(Ui.text(activity, desc, 11.5f, Ui.MUTED, false), margin(0, 12));
        LinearLayout rows = Ui.vertical(activity);
        int added = 0;
        for (int i = 0; i < tutorials.length(); i++) {
            JSONObject t = tutorials.optJSONObject(i);
            if (t == null || !t.optBoolean("active", true) || t.optBoolean("deleted", false) || !category.optString("id").equals(t.optString("categoryId"))) continue;
            rows.addView(tutorialRow(t), margin(0, 10));
            added++;
        }
        if (added == 0) rows.addView(emptyState("هنوز مطلبی برای این دسته ثبت نشده است."));
        page.addView(rows);
        page.addView(space(22));
        content.addView(wrapPull(page, pull -> syncAll(true, false, pull), null));
    }

    private void openPopular() {
        beginSubPage(this::openPopular);
        LinearLayout page = pageBody();
        page.addView(backBar("آموزش‌های محبوب"));
        for (JSONObject t : popularTutorials(200)) page.addView(tutorialRow(t), margin(0, 10));
        page.addView(space(22));
        content.addView(wrapPull(page, pull -> syncAll(true, false, pull), null));
    }

    private View buildFavoritesPage() {
        LinearLayout page = pageBody();
        page.addView(buildTopBar("علاقه‌مندی‌ها", false));
        page.addView(Ui.text(activity, "آموزش‌هایی که ذخیره کرده‌ای اینجا می‌مانند.", 11.5f, Ui.MUTED, false), margin(2, 12));
        int added = 0;
        for (String id : new ArrayList<>(favorites)) {
            JSONObject t = tutorialIndex.get(id);
            if (t != null && t.optBoolean("active", true) && !t.optBoolean("deleted", false)) {
                page.addView(tutorialRow(t), margin(0, 10));
                added++;
            }
        }
        if (added == 0) page.addView(emptyState("هنوز آموزشی ذخیره نکرده‌ای."));
        page.addView(space(22));
        return wrapPull(page, pull -> syncAll(true, false, pull), null);
    }

    private View buildNewsPage() {
        LinearLayout page = pageBody();
        page.addView(buildTopBar("اخبار آنلاین", false));
        page.addView(Ui.text(activity, "جدیدترین خبرها از سرور دریافت می‌شوند.", 11.5f, Ui.MUTED, false), margin(2, 12));
        newsListHost = Ui.vertical(activity);
        page.addView(newsListHost);
        newsFooterHost = Ui.vertical(activity);
        page.addView(newsFooterHost);
        renderNewsList();

        newsPull = new PullRefreshLayout(activity);
        newsPull.setContent(page);
        newsPull.setOnRefreshListener(() -> loadNewsPage(true, newsPull));
        newsPull.setOnBottomListener(() -> {
            if (newsHasMore && !newsLoading) loadNewsPage(false, null);
        });
        if (news.length() == 0 && !newsLoading) loadNewsPage(true, null);
        return newsPull;
    }

    private void renderNewsList() {
        if (newsListHost == null) return;
        newsListHost.removeAllViews();
        int added = 0;
        for (int i = 0; i < news.length(); i++) {
            JSONObject n = news.optJSONObject(i);
            if (n == null || !n.optBoolean("active", true) || n.optBoolean("deleted", false)) continue;
            newsListHost.addView(newsRow(n), margin(0, 12));
            added++;
        }
        if (added == 0 && !newsLoading) newsListHost.addView(emptyState("هنوز خبری منتشر نشده است."));
        renderNewsFooter();
    }

    private void renderNewsFooter() {
        if (newsFooterHost == null) return;
        newsFooterHost.removeAllViews();
        if (newsLoading && news.length() > 0) {
            LinearLayout load = Ui.horizontal(activity);
            load.setGravity(Gravity.CENTER);
            ProgressBar p = new ProgressBar(activity);
            load.addView(p, new LinearLayout.LayoutParams(Ui.dp(activity, 28), Ui.dp(activity, 28)));
            TextView t = Ui.text(activity, "در حال دریافت خبرهای قدیمی‌تر…", 10.5f, Ui.MUTED, false);
            load.addView(t);
            newsFooterHost.addView(load, margin(10, 16));
        } else if (!newsHasMore && news.length() > 0) {
            TextView end = Ui.text(activity, "به انتهای اخبار رسیدید", 10.5f, Ui.MUTED2, false);
            end.setGravity(Gravity.CENTER);
            newsFooterHost.addView(end, margin(14, 20));
        }
    }

    private View newsRow(JSONObject n) {
        LinearLayout card = Ui.vertical(activity);
        card.setPadding(Ui.dp(activity, 9), Ui.dp(activity, 9), Ui.dp(activity, 9), Ui.dp(activity, 12));
        card.setBackground(Ui.bg(Color.WHITE, 20, Ui.LINE, 1, activity));
        View cover = newsVisual(n);
        card.addView(cover, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 180)));
        TextView title = Ui.text(activity, n.optString("title"), 15, Ui.TEXT, true);
        title.setMaxLines(2);
        card.addView(title, margin(11, 4));
        TextView sum = Ui.text(activity, n.optString("summary"), 11, Ui.MUTED, false);
        sum.setMaxLines(3);
        card.addView(sum, margin(2, 5));
        TextView date = Ui.text(activity, n.optString("publishedAt", ""), 9.5f, Ui.MUTED2, false);
        card.addView(date);
        card.setOnClickListener(v -> openNews(n));
        return card;
    }

    private void loadNewsPage(boolean reset, PullRefreshLayout pull) {
        if (newsLoading) {
            if (pull != null) pull.setRefreshing(false);
            return;
        }
        newsLoading = true;
        if (reset && news.length() == 0) {
            if (newsListHost != null) {
                newsListHost.removeAllViews();
                LinearLayout l = Ui.vertical(activity);
                l.setGravity(Gravity.CENTER);
                ProgressBar p = new ProgressBar(activity);
                l.addView(p, new LinearLayout.LayoutParams(Ui.dp(activity, 40), Ui.dp(activity, 40)));
                TextView t = Ui.text(activity, "در حال دریافت اخبار…", 11.5f, Ui.MUTED, false);
                t.setGravity(Gravity.CENTER);
                l.addView(t, margin(10, 0));
                newsListHost.addView(l, sizedMargin(Ui.dp(activity, 140), 18, 10));
            }
        }
        renderNewsFooter();
        JSONObject body = new JSONObject();
        try {
            body.put("limit", NEWS_PAGE_SIZE);
            body.put("offset", reset ? 0 : news.length());
        } catch (Exception ignored) { }
        api.post("app.php?action=news", body, null, new ApiClient.Callback() {
            @Override public void ok(JSONObject j) {
                JSONArray rows = j.optJSONArray("news");
                if (rows == null) rows = new JSONArray();
                if (reset) news = rows;
                else news = appendUnique(news, rows, "id");
                newsTotal = j.optInt("total", news.length());
                newsHasMore = j.has("hasMore") ? j.optBoolean("hasMore") : news.length() < newsTotal;
                String v = j.optString("contentVersion");
                if (!v.isEmpty()) contentVersion = v;
                newsLoading = false;
                indexData();
                saveCaches();
                renderNewsList();
                if (pull != null) pull.setRefreshing(false);
            }
            @Override public void fail(String m) {
                newsLoading = false;
                renderNewsList();
                if (pull != null) pull.setRefreshing(false);
                if (news.length() == 0) activity.toast("اتصال اینترنت برقرار نیست");
                else activity.toast("به‌روزرسانی اخبار انجام نشد");
            }
        });
    }

    private JSONArray appendUnique(JSONArray base, JSONArray more, String idKey) {
        JSONArray out = new JSONArray();
        Set<String> ids = new HashSet<>();
        for (int i = 0; i < base.length(); i++) {
            JSONObject x = base.optJSONObject(i);
            if (x == null) continue;
            String id = x.optString(idKey);
            if (ids.add(id)) out.put(x);
        }
        for (int i = 0; i < more.length(); i++) {
            JSONObject x = more.optJSONObject(i);
            if (x == null) continue;
            String id = x.optString(idKey);
            if (ids.add(id)) out.put(x);
        }
        return out;
    }

    private void openTutorial(JSONObject summary) {
        String id = summary.optString("id");
        JSONObject local = tutorialIndex.get(id);
        if (local != null && !local.optString("body").trim().isEmpty()) {
            showTutorialDetail(local);
            trackView("tutorial", id);
            return;
        }
        showDetailLoading("در حال دریافت آموزش…");
        api.post("app.php?action=tutorial", json("id", id), null, new ApiClient.Callback() {
            @Override public void ok(JSONObject j) {
                JSONObject t = j.optJSONObject("tutorial");
                if (t != null) {
                    replaceTutorial(t);
                    saveCaches();
                    replaceCurrentSubPage(() -> showTutorialDetail(t));
                    trackView("tutorial", id);
                }
            }
            @Override public void fail(String m) {
                activity.toast(m);
                goBack();
            }
        });
    }

    private void showTutorialDetail(JSONObject t) {
        final String tutorialId = t.optString("id");
        Runnable renderer = () -> { JSONObject fresh = tutorialIndex.get(tutorialId); if (fresh != null) showTutorialDetail(fresh); else showTab(activeTab); };
        beginSubPage(renderer);
        LinearLayout page = pageBody();
        LinearLayout bar = backBar(t.optString("title"));
        FrameLayout save = circleImageAction("favoriteAction", favorites.contains(t.optString("id")) ? "♥" : "♡");
        if (favorites.contains(t.optString("id"))) save.setBackground(Ui.bg(Color.rgb(255, 241, 244), 99, Color.rgb(255, 210, 220), 1, activity));
        save.setOnClickListener(v -> {
            toggleFavorite(t.optString("id"));
            replaceCurrentSubPage(() -> showTutorialDetail(t));
        });
        bar.addView(save, new LinearLayout.LayoutParams(Ui.dp(activity, 42), Ui.dp(activity, 42)));
        page.addView(bar);
        page.addView(detailCover(t), sizedMargin(Ui.dp(activity, 190), 8, 15));
        page.addView(buildDetailAdiveryBanner(), margin(0, 15));
        JSONObject c = categoryIndex.get(t.optString("categoryId"));
        if (c != null) page.addView(Ui.pill(activity, c.optString("name"), Ui.PRIMARY_DARK, Color.rgb(238, 237, 255)), margin(0, 8));
        page.addView(Ui.text(activity, t.optString("title"), 23, Ui.TEXT, true), margin(0, 6));
        LinearLayout meta = Ui.horizontal(activity);
        meta.addView(Ui.pill(activity, t.optString("level", "مبتدی"), Ui.GREEN, Color.rgb(231, 249, 241)));
        Ui.gap(meta, activity, 6);
        meta.addView(Ui.pill(activity, t.optInt("duration", 5) + " دقیقه", Ui.MUTED, Ui.SURFACE_SOFT));
        page.addView(meta, margin(4, 16));
        addBodyParagraphs(page, t.optString("body").isEmpty() ? t.optString("summary") : t.optString("body"));
        String source = t.optString("sourceUrl");
        if (!source.isEmpty()) {
            LinearLayout sourceCard = Ui.softCard(activity);
            sourceCard.addView(Ui.text(activity, "منبع", 10, Ui.MUTED, true));
            TextView st = Ui.text(activity, t.optString("sourceTitle", "مشاهده منبع"), 12.5f, Ui.PRIMARY, true);
            sourceCard.addView(st, margin(4, 0));
            sourceCard.setOnClickListener(v -> openUrl(source));
            page.addView(sourceCard, margin(6, 12));
        }
        page.addView(space(25));
        content.addView(wrapPull(page, pull -> syncAll(true, false, pull), null));
    }

    private void openNews(JSONObject summary) {
        String id = summary.optString("id");
        JSONObject local = newsIndex.get(id);
        if (local != null && !local.optString("body").trim().isEmpty()) {
            showNewsDetail(local);
            trackView("news", id);
            return;
        }
        showDetailLoading("در حال دریافت خبر…");
        api.post("app.php?action=news_detail", json("id", id), null, new ApiClient.Callback() {
            @Override public void ok(JSONObject j) {
                JSONObject n = j.optJSONObject("news");
                if (n != null) {
                    replaceNews(n);
                    saveCaches();
                    replaceCurrentSubPage(() -> showNewsDetail(n));
                    trackView("news", id);
                }
            }
            @Override public void fail(String m) {
                activity.toast(m);
                goBack();
            }
        });
    }

    private void showNewsDetail(JSONObject n) {
        final String newsId = n.optString("id");
        Runnable renderer = () -> { JSONObject fresh = newsIndex.get(newsId); if (fresh != null) showNewsDetail(fresh); else showTab(TAB_NEWS); };
        beginSubPage(renderer);
        LinearLayout page = pageBody();
        page.addView(backBar("خبر"));
        page.addView(detailCover(n), sizedMargin(Ui.dp(activity, 190), 8, 14));
        page.addView(buildDetailAdiveryBanner(), margin(0, 14));
        page.addView(Ui.text(activity, n.optString("title"), 22, Ui.TEXT, true), margin(0, 6));
        page.addView(Ui.text(activity, n.optString("publishedAt"), 10, Ui.MUTED2, false), margin(0, 14));
        addBodyParagraphs(page, n.optString("body").isEmpty() ? n.optString("summary") : n.optString("body"));
        String source = n.optString("sourceUrl");
        if (!source.isEmpty()) {
            Button b = Ui.button(activity, "مشاهده منبع", false);
            b.setOnClickListener(v -> openUrl(source));
            page.addView(b, margin(6, 10));
        }
        page.addView(space(25));
        content.addView(wrapPull(page, pull -> loadNewsPage(true, pull), null));
    }

    private View buildDetailAdiveryBanner() {
        FrameLayout host = new FrameLayout(activity);
        host.setVisibility(View.GONE);
        AdiveryBannerAdView banner = AdiveryManager.createBanner(activity, BannerSize.BANNER, new AdiveryAdListener() {
            @Override public void onAdLoaded() {
                host.setVisibility(View.VISIBLE);
            }

            @Override public void onError(String reason) {
                host.setVisibility(View.GONE);
            }
        });
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.gravity = Gravity.CENTER;
        host.addView(banner, p);
        banner.loadAd();
        host.setMinimumHeight(Ui.dp(activity, 50));
        return host;
    }

    private void addBodyParagraphs(LinearLayout page, String body) {
        for (String p : body.split("\\n\\s*\\n")) {
            if (p.trim().isEmpty()) continue;
            TextView pv = Ui.text(activity, p.trim(), 13.2f, Ui.TEXT, false);
            pv.setLineSpacing(Ui.dp(activity, 3), 1.35f);
            page.addView(pv, margin(0, 14));
        }
    }

    private void showDetailLoading(String message) {
        beginSubPage(null);
        LinearLayout page = Ui.vertical(activity);
        page.setGravity(Gravity.CENTER);
        ProgressBar p = new ProgressBar(activity);
        page.addView(p, new LinearLayout.LayoutParams(Ui.dp(activity, 42), Ui.dp(activity, 42)));
        TextView t = Ui.text(activity, message, 11.5f, Ui.MUTED, false);
        t.setGravity(Gravity.CENTER);
        page.addView(t, margin(10, 0));
        content.addView(page);
    }

    private void openSearch() {
        beginSubPage(null);
        LinearLayout root = Ui.vertical(activity);
        root.setPadding(Ui.dp(activity, 14), Ui.dp(activity, 10), Ui.dp(activity, 14), Ui.dp(activity, 10));
        root.addView(backBar("جستجو"));
        EditText q = new EditText(activity);
        q.setHint("جستجو در آموزش‌ها…");
        q.setSingleLine(true);
        q.setTextSize(13);
        q.setTextColor(Ui.TEXT);
        q.setHintTextColor(Ui.MUTED2);
        q.setPadding(Ui.dp(activity, 14), 0, Ui.dp(activity, 14), 0);
        q.setBackground(Ui.bg(Color.WHITE, 16, Ui.LINE, 1, activity));
        root.addView(q, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 52)));
        ScrollView scroll = new ScrollView(activity);
        LinearLayout results = Ui.vertical(activity);
        results.setPadding(0, Ui.dp(activity, 10), 0, Ui.dp(activity, 20));
        scroll.addView(results);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        Runnable render = () -> {
            String needle = q.getText().toString().trim().toLowerCase();
            results.removeAllViews();
            int added = 0;
            for (int i = 0; i < tutorials.length(); i++) {
                JSONObject t = tutorials.optJSONObject(i);
                if (t == null || !t.optBoolean("active", true) || t.optBoolean("deleted", false)) continue;
                String hay = (t.optString("title") + " " + t.optString("summary") + " " + t.optJSONArray("tags")).toLowerCase();
                if (needle.isEmpty() || hay.contains(needle)) {
                    results.addView(tutorialRow(t), margin(0, 8));
                    added++;
                }
            }
            if (added == 0) results.addView(emptyState("نتیجه‌ای پیدا نشد."));
        };
        q.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) { }
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) { render.run(); }
            @Override public void afterTextChanged(Editable e) { }
        });
        render.run();
        content.addView(root);
    }

    private void toggleFavorite(String id) {
        if (favorites.contains(id)) favorites.remove(id); else favorites.add(id);
        prefs.edit().putStringSet("favorites", new HashSet<>(favorites)).apply();
        activity.toast(favorites.contains(id) ? "به علاقه‌مندی‌ها اضافه شد" : "از علاقه‌مندی‌ها حذف شد");
    }

    private void followTarget(JSONObject s) {
        String type = s.optString("targetType");
        String value = s.optString("targetValue");
        if (value.isEmpty()) value = s.optString("link");
        if ("tutorial".equals(type)) {
            JSONObject t = tutorialIndex.get(value); if (t == null) { t = new JSONObject(); try { t.put("id", value); } catch (Exception ignored) { } } openTutorial(t);
        } else if ("category".equals(type) && categoryIndex.containsKey(value)) openCategory(categoryIndex.get(value));
        else if ("news".equals(type)) {
            JSONObject n = newsIndex.get(value); if (n == null) { n = new JSONObject(); try { n.put("id", value); } catch (Exception ignored) { } } openNews(n);
        } else if ("url".equals(type) || value.startsWith("http://") || value.startsWith("https://")) openUrl(value);
    }

    private void checkForUpdates() {
        api.post("app.php?action=version", new JSONObject(), null, new ApiClient.Callback() {
            @Override public void ok(JSONObject j) {
                lastLoadedAt = SystemClock.elapsedRealtime();
                String remote = j.optString("contentVersion");
                if (!remote.isEmpty() && !remote.equals(contentVersion)) syncAll(true, false, null);
            }
            @Override public void fail(String m) {
                lastLoadedAt = SystemClock.elapsedRealtime();
                if (hasBootstrapCache()) activity.toast("حالت آفلاین؛ اطلاعات ذخیره‌شده نمایش داده می‌شود");
            }
        });
    }

    private void syncAll(boolean force, boolean initial, PullRefreshLayout pull) {
        final int[] pending = {3};
        final int[] success = {0};
        final boolean[] homeOk = {false};
        final boolean[] tutorialOk = {false};
        final String[] newestVersion = {contentVersion};
        Runnable done = () -> {
            pending[0]--;
            if (pending[0] > 0) return;
            if (pull != null) pull.setRefreshing(false);
            if (homeOk[0] && tutorialOk[0]) {
                contentVersion = newestVersion[0];
                indexData();
                saveCaches();
                lastLoadedAt = SystemClock.elapsedRealtime();
                rebuildBottomNav();
                if (initial) {
                    showTab(TAB_HOME);
                    settleInitial();
                } else if (subPageOpen && pull != null && subpageRenderer != null) {
                    replaceCurrentSubPage(subpageRenderer);
                } else if (!subPageOpen) {
                    showTab(activeTab);
                }
            } else {
                if (initial && !hasBootstrapCache()) {
                    showInitialOffline();
                    settleInitial();
                } else {
                    activity.toast("به‌روزرسانی انجام نشد؛ اطلاعات ذخیره‌شده نمایش داده می‌شود");
                }
            }
        };

        api.post("app.php?action=home", new JSONObject(), null, new ApiClient.Callback() {
            @Override public void ok(JSONObject j) {
                JSONArray s = j.optJSONArray("sliders");
                JSONArray c = j.optJSONArray("categories");
                JSONObject ui = j.optJSONObject("uiImages");
                if (s != null) sliders = s;
                if (c != null) categories = c;
                if (ui != null) uiImages = ui;
                String v = j.optString("contentVersion");
                if (!v.isEmpty()) newestVersion[0] = v;
                success[0]++;
                homeOk[0] = true;
                done.run();
            }
            @Override public void fail(String m) { done.run(); }
        });

        JSONObject tutBody = new JSONObject();
        try { tutBody.put("limit", 200); tutBody.put("offset", 0); } catch (Exception ignored) { }
        api.post("app.php?action=tutorials", tutBody, null, new ApiClient.Callback() {
            @Override public void ok(JSONObject j) {
                JSONArray a = j.optJSONArray("tutorials");
                if (a != null) tutorials = a;
                String v = j.optString("contentVersion");
                if (!v.isEmpty()) newestVersion[0] = v;
                success[0]++;
                tutorialOk[0] = true;
                done.run();
            }
            @Override public void fail(String m) { done.run(); }
        });

        JSONObject newsBody = new JSONObject();
        try { newsBody.put("limit", NEWS_PAGE_SIZE); newsBody.put("offset", 0); } catch (Exception ignored) { }
        api.post("app.php?action=news", newsBody, null, new ApiClient.Callback() {
            @Override public void ok(JSONObject j) {
                JSONArray a = j.optJSONArray("news");
                if (a != null) news = a;
                newsTotal = j.optInt("total", news.length());
                newsHasMore = j.has("hasMore") ? j.optBoolean("hasMore") : news.length() < newsTotal;
                String v = j.optString("contentVersion");
                if (!v.isEmpty()) newestVersion[0] = v;
                success[0]++;
                done.run();
            }
            @Override public void fail(String m) { done.run(); }
        });
    }

    private void trackView(String type, String id) {
        JSONObject b = new JSONObject();
        try {
            b.put("type", type);
            b.put("id", id);
            b.put("deviceId", deviceId);
        } catch (Exception ignored) { }
        api.post("app.php?action=view", b, null, new ApiClient.Callback() {
            @Override public void ok(JSONObject j) {
                JSONObject item = "tutorial".equals(type) ? tutorialIndex.get(id) : newsIndex.get(id);
                if (item != null) {
                    try { item.put("views", j.optInt("views", item.optInt("views", 0))); } catch (Exception ignored) { }
                    saveCaches();
                }
            }
            @Override public void fail(String m) { }
        });
    }

    private void replaceTutorial(JSONObject replacement) {
        JSONArray out = new JSONArray();
        boolean found = false;
        for (int i = 0; i < tutorials.length(); i++) {
            JSONObject x = tutorials.optJSONObject(i);
            if (x != null && replacement.optString("id").equals(x.optString("id"))) {
                out.put(replacement);
                found = true;
            } else if (x != null) out.put(x);
        }
        if (!found) out.put(replacement);
        tutorials = out;
        indexData();
    }

    private void replaceNews(JSONObject replacement) {
        JSONArray out = new JSONArray();
        boolean found = false;
        for (int i = 0; i < news.length(); i++) {
            JSONObject x = news.optJSONObject(i);
            if (x != null && replacement.optString("id").equals(x.optString("id"))) {
                out.put(replacement);
                found = true;
            } else if (x != null) out.put(x);
        }
        if (!found) out.put(replacement);
        news = out;
        indexData();
    }

    private PullRefreshLayout wrapPull(LinearLayout page, RefreshAction refresh, PullRefreshLayout.BottomListener bottom) {
        PullRefreshLayout pull = new PullRefreshLayout(activity);
        pull.setContent(page);
        if (refresh != null) pull.setOnRefreshListener(() -> refresh.run(pull));
        if (bottom != null) pull.setOnBottomListener(bottom);
        return pull;
    }

    private interface RefreshAction { void run(PullRefreshLayout pull); }

    private LinearLayout backBar(String title) {
        LinearLayout bar = Ui.horizontal(activity);
        bar.setPadding(0, Ui.dp(activity, 4), 0, Ui.dp(activity, 8));
        TextView t = Ui.text(activity, title, 18, Ui.TEXT, true);
        t.setMaxLines(1);
        bar.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return bar;
    }

    private TextView circleAction(String txt) {
        TextView v = Ui.text(activity, txt, 22, Ui.PRIMARY, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(Ui.bg(Color.WHITE, 99, Ui.LINE, 1, activity));
        return v;
    }

    private View categoryVisual(JSONObject c, int size) {
        String image = ApiClient.absolute(c.optString("image"));
        if (!image.isEmpty()) {
            ImageView iv = new ImageView(activity);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(Ui.bg(Color.WHITE, 16, Color.TRANSPARENT, 0, activity));
            if (Build.VERSION.SDK_INT >= 21) iv.setClipToOutline(true);
            images.load(iv, image);
            return iv;
        }
        TextView tv = Ui.text(activity, c.optString("icon", "□"), size * .48f, Ui.PRIMARY, false);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(Ui.bg(Color.argb(35, 80, 73, 224), 16, Color.TRANSPARENT, 0, activity));
        return tv;
    }

    private View categoryBanner(JSONObject c) {
        FrameLayout f = new FrameLayout(activity);
        f.setBackground(Ui.gradient(categoryTint(c.optString("id")), Color.rgb(236, 238, 255), 20, Color.TRANSPARENT, 0, activity));
        if (Build.VERSION.SDK_INT >= 21) f.setClipToOutline(true);
        String image = ApiClient.absolute(c.optString("image"));
        if (!image.isEmpty()) {
            ImageView iv = new ImageView(activity);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            images.load(iv, image);
            f.addView(iv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            TextView icon = Ui.text(activity, c.optString("icon", "□"), 38, Ui.PRIMARY, false);
            icon.setGravity(Gravity.CENTER);
            f.addView(icon, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        return f;
    }

    private int categoryTint(String id) {
        int[] colors = {Color.rgb(239, 235, 255), Color.rgb(232, 244, 255), Color.rgb(231, 249, 243), Color.rgb(255, 244, 225), Color.rgb(255, 235, 240), Color.rgb(236, 240, 255)};
        return colors[Math.abs(id.hashCode()) % colors.length];
    }

    private View coverVisual(JSONObject t, int w, int h) {
        String cover = ApiClient.absolute(t.optString("cover"));
        if (!cover.isEmpty()) {
            ImageView iv = new ImageView(activity);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(Ui.bg(Ui.SURFACE_SOFT, 16, Color.TRANSPARENT, 0, activity));
            if (Build.VERSION.SDK_INT >= 21) iv.setClipToOutline(true);
            images.load(iv, cover);
            return iv;
        }
        return mediaPlaceholder(16);
    }

    private View newsVisual(JSONObject n) {
        String cover = ApiClient.absolute(n.optString("cover"));
        FrameLayout f = new FrameLayout(activity);
        f.setBackground(Ui.gradient(Color.rgb(230, 239, 255), Color.rgb(241, 236, 255), 18, Color.TRANSPARENT, 0, activity));
        if (Build.VERSION.SDK_INT >= 21) f.setClipToOutline(true);
        if (!cover.isEmpty()) {
            ImageView iv = new ImageView(activity);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            images.load(iv, cover);
            f.addView(iv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            TextView i = Ui.text(activity, "□", 30, Ui.PRIMARY, false);
            i.setGravity(Gravity.CENTER);
            f.addView(i, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        return f;
    }

    private View detailCover(JSONObject item) {
        String cover = ApiClient.absolute(item.optString("cover"));
        FrameLayout f = new FrameLayout(activity);
        f.setBackground(Ui.gradient(Color.rgb(232, 238, 255), Color.rgb(239, 234, 255), 22, Color.TRANSPARENT, 0, activity));
        if (Build.VERSION.SDK_INT >= 21) f.setClipToOutline(true);
        if (!cover.isEmpty()) {
            ImageView iv = new ImageView(activity);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            images.load(iv, cover);
            f.addView(iv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            View fallback = mediaPlaceholder(18);
            f.addView(fallback, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        return f;
    }

    private View mediaPlaceholder(int radius) {
        FrameLayout f = new FrameLayout(activity);
        f.setBackground(Ui.gradient(Color.rgb(238, 241, 250), Color.rgb(246, 247, 252), radius, Color.TRANSPARENT, 0, activity));
        if (Build.VERSION.SDK_INT >= 21) f.setClipToOutline(true);
        TextView mark = Ui.text(activity, "▧", 24, Ui.MUTED2, false);
        mark.setGravity(Gravity.CENTER);
        f.addView(mark, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return f;
    }

    private TextView emptyState(String text) {
        TextView e = Ui.text(activity, text, 12, Ui.MUTED, false);
        e.setGravity(Gravity.CENTER);
        e.setPadding(Ui.dp(activity, 16), Ui.dp(activity, 32), Ui.dp(activity, 16), Ui.dp(activity, 32));
        e.setBackground(Ui.bg(Color.WHITE, 18, Ui.LINE, 1, activity));
        return e;
    }

    private LinearLayout pageBody() {
        LinearLayout p = Ui.vertical(activity);
        p.setPadding(Ui.dp(activity, 14), Ui.dp(activity, 4), Ui.dp(activity, 14), Ui.dp(activity, 12));
        return p;
    }

    private View space(int dp) {
        View v = new View(activity);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, Ui.dp(activity, dp)));
        return v;
    }

    private LinearLayout.LayoutParams margin(int top, int bottom) { return Ui.lpMatchWrap(activity, top, bottom); }

    private LinearLayout.LayoutParams sizedMargin(int heightPx, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx);
        p.setMargins(0, Ui.dp(activity, top), 0, Ui.dp(activity, bottom));
        return p;
    }

    private JSONObject json(String key, Object value) {
        JSONObject j = new JSONObject();
        try { j.put(key, value); } catch (Exception ignored) { }
        return j;
    }

    private void openUrl(String url) {
        if (url == null || url.trim().isEmpty()) return;
        try { activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { activity.toast("بازکردن لینک ممکن نشد"); }
    }
}
