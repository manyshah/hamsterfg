# No custom ProGuard/R8 rules are required for this verification build.
