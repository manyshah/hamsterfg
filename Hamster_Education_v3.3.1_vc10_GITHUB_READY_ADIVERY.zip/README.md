# Hamster Education Android v3.3.1 (10)

Native Android client for `com.maniplus.notcoin`.

Current release focus:
- Splash is time-bound at 2.5 seconds; network/cache never blocks it.
- Adivery Android SDK 4.9.0 integration.
- Home slider accepts unlimited mixed slides: normal image slides or Adivery medium-rectangle slides.
- Adivery slider uses the project banner placement; slider impressions/clicks are reported to backend per slide.
- Adivery banner is shown under the cover image on tutorial/news detail pages when an ad is available.
- One startup interstitial is prepared at launch and attempted once per app process after ~10 seconds when enabled by backend/admin.
- System Back is the only internal back navigation; no extra header back arrow is introduced.
- Back on Favorites/News root returns Home; Back on Home shows exit confirmation.
- Confirmed exit removes all app tasks from Recents and explicitly terminates the app process.
- Category images are category-only; tutorial/news covers remain independent.

Build identity:
- applicationId: `com.maniplus.notcoin`
- versionName: `3.3.1`
- versionCode: `10`
- compileSdk / targetSdk: `36`
- minSdk: `21`
- Java: `17`

Adivery placements:
- App ID: `1ed3d9f1-ccaf-40a7-808f-aaee6ccd422f`
- Banner Zone ID: `4fb16d31-bfcd-4c85-9a0f-f787d8fc34f4`
- Interstitial Zone ID: `d027cb9f-ad5b-410e-a716-287fd8ec61e1`

The GitHub Actions workflow is intentionally unchanged from the verified v3.3.1/vc10 workflow.
