# Hamster Education Android v3.3.0 (Version Code 10)

- Package: `com.maniplus.notcoin`
- Target SDK: 36
- Version Code: 10
- Version Name: 3.3.0
- Signing: original Hamster signing key bundled in `signing/hamster-release.jks`
- Store/key password: `1234`
- Alias: `hellosc`
- Key password: `1234`

## Data model
The APK contains no bundled tutorial/news/category/slider seed. First launch fetches content from the backend. After the first successful fetch, data and images are cached for offline reading. The backend remains the source of truth and content is re-synced when its content version changes or when the user pulls down to refresh.

## Refresh behavior
Home, categories, favorites and news use pull-to-refresh. News loads 10 items per page and automatically loads older items at the bottom.

## GitHub build
Keep this ZIP intact in the repository and use the provided workflow. It auto-detects and extracts the ZIP before building the signed release APK.
