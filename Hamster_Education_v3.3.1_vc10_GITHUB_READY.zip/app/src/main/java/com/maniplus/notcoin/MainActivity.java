package com.maniplus.notcoin;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final long SPLASH_DURATION_MS = 1500L;

    private final ApiClient api = new ApiClient();
    private ImageLoader images;
    private UsageTracker usage;
    private TutorialsController controller;
    private FrameLayout splash;
    private boolean exitDialogVisible;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        styleSystemBars();
        images = new ImageLoader(this);
        usage = new UsageTracker(this, api);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        applySafeInsets(root);

        // Splash is deliberately time-bound. Network/cache state must never keep the user here.
        splash = buildSplash();

        controller = new TutorialsController(this, api, images, usage.deviceId(), () -> { });
        root.addView(controller.view(), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(splash, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        new Handler(Looper.getMainLooper()).postDelayed(this::hideSplash, SPLASH_DURATION_MS);
    }

    private FrameLayout buildSplash() {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(Color.WHITE);
        LinearLayout box = Ui.vertical(this);
        box.setGravity(Gravity.CENTER);
        ImageView icon = new ImageView(this);
        icon.setImageResource(com.maniplus.notcoin.R.drawable.app_icon);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        try {
            String raw = getSharedPreferences("hamster_education_v35", MODE_PRIVATE).getString("ui_images_cache", "");
            if (!raw.isEmpty()) {
                String splashUrl = ApiClient.absolute(new JSONObject(raw).optString("splashLogo"));
                if (!splashUrl.isEmpty()) images.load(icon, splashUrl);
            }
        } catch (Exception ignored) { }
        box.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this, 112), Ui.dp(this, 112)));
        TextView title = Ui.text(this, "آموزش همستر", 24, Ui.TEXT, true);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = Ui.dp(this, 16);
        box.addView(title, tp);
        TextView sub = Ui.text(this, "در حال آماده‌سازی محتوا…", 11.5f, Ui.MUTED, false);
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = Ui.dp(this, 7);
        box.addView(sub, sp);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.gravity = Gravity.CENTER;
        f.addView(box, bp);
        return f;
    }

    private void hideSplash() {
        if (splash == null || splash.getVisibility() != View.VISIBLE) return;
        splash.animate().alpha(0f).setDuration(160).withEndAction(() -> {
            splash.setVisibility(View.GONE);
            splash.setClickable(false);
        }).start();
    }

    private void applySafeInsets(View root) {
        if (Build.VERSION.SDK_INT >= 20) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top;
                int bottom;
                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                    top = bars.top;
                    bottom = bars.bottom;
                } else {
                    top = insets.getSystemWindowInsetTop();
                    bottom = insets.getSystemWindowInsetBottom();
                }
                v.setPadding(0, top, 0, bottom);
                return insets;
            });
            root.requestApplyInsets();
        }
    }

    private void styleSystemBars() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 21) {
            w.setStatusBarColor(Color.WHITE);
            w.setNavigationBarColor(Color.WHITE);
        }
        if (Build.VERSION.SDK_INT >= 23) {
            int flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            w.getDecorView().setSystemUiVisibility(flags);
        }
    }

    public void toast(String s) {
        android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show();
    }

    @Override public void onBackPressed() {
        if (controller != null && controller.goBack()) return;
        showExitDialog();
    }

    private void showExitDialog() {
        if (exitDialogVisible || isFinishing()) return;
        exitDialogVisible = true;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("خروج از برنامه")
                .setMessage("آیا می‌خواهید از برنامه خارج شوید؟")
                .setNegativeButton("انصراف", (d, which) -> d.dismiss())
                .setPositiveButton("خروج", (d, which) -> closeAppCompletely())
                .create();
        dialog.setOnDismissListener(d -> exitDialogVisible = false);
        dialog.show();
    }

    private void closeAppCompletely() {
        if (Build.VERSION.SDK_INT >= 21) {
            finishAndRemoveTask();
        } else if (Build.VERSION.SDK_INT >= 16) {
            finishAffinity();
        } else {
            finish();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (usage != null) usage.start();
        if (controller != null) controller.refreshIfNeeded();
    }

    @Override protected void onPause() {
        if (usage != null) usage.stop();
        super.onPause();
    }
}
