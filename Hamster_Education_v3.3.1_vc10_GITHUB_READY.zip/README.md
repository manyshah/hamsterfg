# Hamster Education Android v3.3.1 (10)

Native Android client for `com.maniplus.notcoin`.

Release focus:
- Splash always exits after ~1.5 seconds; network/cache never blocks it.
- System Back is the only internal back navigation; no header back buttons.
- Nested pages go back exactly one level and preserve the previous View/scroll state.
- Back on Favorites/News root returns Home; Back on Home shows exit confirmation.
- Confirmed exit removes the app task.
- Category images are category-only.
- Tutorial and news covers are independent; missing covers use neutral placeholders, never category artwork.
- Images remain manageable from Backend/Admin v35 (upload/change/delete).

Build identity:
- applicationId: com.maniplus.notcoin
- versionName: 3.3.1
- versionCode: 10
- targetSdk: 36
