# Hamster Education 3.2.0 (versionCode 10)

Native Android education app for package `com.maniplus.notcoin`.

This revision includes:
- requested Hamster app icon
- splash screen
- status/navigation bar safe layout
- image-only swipe slider with dots
- panel-managed images for content cards
- backend-first content with no bundled education seed in APK
- cache only after successful backend sync
- pull-to-refresh (no refresh button)
- online news pagination: 10 items per page + infinite scroll loading
- favorites
- real presence/view analytics
- original Hamster signing key
- targetSdk 36

Build with the provided GitHub Actions workflow. The source ZIP can stay unextracted in the repository.
