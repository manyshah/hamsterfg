package com.maniplus.notcoin;

import android.content.Context;
import android.graphics.Color;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

public final class PullRefreshLayout extends FrameLayout {
    public interface Listener { void onRefresh(PullRefreshLayout layout); }
    private final ProgressBar spinner;
    private View content;
    private Listener listener;
    private float downY;
    private boolean dragging;
    private boolean refreshing;
    private final int trigger;

    public PullRefreshLayout(Context context) {
        super(context);
        setClipChildren(false);
        trigger = Ui.dp(context, 72);
        spinner = new ProgressBar(context);
        spinner.setIndeterminate(true);
        spinner.setVisibility(INVISIBLE);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(Ui.dp(context, 34), Ui.dp(context, 34));
        p.gravity = android.view.Gravity.TOP | android.view.Gravity.CENTER_HORIZONTAL;
        p.topMargin = Ui.dp(context, 8);
        super.addView(spinner, p);
    }

    public void setContent(View v) {
        if (content != null) removeView(content);
        content = v;
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        super.addView(v, 0, p);
    }

    public void setOnRefreshListener(Listener l) { listener = l; }

    private boolean canChildScrollUp() {
        return content != null && content.canScrollVertically(-1);
    }

    @Override public boolean onInterceptTouchEvent(MotionEvent e) {
        if (refreshing || content == null) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downY = e.getY(); dragging = false; break;
            case MotionEvent.ACTION_MOVE:
                float dy = e.getY() - downY;
                if (dy > Ui.dp(getContext(), 12) && !canChildScrollUp()) { dragging = true; return true; }
                break;
        }
        return false;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (refreshing || content == null) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downY = e.getY(); return true;
            case MotionEvent.ACTION_MOVE:
                float raw = Math.max(0, e.getY() - downY);
                float pull = Math.min(trigger * 1.35f, raw * .48f);
                dragging = pull > 0;
                content.setTranslationY(pull);
                spinner.setVisibility(VISIBLE);
                spinner.setAlpha(Math.min(1f, pull / trigger));
                spinner.setTranslationY(Math.max(0, pull - Ui.dp(getContext(), 44)));
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                float pulled = content.getTranslationY();
                if (dragging && pulled >= trigger && listener != null) {
                    refreshing = true;
                    content.animate().translationY(Ui.dp(getContext(), 52)).setDuration(160).start();
                    spinner.setVisibility(VISIBLE); spinner.setAlpha(1f); spinner.setTranslationY(Ui.dp(getContext(), 10));
                    listener.onRefresh(this);
                } else {
                    reset();
                }
                dragging = false;
                return true;
        }
        return false;
    }

    public void finishRefreshing() {
        refreshing = false;
        reset();
    }

    private void reset() {
        if (content != null) content.animate().translationY(0).setDuration(180).start();
        spinner.animate().alpha(0f).setDuration(150).withEndAction(() -> {
            if (!refreshing) { spinner.setVisibility(INVISIBLE); spinner.setAlpha(1f); spinner.setTranslationY(0); }
        }).start();
    }
}
