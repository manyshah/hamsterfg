package com.maniplus.notcoin;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class TutorialsController {
    private static final String TAB_HOME = "home";
    private static final String TAB_FAVORITES = "favorites";
    private static final String TAB_NEWS = "news";
    private static final int NEWS_PAGE = 10;

    private final MainActivity activity;
    private final ApiClient api;
    private final ImageLoader images;
    private final SharedPreferences prefs;
    private final String deviceId;
    private final Runnable initialReady;
    private final LinearLayout root;
    private final FrameLayout content;
    private final LinearLayout bottomNav;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private JSONArray categories = new JSONArray();
    private JSONArray tutorials = new JSONArray();
    private JSONArray sliders = new JSONArray();
    private JSONArray news = new JSONArray();
    private final Map<String, JSONObject> tutorialIndex = new HashMap<>();
    private final Map<String, JSONObject> categoryIndex = new HashMap<>();
    private final Map<String, JSONObject> newsIndex = new HashMap<>();
    private Set<String> favorites = new HashSet<>();
    private String activeTab = TAB_HOME;
    private boolean subPageOpen;
    private long lastLoadedAt;
    private boolean initialReadySent;
    private String contentVersion = "";

    private ScrollView newsScroll;
    private LinearLayout newsList;
    private LinearLayout newsFooter;
    private boolean newsLoading;
    private boolean newsHasMore = true;
    private int newsOffset;

    public TutorialsController(MainActivity activity, ApiClient api, ImageLoader images, String deviceId, Runnable initialReady) {
        this.activity = activity; this.api = api; this.images = images; this.deviceId = deviceId; this.initialReady = initialReady;
        this.prefs = activity.getSharedPreferences("hamster_education_v35", Context.MODE_PRIVATE);
        this.favorites = new HashSet<>(prefs.getStringSet("favorites", new HashSet<>()));
        loadCache(); indexData();

        root = Ui.vertical(activity); root.setBackgroundColor(Ui.BG);
        content = new FrameLayout(activity);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        bottomNav = buildBottomNav();
        root.addView(bottomNav, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 68)));

        if (hasContentCache()) {
            showTab(TAB_HOME); signalInitialReady(); syncBootstrap(false, null);
        } else {
            showInitialLoading(); syncBootstrap(true, null);
        }
    }

    public View view() { return root; }

    public void refreshIfNeeded() {
        if (SystemClock.elapsedRealtime() - lastLoadedAt > 60000) syncBootstrap(false, null);
    }

    public boolean goBack() {
        if (subPageOpen) { subPageOpen = false; showTab(activeTab); return true; }
        if (!TAB_HOME.equals(activeTab)) { showTab(TAB_HOME); return true; }
        return false;
    }

    private void signalInitialReady() {
        if (initialReadySent) return; initialReadySent = true; if (initialReady != null) initialReady.run();
    }

    private boolean hasContentCache() { return categories.length() > 0 || tutorials.length() > 0 || sliders.length() > 0; }

    private void loadCache() {
        try {
            String b = prefs.getString("bootstrap_cache", "");
            if (!b.isEmpty()) {
                JSONObject j = new JSONObject(b);
                categories = arr(j, "categories"); tutorials = arr(j, "tutorials"); sliders = arr(j, "sliders");
                contentVersion = j.optString("contentVersion", prefs.getString("content_version", ""));
            }
            String n = prefs.getString("news_cache", ""); if (!n.isEmpty()) news = new JSONArray(n);
        } catch (Exception ignored) {}
    }

    private JSONArray arr(JSONObject j, String k) { JSONArray a=j.optJSONArray(k); return a==null?new JSONArray():a; }

    private void indexData() {
        tutorialIndex.clear(); categoryIndex.clear(); newsIndex.clear();
        for(int i=0;i<tutorials.length();i++){JSONObject x=tutorials.optJSONObject(i);if(x!=null)tutorialIndex.put(x.optString("id"),x);}
        for(int i=0;i<categories.length();i++){JSONObject x=categories.optJSONObject(i);if(x!=null)categoryIndex.put(x.optString("id"),x);}
        for(int i=0;i<news.length();i++){JSONObject x=news.optJSONObject(i);if(x!=null)newsIndex.put(x.optString("id"),x);}
    }

    private LinearLayout buildBottomNav() {
        LinearLayout nav=Ui.horizontal(activity);nav.setGravity(Gravity.CENTER);nav.setPadding(Ui.dp(activity,8),Ui.dp(activity,7),Ui.dp(activity,8),Ui.dp(activity,7));nav.setBackground(Ui.bg(Color.WHITE,0,Ui.LINE,1,activity));
        nav.addView(navButton("⌂","خانه",TAB_HOME),Ui.lpWeight(1));
        nav.addView(navButton("♡","علاقه‌مندی",TAB_FAVORITES),Ui.lpWeight(1));
        nav.addView(navButton("▤","اخبار آنلاین",TAB_NEWS),Ui.lpWeight(1));
        return nav;
    }

    private View navButton(String icon,String label,String tab){LinearLayout b=Ui.vertical(activity);b.setGravity(Gravity.CENTER);TextView i=Ui.text(activity,icon,22,Ui.MUTED,true);i.setGravity(Gravity.CENTER);TextView t=Ui.text(activity,label,10.5f,Ui.MUTED,true);t.setGravity(Gravity.CENTER);b.addView(i);b.addView(t);b.setTag(tab);b.setOnClickListener(v->showTab(tab));return b;}

    private void updateBottomNav(){for(int i=0;i<bottomNav.getChildCount();i++){View v=bottomNav.getChildAt(i);boolean on=activeTab.equals(v.getTag());if(v instanceof LinearLayout){LinearLayout l=(LinearLayout)v;for(int j=0;j<l.getChildCount();j++)if(l.getChildAt(j) instanceof TextView)((TextView)l.getChildAt(j)).setTextColor(on?Ui.PRIMARY:Ui.MUTED);}}}

    private void showTab(String tab) {
        activeTab=tab;subPageOpen=false;updateBottomNav();content.removeAllViews();
        if (TAB_NEWS.equals(tab)) content.addView(buildNewsPage());
        else if (TAB_FAVORITES.equals(tab)) content.addView(buildFavoritesPage());
        else content.addView(buildHomePage());
    }

    private View buildHomePage(){
        ScrollView scroll=pageScroll();LinearLayout page=pageBody();
        page.addView(buildTopBar("آموزش همستر",true));
        if(activeSliderCount()>0) page.addView(buildSlider(),margin(16,8));
        page.addView(sectionHeader("دسته‌بندی‌ها","مشاهده همه",v->openAllCategories()),margin(18,6));page.addView(buildHomeCategories());
        page.addView(sectionHeader("آموزش‌های محبوب","مشاهده همه",v->openPopular()),margin(20,8));
        LinearLayout popular=Ui.vertical(activity);for(JSONObject t:popularTutorials(5))popular.addView(tutorialRow(t),margin(0,10));if(popular.getChildCount()==0)popular.addView(emptyState("هنوز آموزشی منتشر نشده است."));page.addView(popular);page.addView(space(22));scroll.addView(page);
        return pullWrap(scroll, l->syncBootstrap(true,l));
    }

    private LinearLayout buildTopBar(String title,boolean search){LinearLayout bar=Ui.horizontal(activity);bar.setPadding(Ui.dp(activity,6),Ui.dp(activity,10),Ui.dp(activity,6),Ui.dp(activity,4));TextView tv=Ui.text(activity,title,22,Ui.TEXT,true);bar.addView(tv,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));if(search){TextView s=circleAction("⌕");s.setOnClickListener(v->openSearch());bar.addView(s,new LinearLayout.LayoutParams(Ui.dp(activity,42),Ui.dp(activity,42)));}return bar;}

    private int activeSliderCount(){int n=0;for(int i=0;i<sliders.length();i++){JSONObject s=sliders.optJSONObject(i);if(s!=null&&s.optBoolean("active",true)&&!s.optString("image").isEmpty())n++;}return n;}

    private View buildSlider(){
        final List<JSONObject> items=new ArrayList<>();for(int i=0;i<sliders.length();i++){JSONObject s=sliders.optJSONObject(i);if(s!=null&&s.optBoolean("active",true)&&!s.optString("image").isEmpty())items.add(s);} 
        FrameLayout holder=new FrameLayout(activity);int h=Ui.dp(activity,150);holder.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,h));
        HorizontalScrollView hsv=new HorizontalScrollView(activity);hsv.setHorizontalScrollBarEnabled(false);hsv.setFillViewport(false);LinearLayout row=Ui.horizontal(activity);row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        int screen=activity.getResources().getDisplayMetrics().widthPixels;int cardW=screen-Ui.dp(activity,28);int gap=Ui.dp(activity,10);
        for(JSONObject s:items){ImageView iv=new ImageView(activity);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setBackground(Ui.bg(Ui.SURFACE_SOFT,20,Color.TRANSPARENT,0,activity));images.load(iv,ApiClient.absolute(s.optString("image")));iv.setOnClickListener(v->followTarget(s));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(cardW,h);p.setMargins(0,0,gap,0);row.addView(iv,p);}hsv.addView(row,new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,h));holder.addView(hsv,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,h));
        LinearLayout dots=Ui.horizontal(activity);dots.setGravity(Gravity.CENTER);FrameLayout.LayoutParams dp=new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,Ui.dp(activity,26));dp.gravity=Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL;dp.bottomMargin=Ui.dp(activity,6);holder.addView(dots,dp);
        final int[] current={0};Runnable paint=()->{dots.removeAllViews();for(int i=0;i<items.size();i++){View d=new View(activity);d.setBackground(Ui.bg(Color.argb(i==current[0]?255:130,255,255,255),99,Color.TRANSPARENT,0,activity));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(activity,i==current[0]?18:7),Ui.dp(activity,7));p.setMargins(Ui.dp(activity,3),0,Ui.dp(activity,3),0);dots.addView(d,p);}};paint.run();
        if(Build.VERSION.SDK_INT>=23)hsv.setOnScrollChangeListener((v,x,y,ox,oy)->{int idx=Math.max(0,Math.min(items.size()-1,Math.round((float)x/(cardW+gap))));if(idx!=current[0]){current[0]=idx;paint.run();}});
        hsv.setOnTouchListener((v,e)->{if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL){int idx=Math.max(0,Math.min(items.size()-1,Math.round((float)hsv.getScrollX()/(cardW+gap))));hsv.post(()->hsv.smoothScrollTo(idx*(cardW+gap),0));}return false;});
        return holder;
    }

    private View buildHomeCategories(){HorizontalScrollView hsv=new HorizontalScrollView(activity);hsv.setHorizontalScrollBarEnabled(false);LinearLayout row=Ui.horizontal(activity);row.setPadding(Ui.dp(activity,8),0,Ui.dp(activity,8),0);int added=0;for(int i=0;i<categories.length()&&added<4;i++){JSONObject c=categories.optJSONObject(i);if(!rootCategory(c))continue;row.addView(homeCategoryCard(c));added++;}hsv.addView(row,new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT));return hsv;}
    private boolean rootCategory(JSONObject c){return c!=null&&c.optBoolean("active",true)&&!c.optBoolean("deleted",false)&&c.optString("parentId").isEmpty();}
    private View homeCategoryCard(JSONObject c){LinearLayout card=Ui.vertical(activity);card.setGravity(Gravity.CENTER);card.setPadding(Ui.dp(activity,8),Ui.dp(activity,10),Ui.dp(activity,8),Ui.dp(activity,10));card.setBackground(Ui.bg(categoryTint(c.optString("id")),18,Color.TRANSPARENT,0,activity));card.addView(categoryVisual(c),new LinearLayout.LayoutParams(Ui.dp(activity,68),Ui.dp(activity,60)));TextView title=Ui.text(activity,c.optString("name"),10.5f,Ui.TEXT,true);title.setGravity(Gravity.CENTER);title.setMaxLines(2);card.addView(title,margin(7,0));card.setOnClickListener(v->openCategory(c));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(activity,112),Ui.dp(activity,124));p.setMargins(Ui.dp(activity,5),0,Ui.dp(activity,5),0);card.setLayoutParams(p);return card;}

    private LinearLayout sectionHeader(String title,String action,View.OnClickListener click){LinearLayout row=Ui.horizontal(activity);TextView t=Ui.text(activity,title,17,Ui.TEXT,true);row.addView(t,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));TextView a=Ui.text(activity,action,11,Ui.PRIMARY,true);a.setPadding(Ui.dp(activity,8),Ui.dp(activity,8),Ui.dp(activity,8),Ui.dp(activity,8));a.setOnClickListener(click);row.addView(a);return row;}

    private View tutorialRow(JSONObject t){LinearLayout card=Ui.horizontal(activity);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(Ui.dp(activity,10),Ui.dp(activity,10),Ui.dp(activity,10),Ui.dp(activity,10));card.setBackground(Ui.bg(Color.WHITE,19,Ui.LINE,1,activity));View image=coverVisual(t);card.addView(image,new LinearLayout.LayoutParams(Ui.dp(activity,112),Ui.dp(activity,78)));LinearLayout text=Ui.vertical(activity);text.setPadding(Ui.dp(activity,12),0,Ui.dp(activity,8),0);TextView title=Ui.text(activity,t.optString("title"),13.5f,Ui.TEXT,true);title.setMaxLines(2);text.addView(title);TextView summary=Ui.text(activity,t.optString("summary"),10.5f,Ui.MUTED,false);summary.setMaxLines(2);text.addView(summary,margin(4,5));LinearLayout meta=Ui.horizontal(activity);meta.addView(Ui.pill(activity,t.optString("level","مبتدی"),Ui.PRIMARY_DARK,Color.rgb(239,238,255)));Ui.gap(meta,activity,5);meta.addView(Ui.pill(activity,t.optInt("duration",5)+" دقیقه",Ui.MUTED,Ui.SURFACE_SOFT));text.addView(meta);card.addView(text,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));card.setOnClickListener(v->openTutorial(t));return card;}

    private List<JSONObject> popularTutorials(int limit){List<JSONObject> list=new ArrayList<>();for(int i=0;i<tutorials.length();i++){JSONObject t=tutorials.optJSONObject(i);if(t!=null&&t.optBoolean("active",true)&&!t.optBoolean("deleted",false))list.add(t);}Collections.sort(list,(a,b)->{int av=a.optInt("views",0)+(a.optBoolean("featured",false)?100000:0),bv=b.optInt("views",0)+(b.optBoolean("featured",false)?100000:0);return av==bv?Integer.compare(a.optInt("sortOrder",0),b.optInt("sortOrder",0)):Integer.compare(bv,av);});return list.subList(0,Math.min(limit,list.size()));}

    private void openAllCategories(){subPageOpen=true;content.removeAllViews();ScrollView scroll=pageScroll();LinearLayout page=pageBody();page.addView(backBar("همه دسته‌بندی‌ها"));TextView intro=Ui.text(activity,"موضوع موردنظرت را انتخاب کن؛ داخل هر دسته آموزش‌های ریز و مرحله‌به‌مرحله قرار دارد.",11.5f,Ui.MUTED,false);page.addView(intro,margin(4,14));GridLayout grid=new GridLayout(activity);grid.setColumnCount(2);for(int i=0;i<categories.length();i++){JSONObject c=categories.optJSONObject(i);if(!rootCategory(c))continue;View card=fullCategoryCard(c);GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(Ui.dp(activity,5),Ui.dp(activity,5),Ui.dp(activity,5),Ui.dp(activity,5));grid.addView(card,p);}page.addView(grid);page.addView(space(24));scroll.addView(page);content.addView(pullWrap(scroll,l->syncBootstrap(true,l)));}

    private View fullCategoryCard(JSONObject c){LinearLayout card=Ui.vertical(activity);card.setPadding(Ui.dp(activity,10),Ui.dp(activity,10),Ui.dp(activity,10),Ui.dp(activity,14));card.setBackground(Ui.bg(Color.WHITE,20,Ui.LINE,1,activity));card.addView(categoryBanner(c),new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,120)));TextView t=Ui.text(activity,c.optString("name"),15,Ui.TEXT,true);card.addView(t,margin(10,2));TextView d=Ui.text(activity,c.optString("description"),10.5f,Ui.MUTED,false);d.setMaxLines(3);card.addView(d);card.setOnClickListener(v->openCategory(c));return card;}

    private void openCategory(JSONObject category){subPageOpen=true;content.removeAllViews();ScrollView scroll=pageScroll();LinearLayout page=pageBody();page.addView(backBar(category.optString("name")));page.addView(categoryBanner(category),new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,150)));TextView d=Ui.text(activity,category.optString("description"),11.5f,Ui.MUTED,false);page.addView(d,margin(10,12));int n=0;for(int i=0;i<tutorials.length();i++){JSONObject t=tutorials.optJSONObject(i);if(t!=null&&t.optBoolean("active",true)&&category.optString("id").equals(t.optString("categoryId"))){page.addView(tutorialRow(t),margin(0,9));n++;}}if(n==0)page.addView(emptyState("هنوز آموزشی در این دسته منتشر نشده است."));scroll.addView(page);content.addView(pullWrap(scroll,l->syncBootstrap(true,l)));}

    private void openPopular(){subPageOpen=true;content.removeAllViews();ScrollView scroll=pageScroll();LinearLayout page=pageBody();page.addView(backBar("آموزش‌های محبوب"));for(JSONObject t:popularTutorials(50))page.addView(tutorialRow(t),margin(0,9));scroll.addView(page);content.addView(pullWrap(scroll,l->syncBootstrap(true,l)));}

    private View buildFavoritesPage(){ScrollView scroll=pageScroll();LinearLayout page=pageBody();page.addView(buildTopBar("علاقه‌مندی‌ها",false));int n=0;for(String id:new HashSet<>(favorites)){JSONObject t=tutorialIndex.get(id);if(t!=null){page.addView(tutorialRow(t),margin(0,9));n++;}}if(n==0)page.addView(emptyState("هنوز آموزشی ذخیره نکرده‌ای."),margin(16,0));scroll.addView(page);return pullWrap(scroll,l->syncBootstrap(true,l));}

    private View buildNewsPage(){
        PullRefreshLayout pull=new PullRefreshLayout(activity);LinearLayout shell=Ui.vertical(activity);shell.setBackgroundColor(Ui.BG);shell.addView(buildTopBar("اخبار آنلاین",false));
        newsScroll=pageScroll();LinearLayout page=pageBody();newsList=Ui.vertical(activity);page.addView(newsList);newsFooter=Ui.vertical(activity);newsFooter.setGravity(Gravity.CENTER);page.addView(newsFooter,margin(10,18));newsScroll.addView(page);shell.addView(newsScroll,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f));pull.setContent(shell);pull.setOnRefreshListener(l->loadNews(true,l));
        attachNewsBottomListener();
        if(ApiClient.isOnline(activity)){showNewsInitialLoading();handler.post(()->loadNews(true,null));}
        else if(news.length()>0){renderCachedNews();activity.toast("اتصال اینترنت برقرار نیست؛ آخرین اخبار ذخیره‌شده نمایش داده شد");}
        else showNewsError("برای دریافت اخبار، اتصال اینترنت را فعال کنید.");
        return pull;
    }

    private void attachNewsBottomListener(){Runnable check=()->{if(newsScroll==null||newsLoading||!newsHasMore)return;View child=newsScroll.getChildAt(0);if(child!=null&&newsScroll.getScrollY()+newsScroll.getHeight()>=child.getHeight()-Ui.dp(activity,180))loadNews(false,null);};if(Build.VERSION.SDK_INT>=23)newsScroll.setOnScrollChangeListener((v,x,y,ox,oy)->check.run());else newsScroll.getViewTreeObserver().addOnScrollChangedListener(check::run);}

    private void showNewsInitialLoading(){newsList.removeAllViews();LinearLayout box=Ui.vertical(activity);box.setGravity(Gravity.CENTER);ProgressBar p=new ProgressBar(activity);box.addView(p,new LinearLayout.LayoutParams(Ui.dp(activity,44),Ui.dp(activity,44)));TextView t=Ui.text(activity,"در حال دریافت تازه‌ترین اخبار…",11.5f,Ui.MUTED,false);t.setGravity(Gravity.CENTER);box.addView(t,margin(8,0));newsList.addView(box,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,260)));newsFooter.removeAllViews();}
    private void showNewsError(String msg){newsList.removeAllViews();LinearLayout box=Ui.vertical(activity);box.setGravity(Gravity.CENTER);TextView t=emptyState(msg+"\nصفحه را به پایین بکش و دوباره رها کن.");box.addView(t);newsList.addView(box,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,260)));newsFooter.removeAllViews();}
    private void renderCachedNews(){newsList.removeAllViews();for(int i=0;i<news.length();i++){JSONObject n=news.optJSONObject(i);if(n!=null)newsList.addView(newsRow(n),margin(0,12));}newsOffset=news.length();newsHasMore=true;updateNewsFooter(false);}

    private void loadNews(boolean reset, PullRefreshLayout pull){
        if(newsLoading){if(pull!=null)pull.finishRefreshing();return;}if(!ApiClient.isOnline(activity)){if(pull!=null)pull.finishRefreshing();if(news.length()==0)showNewsError("برای دریافت اخبار، اتصال اینترنت را فعال کنید.");else activity.toast("اتصال اینترنت برقرار نیست");return;}
        newsLoading=true;if(!reset)updateNewsFooter(true);JSONObject b=new JSONObject();try{b.put("limit",NEWS_PAGE);b.put("offset",reset?0:newsOffset);}catch(Exception ignored){}
        api.post("app.php?action=news",b,null,new ApiClient.Callback(){@Override public void ok(JSONObject j){JSONArray got=j.optJSONArray("news");if(got==null)got=new JSONArray();if(reset){news=new JSONArray();newsOffset=0;newsList.removeAllViews();}Set<String> ids=new HashSet<>();for(int i=0;i<news.length();i++){JSONObject x=news.optJSONObject(i);if(x!=null)ids.add(x.optString("id"));}for(int i=0;i<got.length();i++){JSONObject x=got.optJSONObject(i);if(x!=null&&!ids.contains(x.optString("id"))){news.put(x);ids.add(x.optString("id"));newsList.addView(newsRow(x),margin(0,12));}}newsOffset=news.length();newsHasMore=j.optBoolean("hasMore",false);prefs.edit().putString("news_cache",news.toString()).apply();indexData();newsLoading=false;updateNewsFooter(false);if(pull!=null)pull.finishRefreshing();if(reset&&news.length()==0)showNewsError("هنوز خبری منتشر نشده است.");}@Override public void fail(String m){newsLoading=false;if(pull!=null)pull.finishRefreshing();if(reset&&news.length()>0){renderCachedNews();activity.toast("به‌روزرسانی اخبار انجام نشد");}else if(reset)showNewsError("دریافت اخبار انجام نشد. اینترنت را بررسی کن.");else updateNewsFooter(false);}});
    }

    private void updateNewsFooter(boolean loading){newsFooter.removeAllViews();if(loading){ProgressBar p=new ProgressBar(activity);newsFooter.addView(p,new LinearLayout.LayoutParams(Ui.dp(activity,32),Ui.dp(activity,32)));TextView t=Ui.text(activity,"در حال بارگذاری خبرهای قدیمی‌تر…",10.5f,Ui.MUTED,false);t.setGravity(Gravity.CENTER);newsFooter.addView(t,margin(5,0));}else if(!newsHasMore&&news.length()>0){TextView t=Ui.text(activity,"به انتهای اخبار رسیدید",10.5f,Ui.MUTED2,false);t.setGravity(Gravity.CENTER);newsFooter.addView(t);}}

    private View newsRow(JSONObject n){LinearLayout card=Ui.vertical(activity);card.setBackground(Ui.bg(Color.WHITE,20,Ui.LINE,1,activity));card.setPadding(Ui.dp(activity,10),Ui.dp(activity,10),Ui.dp(activity,10),Ui.dp(activity,12));View image=newsVisual(n);card.addView(image,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,150)));TextView title=Ui.text(activity,n.optString("title"),15,Ui.TEXT,true);title.setMaxLines(2);card.addView(title,margin(10,4));TextView sum=Ui.text(activity,n.optString("summary"),11,Ui.MUTED,false);sum.setMaxLines(3);card.addView(sum);TextView date=Ui.text(activity,n.optString("publishedAt"),9.5f,Ui.MUTED2,false);card.addView(date,margin(7,0));card.setOnClickListener(v->openNews(n));return card;}

    private void openTutorial(JSONObject summary){subPageOpen=true;content.removeAllViews();content.addView(loadingPage("در حال دریافت آموزش…"));JSONObject b=json("id",summary.optString("id"));api.post("app.php?action=tutorial",b,null,new ApiClient.Callback(){@Override public void ok(JSONObject j){JSONObject t=j.optJSONObject("tutorial");if(t!=null){tutorialIndex.put(t.optString("id"),t);showTutorialDetail(t);trackView("tutorial",t.optString("id"));}}@Override public void fail(String m){JSONObject cached=tutorialIndex.get(summary.optString("id"));if(cached!=null&&!cached.optString("body").isEmpty())showTutorialDetail(cached);else showSubError("دریافت آموزش انجام نشد.");}});}

    private void showTutorialDetail(JSONObject t){content.removeAllViews();ScrollView scroll=pageScroll();LinearLayout page=pageBody();LinearLayout bar=backBar(t.optString("title"));TextView fav=circleAction(favorites.contains(t.optString("id"))?"♥":"♡");fav.setOnClickListener(v->{toggleFavorite(t.optString("id"));fav.setText(favorites.contains(t.optString("id"))?"♥":"♡");});bar.addView(fav,0,new LinearLayout.LayoutParams(Ui.dp(activity,42),Ui.dp(activity,42)));page.addView(bar);page.addView(detailCover(t),margin(8,12));TextView title=Ui.text(activity,t.optString("title"),21,Ui.TEXT,true);page.addView(title);TextView meta=Ui.text(activity,(categoryIndex.get(t.optString("categoryId"))==null?"":categoryIndex.get(t.optString("categoryId")).optString("name")+" · ")+t.optString("level","مبتدی")+" · "+t.optInt("duration",0)+" دقیقه",10.5f,Ui.MUTED,false);page.addView(meta,margin(7,14));TextView body=Ui.text(activity,t.optString("body",t.optString("summary")),13,Ui.TEXT,false);body.setLineSpacing(Ui.dp(activity,5),1.45f);page.addView(body);String src=t.optString("sourceUrl");if(!src.isEmpty()){TextView b=Ui.pill(activity,"مشاهده منبع",Ui.PRIMARY,Color.WHITE);b.setPadding(Ui.dp(activity,16),Ui.dp(activity,14),Ui.dp(activity,16),Ui.dp(activity,14));b.setOnClickListener(v->openUrl(src));page.addView(b,margin(18,20));}scroll.addView(page);content.addView(scroll);}

    private void openNews(JSONObject summary){subPageOpen=true;content.removeAllViews();content.addView(loadingPage("در حال دریافت خبر…"));api.post("app.php?action=news_detail",json("id",summary.optString("id")),null,new ApiClient.Callback(){@Override public void ok(JSONObject j){JSONObject n=j.optJSONObject("news");if(n!=null){newsIndex.put(n.optString("id"),n);showNewsDetail(n);trackView("news",n.optString("id"));}}@Override public void fail(String m){JSONObject cached=newsIndex.get(summary.optString("id"));if(cached!=null&&!cached.optString("body").isEmpty())showNewsDetail(cached);else showSubError("دریافت خبر انجام نشد.");}});}

    private void showNewsDetail(JSONObject n){content.removeAllViews();ScrollView scroll=pageScroll();LinearLayout page=pageBody();page.addView(backBar("خبر"));View cover=newsVisual(n);page.addView(cover,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,190)));TextView title=Ui.text(activity,n.optString("title"),21,Ui.TEXT,true);page.addView(title,margin(16,5));TextView date=Ui.text(activity,n.optString("publishedAt"),10,Ui.MUTED2,false);page.addView(date,margin(0,14));TextView body=Ui.text(activity,n.optString("body",n.optString("summary")),13,Ui.TEXT,false);body.setLineSpacing(Ui.dp(activity,5),1.45f);page.addView(body);String src=n.optString("sourceUrl");if(!src.isEmpty()){TextView b=Ui.pill(activity,"مشاهده منبع",Ui.PRIMARY,Color.WHITE);b.setPadding(Ui.dp(activity,16),Ui.dp(activity,14),Ui.dp(activity,16),Ui.dp(activity,14));b.setOnClickListener(v->openUrl(src));page.addView(b,margin(18,20));}scroll.addView(page);content.addView(scroll);}

    private void openSearch(){subPageOpen=true;content.removeAllViews();LinearLayout shell=Ui.vertical(activity);shell.setPadding(Ui.dp(activity,14),Ui.dp(activity,8),Ui.dp(activity,14),Ui.dp(activity,10));shell.addView(backBar("جستجوی آموزش"));EditText q=new EditText(activity);q.setHint("موضوع موردنظر را بنویس…");q.setSingleLine(true);q.setTextSize(13);q.setBackground(Ui.bg(Color.WHITE,18,Ui.LINE,1,activity));q.setPadding(Ui.dp(activity,14),0,Ui.dp(activity,14),0);shell.addView(q,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,52)));ScrollView scroll=pageScroll();LinearLayout results=Ui.vertical(activity);results.setPadding(0,Ui.dp(activity,12),0,Ui.dp(activity,20));scroll.addView(results);shell.addView(scroll,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f));Runnable render=()->{String needle=q.getText().toString().trim().toLowerCase();results.removeAllViews();int added=0;for(int i=0;i<tutorials.length();i++){JSONObject t=tutorials.optJSONObject(i);if(t==null||!t.optBoolean("active",true))continue;String hay=(t.optString("title")+" "+t.optString("summary")+" "+String.valueOf(t.optJSONArray("tags"))).toLowerCase();if(needle.isEmpty()||hay.contains(needle)){results.addView(tutorialRow(t),margin(0,8));added++;}}if(added==0)results.addView(emptyState("نتیجه‌ای پیدا نشد."));};q.addTextChangedListener(new TextWatcher(){@Override public void beforeTextChanged(CharSequence s,int st,int c,int a){}@Override public void onTextChanged(CharSequence s,int st,int b,int c){render.run();}@Override public void afterTextChanged(Editable e){}});render.run();content.addView(shell);}

    private void toggleFavorite(String id){if(favorites.contains(id))favorites.remove(id);else favorites.add(id);prefs.edit().putStringSet("favorites",new HashSet<>(favorites)).apply();activity.toast(favorites.contains(id)?"به علاقه‌مندی‌ها اضافه شد":"از علاقه‌مندی‌ها حذف شد");}

    private void followTarget(JSONObject s){String type=s.optString("targetType"),value=s.optString("targetValue");if(value.isEmpty())value=s.optString("link");if("tutorial".equals(type)&&tutorialIndex.containsKey(value))openTutorial(tutorialIndex.get(value));else if("category".equals(type)&&categoryIndex.containsKey(value))openCategory(categoryIndex.get(value));else if("news".equals(type)&&newsIndex.containsKey(value))openNews(newsIndex.get(value));else if("url".equals(type)||value.startsWith("http"))openUrl(value);}

    private void syncBootstrap(boolean force, PullRefreshLayout pull){
        if(!ApiClient.isOnline(activity)){if(pull!=null)pull.finishRefreshing();if(!hasContentCache()){showOfflineFirstRun();signalInitialReady();}else activity.toast("اتصال اینترنت برقرار نیست");return;}
        api.post("app.php?action=config",new JSONObject(),null,new ApiClient.Callback(){@Override public void ok(JSONObject cfg){String remote=cfg.optString("contentVersion");if(!force&&hasContentCache()&&!remote.isEmpty()&&remote.equals(contentVersion)){lastLoadedAt=SystemClock.elapsedRealtime();if(pull!=null)pull.finishRefreshing();signalInitialReady();return;}fetchBootstrap(remote,pull);}@Override public void fail(String m){if(pull!=null)pull.finishRefreshing();if(!hasContentCache()){showOfflineFirstRun();signalInitialReady();}else activity.toast("به‌روزرسانی انجام نشد");}});
    }

    private void fetchBootstrap(String remoteVersion,PullRefreshLayout pull){api.post("app.php?action=bootstrap",new JSONObject(),null,new ApiClient.Callback(){@Override public void ok(JSONObject j){JSONArray c=j.optJSONArray("categories"),t=j.optJSONArray("tutorials"),s=j.optJSONArray("sliders");categories=c==null?new JSONArray():c;tutorials=t==null?new JSONArray():t;sliders=s==null?new JSONArray():s;contentVersion=j.optString("contentVersion",remoteVersion);JSONObject cache=new JSONObject();try{cache.put("categories",categories);cache.put("tutorials",tutorials);cache.put("sliders",sliders);cache.put("contentVersion",contentVersion);}catch(Exception ignored){}prefs.edit().putString("bootstrap_cache",cache.toString()).putString("content_version",contentVersion).apply();indexData();lastLoadedAt=SystemClock.elapsedRealtime();if(pull!=null)pull.finishRefreshing();if(!subPageOpen)showTab(activeTab);signalInitialReady();}@Override public void fail(String m){if(pull!=null)pull.finishRefreshing();if(!hasContentCache()){showOfflineFirstRun();signalInitialReady();}else activity.toast("به‌روزرسانی انجام نشد");}});}

    private void showInitialLoading(){content.removeAllViews();content.addView(loadingPage("در حال دریافت اطلاعات اولیه…"));}
    private View loadingPage(String text){LinearLayout box=Ui.vertical(activity);box.setGravity(Gravity.CENTER);box.setBackgroundColor(Ui.BG);ProgressBar p=new ProgressBar(activity);box.addView(p,new LinearLayout.LayoutParams(Ui.dp(activity,46),Ui.dp(activity,46)));TextView t=Ui.text(activity,text,12,Ui.MUTED,false);t.setGravity(Gravity.CENTER);box.addView(t,margin(10,0));return box;}
    private void showOfflineFirstRun(){content.removeAllViews();LinearLayout box=Ui.vertical(activity);box.setGravity(Gravity.CENTER);box.setPadding(Ui.dp(activity,26),Ui.dp(activity,26),Ui.dp(activity,26),Ui.dp(activity,26));TextView title=Ui.text(activity,"اتصال اینترنت لازم است",20,Ui.TEXT,true);title.setGravity(Gravity.CENTER);TextView text=Ui.text(activity,"برای دریافت اطلاعات اولیه، اتصال اینترنت را فعال کنید.\nبعد صفحه را به پایین بکشید یا برنامه را دوباره باز کنید.",12,Ui.MUTED,false);text.setGravity(Gravity.CENTER);box.addView(title);box.addView(text,margin(10,0));PullRefreshLayout p=new PullRefreshLayout(activity);p.setContent(box);p.setOnRefreshListener(l->syncBootstrap(true,l));content.addView(p);}
    private void showSubError(String text){content.removeAllViews();LinearLayout box=Ui.vertical(activity);box.setPadding(Ui.dp(activity,14),Ui.dp(activity,8),Ui.dp(activity,14),Ui.dp(activity,14));box.addView(backBar("خطا"));box.addView(emptyState(text),margin(16,0));content.addView(box);}

    private void trackView(String type,String id){JSONObject b=new JSONObject();try{b.put("type",type);b.put("id",id);b.put("deviceId",deviceId);}catch(Exception ignored){}api.post("app.php?action=view",b,null,new ApiClient.Callback(){@Override public void ok(JSONObject j){}@Override public void fail(String m){}});}

    private PullRefreshLayout pullWrap(View child, PullRefreshLayout.Listener l){PullRefreshLayout p=new PullRefreshLayout(activity);p.setContent(child);p.setOnRefreshListener(l);return p;}
    private LinearLayout backBar(String title){LinearLayout bar=Ui.horizontal(activity);bar.setPadding(0,Ui.dp(activity,4),0,Ui.dp(activity,8));TextView back=circleAction("‹");back.setTextSize(30);back.setOnClickListener(v->{subPageOpen=false;showTab(activeTab);});bar.addView(back,new LinearLayout.LayoutParams(Ui.dp(activity,42),Ui.dp(activity,42)));TextView t=Ui.text(activity,title,18,Ui.TEXT,true);t.setMaxLines(1);bar.addView(t,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));return bar;}
    private TextView circleAction(String txt){TextView v=Ui.text(activity,txt,22,Ui.PRIMARY,true);v.setGravity(Gravity.CENTER);v.setBackground(Ui.bg(Color.WHITE,99,Ui.LINE,1,activity));return v;}

    private View categoryVisual(JSONObject c){String image=ApiClient.absolute(c.optString("image"));if(!image.isEmpty()){ImageView iv=new ImageView(activity);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setBackground(Ui.bg(Color.WHITE,16,Color.TRANSPARENT,0,activity));images.load(iv,image);return iv;}TextView tv=Ui.text(activity,c.optString("icon","📘"),26,Ui.PRIMARY,false);tv.setGravity(Gravity.CENTER);tv.setBackground(Ui.bg(Color.argb(35,80,73,224),16,Color.TRANSPARENT,0,activity));return tv;}
    private View categoryBanner(JSONObject c){FrameLayout f=new FrameLayout(activity);f.setBackground(Ui.bg(categoryTint(c.optString("id")),20,Color.TRANSPARENT,0,activity));String image=ApiClient.absolute(c.optString("image"));if(!image.isEmpty()){ImageView iv=new ImageView(activity);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);images.load(iv,image);f.addView(iv,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));}else{TextView icon=Ui.text(activity,c.optString("icon","📘"),42,Ui.PRIMARY,false);icon.setGravity(Gravity.CENTER);f.addView(icon,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));}return f;}
    private int categoryTint(String id){int[] colors={Color.rgb(239,235,255),Color.rgb(232,244,255),Color.rgb(231,249,243),Color.rgb(255,244,225),Color.rgb(255,235,240),Color.rgb(236,240,255)};return colors[Math.abs(id.hashCode())%colors.length];}
    private View coverVisual(JSONObject t){String cover=ApiClient.absolute(t.optString("cover"));if(!cover.isEmpty()){ImageView iv=new ImageView(activity);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setBackground(Ui.bg(Ui.SURFACE_SOFT,16,Color.TRANSPARENT,0,activity));images.load(iv,cover);return iv;}JSONObject c=categoryIndex.get(t.optString("categoryId"));return c==null?fallbackVisual("📚"):categoryVisual(c);}
    private View newsVisual(JSONObject n){String cover=ApiClient.absolute(n.optString("cover"));if(!cover.isEmpty()){ImageView iv=new ImageView(activity);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setBackground(Ui.bg(Ui.SURFACE_SOFT,16,Color.TRANSPARENT,0,activity));images.load(iv,cover);return iv;}return fallbackVisual("📰");}
    private View fallbackVisual(String icon){FrameLayout f=new FrameLayout(activity);f.setBackground(Ui.gradient(Color.rgb(230,239,255),Color.rgb(241,236,255),16,Color.TRANSPARENT,0,activity));TextView i=Ui.text(activity,icon,30,Ui.PRIMARY,false);i.setGravity(Gravity.CENTER);f.addView(i,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));return f;}
    private View detailCover(JSONObject t){String cover=ApiClient.absolute(t.optString("cover"));FrameLayout f=new FrameLayout(activity);f.setBackground(Ui.SURFACE_SOFT==0?null:Ui.bg(Ui.SURFACE_SOFT,20,Color.TRANSPARENT,0,activity));if(!cover.isEmpty()){ImageView iv=new ImageView(activity);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);images.load(iv,cover);f.addView(iv,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));}else{JSONObject c=categoryIndex.get(t.optString("categoryId"));View v=c==null?fallbackVisual("🎓"):categoryVisual(c);f.addView(v,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));}f.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,190)));return f;}

    private TextView emptyState(String text){TextView e=Ui.text(activity,text,12,Ui.MUTED,false);e.setGravity(Gravity.CENTER);e.setPadding(Ui.dp(activity,16),Ui.dp(activity,32),Ui.dp(activity,16),Ui.dp(activity,32));e.setBackground(Ui.bg(Color.WHITE,18,Ui.LINE,1,activity));return e;}
    private ScrollView pageScroll(){ScrollView s=new ScrollView(activity);s.setFillViewport(true);s.setClipToPadding(false);s.setBackgroundColor(Ui.BG);return s;}
    private LinearLayout pageBody(){LinearLayout p=Ui.vertical(activity);p.setPadding(Ui.dp(activity,14),Ui.dp(activity,6),Ui.dp(activity,14),Ui.dp(activity,12));return p;}
    private View space(int dp){View v=new View(activity);v.setLayoutParams(new LinearLayout.LayoutParams(1,Ui.dp(activity,dp)));return v;}
    private LinearLayout.LayoutParams margin(int top,int bottom){return Ui.lpMatchWrap(activity,top,bottom);}
    private JSONObject json(String key,Object value){JSONObject j=new JSONObject();try{j.put(key,value);}catch(Exception ignored){}return j;}
    private void openUrl(String url){try{activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}catch(Exception e){activity.toast("بازکردن لینک ممکن نشد");}}
}
