package com.maniplus.notcoin;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ImageLoader {
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final File diskDir;
    private final LruCache<String, Bitmap> memory = new LruCache<String, Bitmap>(20 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getByteCount(); }
    };

    public ImageLoader(Context context) {
        diskDir = new File(context.getCacheDir(), "remote_images_v2");
        if (!diskDir.exists()) diskDir.mkdirs();
    }

    public void load(ImageView target, String url) {
        if (url == null || url.trim().isEmpty()) return;
        Bitmap b = memory.get(url);
        if (b != null) { target.setImageBitmap(b); return; }
        target.setTag(url);
        pool.execute(() -> {
            Bitmap found = readDisk(url);
            if (found == null) found = download(url);
            if (found != null) {
                memory.put(url, found);
                Bitmap out = found;
                main.post(() -> { if (url.equals(target.getTag())) target.setImageBitmap(out); });
            }
        });
    }

    private Bitmap readDisk(String url) {
        File f = new File(diskDir, key(url) + ".img");
        if (!f.isFile()) return null;
        try (InputStream in = new FileInputStream(f)) { return BitmapFactory.decodeStream(in); }
        catch (Exception e) { return null; }
    }

    private Bitmap download(String url) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection)new URL(url).openConnection();
            c.setConnectTimeout(10000); c.setReadTimeout(18000); c.setDoInput(true); c.connect();
            try (InputStream in = c.getInputStream()) {
                byte[] data = readAll(in);
                Bitmap b = BitmapFactory.decodeByteArray(data, 0, data.length);
                if (b != null) try (FileOutputStream out = new FileOutputStream(new File(diskDir, key(url)+".img"))) { out.write(data); }
                return b;
            }
        } catch (Exception e) { return null; }
        finally { if (c != null) c.disconnect(); }
    }

    private byte[] readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream(); byte[] buf = new byte[8192]; int n;
        while ((n=in.read(buf))>0) out.write(buf,0,n); return out.toByteArray();
    }

    private String key(String s) {
        try { MessageDigest md=MessageDigest.getInstance("SHA-256"); byte[] d=md.digest(s.getBytes(java.nio.charset.StandardCharsets.UTF_8)); StringBuilder b=new StringBuilder(); for(byte x:d)b.append(String.format("%02x",x)); return b.toString(); }
        catch(Exception e){ return Integer.toHexString(s.hashCode()); }
    }
}
