package com.maniplus.notcoin;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.UUID;

public class MainActivity extends Activity {
    private final ApiClient api = new ApiClient();
    private ImageLoader images;
    private TutorialsController controller;
    private FrameLayout root;
    private View splash;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String deviceId;
    private boolean firstPresence = true;
    private final Runnable heartbeat = new Runnable() {
        @Override public void run() { sendPresence(firstPresence ? "open" : "heartbeat"); firstPresence = false; handler.postDelayed(this, 60000); }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        styleSystemBars();
        images = new ImageLoader(this);
        deviceId = getSharedPreferences("hamster_education_device", MODE_PRIVATE).getString("device_id", "");
        if (deviceId.isEmpty()) {
            deviceId = UUID.randomUUID().toString();
            getSharedPreferences("hamster_education_device", MODE_PRIVATE).edit().putString("device_id", deviceId).apply();
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        setContentView(root);
        applyInsets(root);

        splash = buildSplash();
        root.addView(splash, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        controller = new TutorialsController(this, api, images, deviceId, this::hideSplash);
        root.addView(controller.view(), 0, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void styleSystemBars() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 21) {
            w.setStatusBarColor(Color.WHITE);
            w.setNavigationBarColor(Color.WHITE);
        }
        if (Build.VERSION.SDK_INT >= 23) {
            int flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            w.getDecorView().setSystemUiVisibility(flags);
        }
    }

    private void applyInsets(View target) {
        if (Build.VERSION.SDK_INT >= 35) {
            target.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                v.setPadding(0, bars.top, 0, bars.bottom);
                return insets;
            });
        }
    }

    private View buildSplash() {
        FrameLayout f = new FrameLayout(this); f.setBackgroundColor(Color.WHITE);
        LinearLayout box = Ui.vertical(this); box.setGravity(Gravity.CENTER); box.setPadding(Ui.dp(this, 32), Ui.dp(this, 32), Ui.dp(this, 32), Ui.dp(this, 32));
        ImageView icon = new ImageView(this); icon.setImageResource(R.drawable.app_icon); icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        box.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this, 118), Ui.dp(this, 118)));
        TextView title = Ui.text(this, "آموزش همستر", 24, Ui.TEXT, true); title.setGravity(Gravity.CENTER);
        TextView sub = Ui.text(this, "راهنمای فارسی و آنلاین", 11.5f, Ui.MUTED, false); sub.setGravity(Gravity.CENTER);
        box.addView(title, Ui.lpMatchWrap(this, 14, 4)); box.addView(sub);
        f.addView(box, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return f;
    }

    private void hideSplash() {
        if (splash == null) return;
        splash.animate().alpha(0f).setDuration(220).withEndAction(() -> {
            if (splash != null && splash.getParent() instanceof ViewGroup) ((ViewGroup)splash.getParent()).removeView(splash);
            splash = null;
        }).start();
    }

    public String deviceId() { return deviceId; }

    private void sendPresence(String event) {
        JSONObject body = new JSONObject();
        try { body.put("deviceId", deviceId); body.put("version", "3.2.0"); body.put("event", event); } catch (Exception ignored) {}
        api.post("app.php?action=presence", body, null, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) {}
            @Override public void fail(String message) {}
        });
    }

    public void toast(String s) { android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show(); }

    @Override public void onBackPressed() {
        if (controller != null && controller.goBack()) return;
        super.onBackPressed();
    }

    @Override protected void onResume() {
        super.onResume();
        if (controller != null) controller.refreshIfNeeded();
        handler.removeCallbacks(heartbeat); handler.post(heartbeat);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(heartbeat);
        super.onPause();
    }
}
