package com.maniplus.notcoin;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public final class SeedData {
    private SeedData() {}

    public static JSONObject load(Context context) {
        try (InputStream in = context.getAssets().open("education_seed_v34.json");
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return new JSONObject(out.toString(StandardCharsets.UTF_8.name()));
        } catch (Exception ignored) {
            JSONObject empty = new JSONObject();
            try {
                empty.put("categories", new JSONArray());
                empty.put("tutorials", new JSONArray());
            } catch (Exception ignored2) {}
            return empty;
        }
    }
}
