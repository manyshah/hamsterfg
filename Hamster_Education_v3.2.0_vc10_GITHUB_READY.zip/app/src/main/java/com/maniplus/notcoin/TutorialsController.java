package com.maniplus.notcoin;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ViewFlipper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class TutorialsController {
    private static final String TAB_HOME = "home";
    private static final String TAB_FAVORITES = "favorites";
    private static final String TAB_NEWS = "news";

    private final MainActivity activity;
    private final ApiClient api;
    private final ImageLoader images;
    private final SharedPreferences prefs;
    private final FrameLayout content;
    private final LinearLayout root;
    private final LinearLayout bottomNav;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private JSONArray categories = new JSONArray();
    private JSONArray tutorials = new JSONArray();
    private JSONArray sliders = new JSONArray();
    private JSONArray news = new JSONArray();
    private final Map<String, JSONObject> seedTutorials = new HashMap<>();
    private final Map<String, JSONObject> tutorialIndex = new HashMap<>();
    private final Map<String, JSONObject> categoryIndex = new HashMap<>();
    private final Map<String, JSONObject> newsIndex = new HashMap<>();
    private Set<String> favorites = new HashSet<>();
    private String activeTab = TAB_HOME;
    private boolean subPageOpen = false;
    private long lastLoadedAt = 0;
    private Runnable sliderTicker;

    public TutorialsController(MainActivity activity, ApiClient api, ImageLoader images) {
        this.activity = activity;
        this.api = api;
        this.images = images;
        this.prefs = activity.getSharedPreferences("hamster_education_v34", Context.MODE_PRIVATE);

        JSONObject seed = SeedData.load(activity);
        JSONArray seedCats = seed.optJSONArray("categories");
        JSONArray seedTuts = seed.optJSONArray("tutorials");
        categories = seedCats == null ? new JSONArray() : seedCats;
        tutorials = seedTuts == null ? new JSONArray() : seedTuts;
        for (int i = 0; i < tutorials.length(); i++) {
            JSONObject t = tutorials.optJSONObject(i);
            if (t != null) seedTutorials.put(t.optString("id"), t);
        }
        favorites = new HashSet<>(prefs.getStringSet("favorites", new HashSet<>()));
        loadCaches();
        indexData();

        root = Ui.vertical(activity);
        root.setBackgroundColor(Ui.BG);

        content = new FrameLayout(activity);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        bottomNav = buildBottomNav();
        root.addView(bottomNav, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 68)));

        showTab(TAB_HOME);
        refreshRemote();
    }

    public View view() { return root; }

    public void refreshIfNeeded() {
        if (SystemClock.elapsedRealtime() - lastLoadedAt > 60000) refreshRemote();
    }

    public boolean goBack() {
        if (subPageOpen) {
            subPageOpen = false;
            showTab(activeTab);
            return true;
        }
        if (!TAB_HOME.equals(activeTab)) {
            showTab(TAB_HOME);
            return true;
        }
        return false;
    }

    private void loadCaches() {
        try {
            String c = prefs.getString("categories_cache", "");
            String t = prefs.getString("tutorials_cache", "");
            String s = prefs.getString("sliders_cache", "");
            String n = prefs.getString("news_cache", "");
            if (!c.isEmpty()) categories = new JSONArray(c);
            if (!t.isEmpty()) tutorials = new JSONArray(t);
            if (!s.isEmpty()) sliders = new JSONArray(s);
            if (!n.isEmpty()) news = new JSONArray(n);
            mergeSeedBodies();
        } catch (Exception ignored) { }
    }

    private void mergeSeedBodies() {
        for (int i = 0; i < tutorials.length(); i++) {
            JSONObject remote = tutorials.optJSONObject(i);
            if (remote == null) continue;
            JSONObject local = seedTutorials.get(remote.optString("id"));
            if (local == null) continue;
            try {
                if (remote.optString("body").trim().isEmpty()) remote.put("body", local.optString("body"));
                if (remote.optString("sourceUrl").trim().isEmpty()) {
                    remote.put("sourceUrl", local.optString("sourceUrl"));
                    remote.put("sourceTitle", local.optString("sourceTitle"));
                }
            } catch (Exception ignored) { }
        }
    }

    private void indexData() {
        tutorialIndex.clear(); categoryIndex.clear(); newsIndex.clear();
        for (int i = 0; i < tutorials.length(); i++) {
            JSONObject x = tutorials.optJSONObject(i); if (x != null) tutorialIndex.put(x.optString("id"), x);
        }
        for (int i = 0; i < categories.length(); i++) {
            JSONObject x = categories.optJSONObject(i); if (x != null) categoryIndex.put(x.optString("id"), x);
        }
        for (int i = 0; i < news.length(); i++) {
            JSONObject x = news.optJSONObject(i); if (x != null) newsIndex.put(x.optString("id"), x);
        }
    }

    private LinearLayout buildBottomNav() {
        LinearLayout nav = Ui.horizontal(activity);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(Ui.dp(activity, 8), Ui.dp(activity, 7), Ui.dp(activity, 8), Ui.dp(activity, 7));
        nav.setBackground(Ui.bg(Color.WHITE, 0, Ui.LINE, 1, activity));
        nav.addView(navButton("⌂", "خانه", TAB_HOME), Ui.lpWeight(1));
        nav.addView(navButton("♡", "علاقه‌مندی", TAB_FAVORITES), Ui.lpWeight(1));
        nav.addView(navButton("▤", "اخبار آنلاین", TAB_NEWS), Ui.lpWeight(1));
        return nav;
    }

    private View navButton(String icon, String label, String tab) {
        LinearLayout b = Ui.vertical(activity);
        b.setGravity(Gravity.CENTER);
        TextView i = Ui.text(activity, icon, 22, Ui.MUTED, true); i.setGravity(Gravity.CENTER); i.setTag("icon");
        TextView t = Ui.text(activity, label, 10.5f, Ui.MUTED, true); t.setGravity(Gravity.CENTER); t.setTag("label");
        b.addView(i); b.addView(t);
        b.setTag(tab);
        b.setOnClickListener(v -> showTab(tab));
        return b;
    }

    private void updateBottomNav() {
        for (int i = 0; i < bottomNav.getChildCount(); i++) {
            View v = bottomNav.getChildAt(i);
            if (!(v instanceof LinearLayout)) continue;
            boolean on = activeTab.equals(v.getTag());
            LinearLayout l = (LinearLayout)v;
            for (int j = 0; j < l.getChildCount(); j++) {
                View c = l.getChildAt(j);
                if (c instanceof TextView) ((TextView)c).setTextColor(on ? Ui.PRIMARY : Ui.MUTED);
            }
        }
    }

    private void showTab(String tab) {
        stopSlider();
        activeTab = tab;
        subPageOpen = false;
        updateBottomNav();
        content.removeAllViews();
        if (TAB_FAVORITES.equals(tab)) content.addView(buildFavoritesPage());
        else if (TAB_NEWS.equals(tab)) content.addView(buildNewsPage());
        else content.addView(buildHomePage());
    }

    private View buildHomePage() {
        ScrollView scroll = pageScroll();
        LinearLayout page = pageBody();
        page.addView(buildTopBar("آموزش همستر", true));
        page.addView(buildSlider(), margin(16, 8));
        page.addView(sectionHeader("دسته‌بندی‌ها", "مشاهده همه", v -> openAllCategories()), margin(18, 6));
        page.addView(buildHomeCategories());
        page.addView(sectionHeader("آموزش‌های محبوب", "مشاهده همه", v -> openPopular()), margin(20, 8));
        LinearLayout popular = Ui.vertical(activity);
        for (JSONObject t : popularTutorials(5)) popular.addView(tutorialRow(t), margin(0, 10));
        if (popular.getChildCount() == 0) popular.addView(emptyState("هنوز آموزشی منتشر نشده است."));
        page.addView(popular);
        page.addView(space(22));
        scroll.addView(page);
        return scroll;
    }

    private LinearLayout buildTopBar(String title, boolean search) {
        LinearLayout bar = Ui.horizontal(activity);
        bar.setPadding(Ui.dp(activity, 16), Ui.dp(activity, 12), Ui.dp(activity, 16), Ui.dp(activity, 4));
        TextView titleView = Ui.text(activity, title, 22, Ui.TEXT, true);
        bar.addView(titleView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (search) {
            TextView s = circleAction("⌕");
            s.setOnClickListener(v -> openSearch());
            bar.addView(s, new LinearLayout.LayoutParams(Ui.dp(activity, 42), Ui.dp(activity, 42)));
        }
        return bar;
    }

    private View buildSlider() {
        FrameLayout wrap = new FrameLayout(activity);
        wrap.setBackground(Ui.gradient(Color.rgb(75,69,220), Color.rgb(126,78,235), 24, Color.TRANSPARENT, 0, activity));
        ViewFlipper flipper = new ViewFlipper(activity);
        flipper.setInAnimation(activity, android.R.anim.fade_in);
        flipper.setOutAnimation(activity, android.R.anim.fade_out);
        int added = 0;
        for (int i = 0; i < sliders.length(); i++) {
            JSONObject s = sliders.optJSONObject(i);
            if (s == null || !s.optBoolean("active", true)) continue;
            flipper.addView(slideView(s)); added++;
        }
        if (added == 0) {
            JSONObject fallback = new JSONObject();
            try { fallback.put("title", "یادگیری همستر، ساده و فارسی"); fallback.put("subtitle", "راهنماهای مرحله‌به‌مرحله HamsterVerse، TON و امنیت"); } catch (Exception ignored) { }
            flipper.addView(slideView(fallback)); added = 1;
        }
        wrap.addView(flipper, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 188)));
        if (added > 1) {
            sliderTicker = new Runnable() {
                @Override public void run() { if (flipper.getParent() != null) { flipper.showNext(); handler.postDelayed(this, 4500); } }
            };
            handler.postDelayed(sliderTicker, 4500);
        }
        return wrap;
    }

    private View slideView(JSONObject s) {
        FrameLayout slide = new FrameLayout(activity);
        String image = ApiClient.absolute(s.optString("image"));
        if (!image.isEmpty()) {
            ImageView iv = new ImageView(activity); iv.setScaleType(ImageView.ScaleType.CENTER_CROP); iv.setAlpha(.38f); images.load(iv, image);
            slide.addView(iv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        LinearLayout row = Ui.horizontal(activity);
        row.setPadding(Ui.dp(activity, 18), Ui.dp(activity, 17), Ui.dp(activity, 18), Ui.dp(activity, 17));
        LinearLayout text = Ui.vertical(activity);
        TextView kicker = Ui.text(activity, s.optString("kicker", "آموزش آنلاین"), 10, Color.rgb(225,223,255), true);
        TextView title = Ui.text(activity, s.optString("title", "آموزش همستر"), 21, Color.WHITE, true);
        TextView sub = Ui.text(activity, s.optString("subtitle", "راهنمای فارسی و مرحله‌به‌مرحله"), 11.5f, Color.rgb(236,235,255), false);
        sub.setMaxLines(3);
        text.addView(kicker); text.addView(title, margin(6, 6)); text.addView(sub);
        TextView cta = Ui.pill(activity, s.optString("buttonText", "مشاهده"), Ui.PRIMARY_DARK, Color.WHITE);
        text.addView(cta, margin(12, 0));
        row.addView(text, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView art = Ui.text(activity, s.optString("icon", "🎓"), 52, Color.WHITE, false); art.setGravity(Gravity.CENTER);
        row.addView(art, new LinearLayout.LayoutParams(Ui.dp(activity, 92), Ui.dp(activity, 120)));
        slide.addView(row, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        slide.setOnClickListener(v -> followTarget(s));
        return slide;
    }

    private View buildHomeCategories() {
        HorizontalScrollView hsv = new HorizontalScrollView(activity); hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = Ui.horizontal(activity); row.setPadding(Ui.dp(activity, 12), 0, Ui.dp(activity, 12), 0);
        int added = 0;
        for (int i = 0; i < categories.length() && added < 4; i++) {
            JSONObject c = categories.optJSONObject(i);
            if (c == null || !c.optBoolean("active", true) || c.optBoolean("deleted", false) || !c.optString("parentId").isEmpty()) continue;
            row.addView(homeCategoryCard(c)); added++;
        }
        hsv.addView(row, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return hsv;
    }

    private View homeCategoryCard(JSONObject c) {
        LinearLayout card = Ui.vertical(activity); card.setGravity(Gravity.CENTER); card.setPadding(Ui.dp(activity, 10), Ui.dp(activity, 12), Ui.dp(activity, 10), Ui.dp(activity, 12));
        card.setBackground(Ui.bg(categoryTint(c.optString("id")), 18, Color.TRANSPARENT, 0, activity));
        View visual = categoryVisual(c, 52); card.addView(visual, new LinearLayout.LayoutParams(Ui.dp(activity, 54), Ui.dp(activity, 54)));
        TextView title = Ui.text(activity, c.optString("name"), 10.5f, Ui.TEXT, true); title.setGravity(Gravity.CENTER); title.setMaxLines(2);
        card.addView(title, margin(7, 0));
        card.setOnClickListener(v -> openCategory(c));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(activity, 112), Ui.dp(activity, 120)); p.setMargins(Ui.dp(activity, 5),0,Ui.dp(activity,5),0); card.setLayoutParams(p);
        return card;
    }

    private LinearLayout sectionHeader(String title, String action, View.OnClickListener click) {
        LinearLayout row = Ui.horizontal(activity);
        TextView t = Ui.text(activity, title, 17, Ui.TEXT, true); row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView a = Ui.text(activity, action, 11, Ui.PRIMARY, true); a.setPadding(Ui.dp(activity, 8), Ui.dp(activity, 8), Ui.dp(activity, 8), Ui.dp(activity, 8)); a.setOnClickListener(click); row.addView(a);
        return row;
    }

    private View tutorialRow(JSONObject t) {
        LinearLayout card = Ui.horizontal(activity); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(Ui.dp(activity, 10), Ui.dp(activity, 10), Ui.dp(activity, 10), Ui.dp(activity, 10));
        card.setBackground(Ui.bg(Color.WHITE, 19, Ui.LINE, 1, activity));
        View image = coverVisual(t, 112, 78); card.addView(image, new LinearLayout.LayoutParams(Ui.dp(activity, 112), Ui.dp(activity, 78)));
        LinearLayout text = Ui.vertical(activity); text.setPadding(Ui.dp(activity, 12), 0, Ui.dp(activity, 8), 0);
        TextView title = Ui.text(activity, t.optString("title"), 13.5f, Ui.TEXT, true); title.setMaxLines(2); text.addView(title);
        TextView summary = Ui.text(activity, t.optString("summary"), 10.5f, Ui.MUTED, false); summary.setMaxLines(2); text.addView(summary, margin(4, 5));
        LinearLayout meta = Ui.horizontal(activity); meta.addView(Ui.pill(activity, t.optString("level", "مبتدی"), Ui.PRIMARY_DARK, Color.rgb(239,238,255))); Ui.gap(meta, activity, 5); meta.addView(Ui.pill(activity, t.optInt("duration", 5)+" دقیقه", Ui.MUTED, Ui.SURFACE_SOFT)); text.addView(meta);
        card.addView(text, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.setOnClickListener(v -> openTutorial(t));
        return card;
    }

    private List<JSONObject> popularTutorials(int limit) {
        List<JSONObject> list = new ArrayList<>();
        for (int i=0;i<tutorials.length();i++) { JSONObject t=tutorials.optJSONObject(i); if(t!=null&&t.optBoolean("active",true)&&!t.optBoolean("deleted",false)) list.add(t); }
        Collections.sort(list, new Comparator<JSONObject>() {
            @Override public int compare(JSONObject a, JSONObject b) {
                int av=a.optInt("views",0)+(a.optBoolean("featured",false)?100000:0), bv=b.optInt("views",0)+(b.optBoolean("featured",false)?100000:0);
                if (av!=bv) return Integer.compare(bv,av); return Integer.compare(a.optInt("sortOrder",0), b.optInt("sortOrder",0));
            }
        });
        return list.subList(0, Math.min(limit, list.size()));
    }

    private void openAllCategories() {
        subPageOpen = true; content.removeAllViews();
        ScrollView scroll=pageScroll(); LinearLayout page=pageBody(); page.addView(backBar("همه دسته‌بندی‌ها"));
        TextView intro=Ui.text(activity,"موضوع موردنظرت را انتخاب کن؛ داخل هر دسته آموزش‌های ریز و مرحله‌به‌مرحله قرار دارد.",11.5f,Ui.MUTED,false); page.addView(intro,margin(4,14));
        GridLayout grid=new GridLayout(activity); grid.setColumnCount(2); grid.setUseDefaultMargins(false);
        int idx=0;
        for(int i=0;i<categories.length();i++){
            JSONObject c=categories.optJSONObject(i); if(c==null||!c.optBoolean("active",true)||c.optBoolean("deleted",false)||!c.optString("parentId").isEmpty())continue;
            View card=fullCategoryCard(c); GridLayout.LayoutParams gp=new GridLayout.LayoutParams(); gp.width=0; gp.height=ViewGroup.LayoutParams.WRAP_CONTENT; gp.columnSpec=GridLayout.spec(idx%2,1,1f); gp.setMargins(Ui.dp(activity,5),Ui.dp(activity,5),Ui.dp(activity,5),Ui.dp(activity,5)); card.setLayoutParams(gp); grid.addView(card); idx++;
        }
        page.addView(grid); page.addView(space(20)); scroll.addView(page); content.addView(scroll);
    }

    private View fullCategoryCard(JSONObject c) {
        LinearLayout card=Ui.vertical(activity); card.setPadding(Ui.dp(activity,10),Ui.dp(activity,10),Ui.dp(activity,10),Ui.dp(activity,12)); card.setBackground(Ui.bg(Color.WHITE,20,Ui.LINE,1,activity));
        View visual=categoryBanner(c); card.addView(visual,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,102)));
        TextView title=Ui.text(activity,c.optString("name"),13.5f,Ui.TEXT,true); card.addView(title,margin(9,3));
        String desc=c.optString("description"); if(desc.isEmpty())desc="آموزش‌ها و راهنماهای این موضوع";
        TextView d=Ui.text(activity,desc,10.2f,Ui.MUTED,false); d.setMaxLines(3); card.addView(d);
        card.setOnClickListener(v->openCategory(c)); return card;
    }

    private void openCategory(JSONObject category) {
        subPageOpen=true; content.removeAllViews();
        ScrollView scroll=pageScroll(); LinearLayout page=pageBody(); page.addView(backBar(category.optString("name")));
        View banner=categoryBanner(category); page.addView(banner,margin(6,10));
        String desc=category.optString("description"); if(!desc.isEmpty()) page.addView(Ui.text(activity,desc,11.5f,Ui.MUTED,false),margin(0,12));
        LinearLayout rows=Ui.vertical(activity); int added=0;
        for(int i=0;i<tutorials.length();i++){JSONObject t=tutorials.optJSONObject(i);if(t==null||!t.optBoolean("active",true)||!category.optString("id").equals(t.optString("categoryId")))continue;rows.addView(tutorialRow(t),margin(0,10));added++;}
        if(added==0)rows.addView(emptyState("هنوز مطلبی برای این دسته ثبت نشده است.")); page.addView(rows); page.addView(space(20)); scroll.addView(page); content.addView(scroll);
    }

    private void openPopular() {
        subPageOpen=true; content.removeAllViews(); ScrollView scroll=pageScroll(); LinearLayout page=pageBody(); page.addView(backBar("آموزش‌های محبوب"));
        for(JSONObject t:popularTutorials(100))page.addView(tutorialRow(t),margin(0,10)); page.addView(space(20)); scroll.addView(page); content.addView(scroll);
    }

    private View buildFavoritesPage() {
        ScrollView scroll=pageScroll(); LinearLayout page=pageBody(); page.addView(buildTopBar("علاقه‌مندی‌ها",false));
        page.addView(Ui.text(activity,"آموزش‌هایی که ذخیره کرده‌ای اینجا می‌مانند.",11.5f,Ui.MUTED,false),margin(2,12));
        int added=0; for(String id:new ArrayList<>(favorites)){JSONObject t=tutorialIndex.get(id);if(t!=null){page.addView(tutorialRow(t),margin(0,10));added++;}}
        if(added==0)page.addView(emptyState("هنوز آموزشی ذخیره نکرده‌ای.")); page.addView(space(20)); scroll.addView(page); return scroll;
    }

    private View buildNewsPage() {
        ScrollView scroll=pageScroll(); LinearLayout page=pageBody(); page.addView(buildTopBar("اخبار آنلاین",false));
        page.addView(Ui.text(activity,"خبرها و اطلاعیه‌های همستر از سرور به‌روز می‌شوند.",11.5f,Ui.MUTED,false),margin(2,12));
        int added=0; for(int i=0;i<news.length();i++){JSONObject n=news.optJSONObject(i);if(n==null||!n.optBoolean("active",true)||n.optBoolean("deleted",false))continue;page.addView(newsRow(n),margin(0,10));added++;}
        if(added==0)page.addView(emptyState("هنوز خبری منتشر نشده است.")); page.addView(space(20)); scroll.addView(page); return scroll;
    }

    private View newsRow(JSONObject n) {
        LinearLayout card=Ui.horizontal(activity);card.setPadding(Ui.dp(activity,10),Ui.dp(activity,10),Ui.dp(activity,10),Ui.dp(activity,10));card.setGravity(Gravity.CENTER_VERTICAL);card.setBackground(Ui.bg(Color.WHITE,19,Ui.LINE,1,activity));
        View cover=newsVisual(n);card.addView(cover,new LinearLayout.LayoutParams(Ui.dp(activity,112),Ui.dp(activity,80)));
        LinearLayout text=Ui.vertical(activity);text.setPadding(Ui.dp(activity,12),0,Ui.dp(activity,8),0);TextView title=Ui.text(activity,n.optString("title"),13.5f,Ui.TEXT,true);title.setMaxLines(2);text.addView(title);TextView sum=Ui.text(activity,n.optString("summary"),10.2f,Ui.MUTED,false);sum.setMaxLines(2);text.addView(sum,margin(4,4));TextView date=Ui.text(activity,n.optString("publishedAt",""),9.5f,Ui.MUTED2,false);text.addView(date);card.addView(text,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));card.setOnClickListener(v->openNews(n));return card;
    }

    private void openTutorial(JSONObject summary) {
        String id=summary.optString("id"); JSONObject local=tutorialIndex.get(id);
        if(local!=null&&!local.optString("body").trim().isEmpty()){showTutorialDetail(local);trackView("tutorial",id);return;}
        api.post("app.php?action=tutorial", json("id",id), null, new ApiClient.Callback(){@Override public void ok(JSONObject j){JSONObject t=j.optJSONObject("tutorial");if(t!=null){tutorialIndex.put(id,t);showTutorialDetail(t);trackView("tutorial",id);}}@Override public void fail(String m){activity.toast(m);}});
    }

    private void showTutorialDetail(JSONObject t) {
        subPageOpen=true;content.removeAllViews();ScrollView scroll=pageScroll();LinearLayout page=pageBody();
        LinearLayout bar=backBar(t.optString("title"));TextView save=circleAction(favorites.contains(t.optString("id"))?"♥":"♡");save.setTextColor(favorites.contains(t.optString("id"))?Ui.RED:Ui.PRIMARY);save.setOnClickListener(v->{toggleFavorite(t.optString("id"));save.setText(favorites.contains(t.optString("id"))?"♥":"♡");save.setTextColor(favorites.contains(t.optString("id"))?Ui.RED:Ui.PRIMARY);});bar.addView(save,new LinearLayout.LayoutParams(Ui.dp(activity,42),Ui.dp(activity,42)));page.addView(bar);
        View cover=detailCover(t);page.addView(cover,margin(8,15));
        JSONObject c=categoryIndex.get(t.optString("categoryId"));if(c!=null)page.addView(Ui.pill(activity,c.optString("name"),Ui.PRIMARY_DARK,Color.rgb(238,237,255)),margin(0,8));
        page.addView(Ui.text(activity,t.optString("title"),23,Ui.TEXT,true),margin(0,6));
        LinearLayout meta=Ui.horizontal(activity);meta.addView(Ui.pill(activity,t.optString("level","مبتدی"),Ui.GREEN,Color.rgb(231,249,241)));Ui.gap(meta,activity,6);meta.addView(Ui.pill(activity,t.optInt("duration",5)+" دقیقه",Ui.MUTED,Ui.SURFACE_SOFT));page.addView(meta,margin(4,16));
        String body=t.optString("body");if(body.isEmpty())body=t.optString("summary");for(String p:body.split("\\n\\s*\\n")){if(p.trim().isEmpty())continue;TextView pv=Ui.text(activity,p.trim(),13.2f,Ui.TEXT,false);pv.setLineSpacing(Ui.dp(activity,3),1.35f);page.addView(pv,margin(0,14));}
        String source=t.optString("sourceUrl");if(!source.isEmpty()){LinearLayout sourceCard=Ui.softCard(activity);sourceCard.addView(Ui.text(activity,"منبع",10,Ui.MUTED,true));TextView st=Ui.text(activity,t.optString("sourceTitle","مشاهده منبع"),12.5f,Ui.PRIMARY,true);sourceCard.addView(st,margin(4,0));sourceCard.setOnClickListener(v->openUrl(source));page.addView(sourceCard,margin(6,12));}
        page.addView(space(24));scroll.addView(page);content.addView(scroll);
    }

    private void openNews(JSONObject summary) {
        String id=summary.optString("id");JSONObject local=newsIndex.get(id);if(local!=null&&!local.optString("body").trim().isEmpty()){showNewsDetail(local);trackView("news",id);return;}
        api.post("app.php?action=news_detail",json("id",id),null,new ApiClient.Callback(){@Override public void ok(JSONObject j){JSONObject n=j.optJSONObject("news");if(n!=null){newsIndex.put(id,n);showNewsDetail(n);trackView("news",id);}}@Override public void fail(String m){activity.toast(m);}});
    }

    private void showNewsDetail(JSONObject n) {
        subPageOpen=true;content.removeAllViews();ScrollView scroll=pageScroll();LinearLayout page=pageBody();page.addView(backBar("خبر"));page.addView(detailCover(n),margin(8,14));page.addView(Ui.text(activity,n.optString("title"),22,Ui.TEXT,true),margin(0,6));page.addView(Ui.text(activity,n.optString("publishedAt"),10,Ui.MUTED2,false),margin(0,14));String body=n.optString("body");if(body.isEmpty())body=n.optString("summary");for(String p:body.split("\\n\\s*\\n")){if(p.trim().isEmpty())continue;TextView pv=Ui.text(activity,p.trim(),13.2f,Ui.TEXT,false);pv.setLineSpacing(Ui.dp(activity,3),1.35f);page.addView(pv,margin(0,14));}String source=n.optString("sourceUrl");if(!source.isEmpty()){android.widget.Button b=Ui.button(activity,"مشاهده منبع",false);b.setOnClickListener(v->openUrl(source));page.addView(b,margin(6,10));}page.addView(space(24));scroll.addView(page);content.addView(scroll);
    }

    private void openSearch() {
        subPageOpen=true;content.removeAllViews();LinearLayout root=Ui.vertical(activity);root.setPadding(Ui.dp(activity,14),Ui.dp(activity,10),Ui.dp(activity,14),Ui.dp(activity,10));root.addView(backBar("جستجو"));
        EditText q=new EditText(activity);q.setHint("جستجو در آموزش‌ها...");q.setSingleLine(true);q.setTextSize(13);q.setTextColor(Ui.TEXT);q.setHintTextColor(Ui.MUTED2);q.setPadding(Ui.dp(activity,14),0,Ui.dp(activity,14),0);q.setBackground(Ui.bg(Color.WHITE,16,Ui.LINE,1,activity));root.addView(q,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,52)));
        ScrollView scroll=new ScrollView(activity);LinearLayout results=Ui.vertical(activity);results.setPadding(0,Ui.dp(activity,10),0,Ui.dp(activity,20));scroll.addView(results);root.addView(scroll,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f));
        Runnable render=()->{String needle=q.getText().toString().trim().toLowerCase();results.removeAllViews();int added=0;for(int i=0;i<tutorials.length();i++){JSONObject t=tutorials.optJSONObject(i);if(t==null||!t.optBoolean("active",true))continue;String hay=(t.optString("title")+" "+t.optString("summary")+" "+t.optJSONArray("tags")).toLowerCase();if(needle.isEmpty()||hay.contains(needle)){results.addView(tutorialRow(t),margin(0,8));added++;}}if(added==0)results.addView(emptyState("نتیجه‌ای پیدا نشد."));};
        q.addTextChangedListener(new TextWatcher(){@Override public void beforeTextChanged(CharSequence s,int st,int c,int a){}@Override public void onTextChanged(CharSequence s,int st,int b,int c){render.run();}@Override public void afterTextChanged(Editable e){}});render.run();content.addView(root);
    }

    private void toggleFavorite(String id) {
        if(favorites.contains(id))favorites.remove(id);else favorites.add(id);prefs.edit().putStringSet("favorites",new HashSet<>(favorites)).apply();activity.toast(favorites.contains(id)?"به علاقه‌مندی‌ها اضافه شد":"از علاقه‌مندی‌ها حذف شد");
    }

    private void followTarget(JSONObject s) {
        String type=s.optString("targetType"),value=s.optString("targetValue");if(value.isEmpty())value=s.optString("link");
        if("tutorial".equals(type)&&tutorialIndex.containsKey(value))openTutorial(tutorialIndex.get(value));
        else if("category".equals(type)&&categoryIndex.containsKey(value))openCategory(categoryIndex.get(value));
        else if("news".equals(type)&&newsIndex.containsKey(value))openNews(newsIndex.get(value));
        else if("url".equals(type)||value.startsWith("http"))openUrl(value);
    }

    private void refreshRemote() {
        api.post("app.php?action=home",new JSONObject(),null,new ApiClient.Callback(){@Override public void ok(JSONObject j){JSONArray s=j.optJSONArray("sliders"),c=j.optJSONArray("categories"),p=j.optJSONArray("popular"),n=j.optJSONArray("news");if(s!=null){sliders=s;prefs.edit().putString("sliders_cache",s.toString()).apply();}if(c!=null&&c.length()>0){categories=c;prefs.edit().putString("categories_cache",c.toString()).apply();}if(n!=null){news=n;prefs.edit().putString("news_cache",n.toString()).apply();}if(p!=null&&p.length()>0)mergeTutorialLists(p);indexData();lastLoadedAt=SystemClock.elapsedRealtime();if(!subPageOpen)showTab(activeTab);}@Override public void fail(String m){}});
        JSONObject body=new JSONObject();try{body.put("limit",200);}catch(Exception ignored){}
        api.post("app.php?action=tutorials",body,null,new ApiClient.Callback(){@Override public void ok(JSONObject j){JSONArray a=j.optJSONArray("tutorials");if(a!=null&&a.length()>0){tutorials=a;mergeSeedBodies();prefs.edit().putString("tutorials_cache",a.toString()).apply();indexData();lastLoadedAt=SystemClock.elapsedRealtime();if(!subPageOpen)showTab(activeTab);}}@Override public void fail(String m){}});
        api.post("app.php?action=news",json("limit",100),null,new ApiClient.Callback(){@Override public void ok(JSONObject j){JSONArray a=j.optJSONArray("news");if(a!=null){news=a;prefs.edit().putString("news_cache",a.toString()).apply();indexData();if(!subPageOpen&&TAB_NEWS.equals(activeTab))showTab(TAB_NEWS);}}@Override public void fail(String m){}});
    }

    private void mergeTutorialLists(JSONArray popular) {
        for(int i=0;i<popular.length();i++){JSONObject p=popular.optJSONObject(i);if(p==null)continue;String id=p.optString("id");boolean found=false;for(int j=0;j<tutorials.length();j++){JSONObject t=tutorials.optJSONObject(j);if(t!=null&&id.equals(t.optString("id"))){try{t.put("views",p.optInt("views",t.optInt("views",0)));}catch(Exception ignored){}found=true;break;}}if(!found)tutorials.put(p);}
    }

    private void trackView(String type,String id){JSONObject b=new JSONObject();try{b.put("type",type);b.put("id",id);}catch(Exception ignored){}api.post("app.php?action=view",b,null,new ApiClient.Callback(){@Override public void ok(JSONObject j){}@Override public void fail(String m){}});}

    private void stopSlider(){if(sliderTicker!=null){handler.removeCallbacks(sliderTicker);sliderTicker=null;}}

    private LinearLayout backBar(String title) {
        LinearLayout bar=Ui.horizontal(activity);bar.setPadding(0,Ui.dp(activity,4),0,Ui.dp(activity,8));TextView back=circleAction("‹");back.setTextSize(30);back.setOnClickListener(v->{subPageOpen=false;showTab(activeTab);});bar.addView(back,new LinearLayout.LayoutParams(Ui.dp(activity,42),Ui.dp(activity,42)));TextView t=Ui.text(activity,title,18,Ui.TEXT,true);t.setMaxLines(1);bar.addView(t,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));return bar;
    }

    private TextView circleAction(String txt){TextView v=Ui.text(activity,txt,22,Ui.PRIMARY,true);v.setGravity(Gravity.CENTER);v.setBackground(Ui.bg(Color.WHITE,99,Ui.LINE,1,activity));return v;}

    private View categoryVisual(JSONObject c,int size){String image=ApiClient.absolute(c.optString("image"));if(!image.isEmpty()){ImageView iv=new ImageView(activity);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setBackground(Ui.bg(Color.WHITE,16,Color.TRANSPARENT,0,activity));images.load(iv,image);return iv;}TextView tv=Ui.text(activity,c.optString("icon","📘"),size*.48f,Ui.PRIMARY,false);tv.setGravity(Gravity.CENTER);tv.setBackground(Ui.bg(Color.argb(35,80,73,224),16,Color.TRANSPARENT,0,activity));return tv;}

    private View categoryBanner(JSONObject c){FrameLayout f=new FrameLayout(activity);f.setBackground(Ui.gradient(categoryTint(c.optString("id")),Color.rgb(236,238,255),20,Color.TRANSPARENT,0,activity));String image=ApiClient.absolute(c.optString("image"));if(!image.isEmpty()){ImageView iv=new ImageView(activity);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setAlpha(.28f);images.load(iv,image);f.addView(iv,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));}TextView icon=Ui.text(activity,c.optString("icon","📘"),38,Ui.PRIMARY,false);icon.setGravity(Gravity.CENTER);f.addView(icon,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));return f;}

    private int categoryTint(String id){int[] colors={Color.rgb(239,235,255),Color.rgb(232,244,255),Color.rgb(231,249,243),Color.rgb(255,244,225),Color.rgb(255,235,240),Color.rgb(236,240,255)};return colors[Math.abs(id.hashCode())%colors.length];}

    private View coverVisual(JSONObject t,int w,int h){String cover=ApiClient.absolute(t.optString("cover"));if(!cover.isEmpty()){ImageView iv=new ImageView(activity);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setBackground(Ui.bg(Ui.SURFACE_SOFT,16,Color.TRANSPARENT,0,activity));images.load(iv,cover);return iv;}JSONObject c=categoryIndex.get(t.optString("categoryId"));FrameLayout f=new FrameLayout(activity);f.setBackground(Ui.gradient(categoryTint(t.optString("categoryId")),Color.rgb(242,243,253),16,Color.TRANSPARENT,0,activity));TextView i=Ui.text(activity,c==null?"📚":c.optString("icon","📚"),28,Ui.PRIMARY,false);i.setGravity(Gravity.CENTER);f.addView(i,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));return f;}

    private View newsVisual(JSONObject n){String cover=ApiClient.absolute(n.optString("cover"));if(!cover.isEmpty()){ImageView iv=new ImageView(activity);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);images.load(iv,cover);return iv;}FrameLayout f=new FrameLayout(activity);f.setBackground(Ui.gradient(Color.rgb(230,239,255),Color.rgb(241,236,255),16,Color.TRANSPARENT,0,activity));TextView i=Ui.text(activity,"📰",30,Ui.PRIMARY,false);i.setGravity(Gravity.CENTER);f.addView(i,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));return f;}

    private View detailCover(JSONObject t){String cover=ApiClient.absolute(t.optString("cover"));FrameLayout f=new FrameLayout(activity);f.setBackground(Ui.gradient(Color.rgb(72,68,218),Color.rgb(124,78,233),22,Color.TRANSPARENT,0,activity));if(!cover.isEmpty()){ImageView iv=new ImageView(activity);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);images.load(iv,cover);f.addView(iv,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));}else{JSONObject c=categoryIndex.get(t.optString("categoryId"));TextView i=Ui.text(activity,c==null?"🎓":c.optString("icon","🎓"),58,Color.WHITE,false);i.setGravity(Gravity.CENTER);f.addView(i,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));}f.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,205)));return f;}

    private TextView emptyState(String text){TextView e=Ui.text(activity,text,12,Ui.MUTED,false);e.setGravity(Gravity.CENTER);e.setPadding(Ui.dp(activity,16),Ui.dp(activity,32),Ui.dp(activity,16),Ui.dp(activity,32));e.setBackground(Ui.bg(Color.WHITE,18,Ui.LINE,1,activity));return e;}
    private ScrollView pageScroll(){ScrollView s=new ScrollView(activity);s.setFillViewport(true);s.setClipToPadding(false);s.setBackgroundColor(Ui.BG);return s;}
    private LinearLayout pageBody(){LinearLayout p=Ui.vertical(activity);p.setPadding(Ui.dp(activity,14),Ui.dp(activity,6),Ui.dp(activity,14),Ui.dp(activity,12));return p;}
    private View space(int dp){View v=new View(activity);v.setLayoutParams(new LinearLayout.LayoutParams(1,Ui.dp(activity,dp)));return v;}
    private LinearLayout.LayoutParams margin(int top,int bottom){return Ui.lpMatchWrap(activity,top,bottom);}
    private JSONObject json(String key,Object value){JSONObject j=new JSONObject();try{j.put(key,value);}catch(Exception ignored){}return j;}
    private void openUrl(String url){try{activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}catch(Exception e){activity.toast("بازکردن لینک ممکن نشد");}}
}
