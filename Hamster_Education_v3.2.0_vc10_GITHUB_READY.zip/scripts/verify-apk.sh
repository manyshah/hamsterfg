#!/usr/bin/env bash
set -euo pipefail

APK="${1:-}"
if [[ -z "$APK" || ! -f "$APK" ]]; then
  echo "Usage: $0 path/to/release.apk" >&2
  exit 2
fi

BUILD_TOOLS="${ANDROID_HOME}/build-tools/36.0.0"
AAPT="${BUILD_TOOLS}/aapt"
APKSIGNER="${BUILD_TOOLS}/apksigner"
EXPECTED_SHA256="0716fdb68eabeaa35637dcfc468b0cec2976a89bec65d8920432d206414fde53"

"$AAPT" dump badging "$APK" | tee /tmp/hamster-badging.txt

grep -q "package: name='com.maniplus.notcoin' versionCode='10' versionName='3.2.0'" /tmp/hamster-badging.txt
grep -q "targetSdkVersion:'36'" /tmp/hamster-badging.txt

"$APKSIGNER" verify --verbose --print-certs "$APK" | tee /tmp/hamster-signature.txt
ACTUAL_SHA256=$(sed -n 's/^Signer #1 certificate SHA-256 digest: //p' /tmp/hamster-signature.txt | head -1 | tr '[:upper:]' '[:lower:]' | tr -d ':[:space:]')

if [[ "$ACTUAL_SHA256" != "$EXPECTED_SHA256" ]]; then
  echo "Signing certificate mismatch." >&2
  echo "Expected: $EXPECTED_SHA256" >&2
  echo "Actual:   $ACTUAL_SHA256" >&2
  exit 1
fi

echo "All release checks passed."
