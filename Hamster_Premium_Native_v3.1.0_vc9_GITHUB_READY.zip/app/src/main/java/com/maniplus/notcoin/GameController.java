package com.maniplus.notcoin;

import android.animation.ObjectAnimator;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

public final class GameController {
    private final MainActivity activity;
    private final ApiClient api;
    private final ImageLoader images;
    private final SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final LinearLayout root;
    private final LinearLayout navRow;
    private final LinearLayout body;
    private JSONObject user = new JSONObject();
    private JSONObject missions = new JSONObject();
    private JSONArray cups = new JSONArray();
    private JSONArray boostCosts = new JSONArray();
    private String token = "";
    private String section = "home";
    private boolean loadingSession = false;
    private boolean paused = false;
    private int pendingTaps = 0;
    private boolean tapRequestInFlight = false;
    private String missionCategory = "";

    private final Runnable heartbeat = new Runnable() {
        @Override public void run() {
            if (!paused && !token.isEmpty()) callGame("heartbeat", new JSONObject(), false, null);
            handler.postDelayed(this, 30000);
        }
    };

    public GameController(MainActivity activity, ApiClient api, ImageLoader images, SharedPreferences prefs) {
        this.activity = activity;
        this.api = api;
        this.images = images;
        this.prefs = prefs;
        token = prefs.getString("session_token", "");

        root = Ui.vertical(activity);
        root.setBackgroundColor(Color.TRANSPARENT);

        LinearLayout gameHeader = Ui.horizontal(activity);
        gameHeader.setPadding(Ui.dp(activity, 16), Ui.dp(activity, 10), Ui.dp(activity, 16), Ui.dp(activity, 5));
        LinearLayout brand = Ui.vertical(activity);
        TextView eyebrow = Ui.sectionEyebrow(activity, "HAMSTER GOLDEN");
        TextView title = Ui.text(activity, "بازی همستر", 21, Ui.TEXT, true);
        brand.addView(eyebrow);
        brand.addView(title);
        gameHeader.addView(brand, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView online = Ui.pill(activity, "● آنلاین", Ui.GREEN, Color.argb(28, 74, 211, 155));
        gameHeader.addView(online);
        root.addView(gameHeader, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        HorizontalScrollView hsv = new HorizontalScrollView(activity);
        hsv.setHorizontalScrollBarEnabled(false);
        navRow = Ui.horizontal(activity);
        navRow.setPadding(Ui.dp(activity, 12), Ui.dp(activity, 5), Ui.dp(activity, 12), Ui.dp(activity, 9));
        hsv.addView(navRow, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(activity);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        body = Ui.vertical(activity);
        body.setPadding(Ui.dp(activity, 14), Ui.dp(activity, 4), Ui.dp(activity, 14), Ui.dp(activity, 30));
        scroll.addView(body, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        renderNav();
        showLoading("در حال بازیابی حساب و دریافت اطلاعات...");
        ensureSession();
        handler.postDelayed(heartbeat, 30000);
    }

    public View view() {
        if (root.getParent() instanceof ViewGroup) ((ViewGroup)root.getParent()).removeView(root);
        return root;
    }

    public void resume() {
        paused = false;
        if (!token.isEmpty()) callGame("get", new JSONObject(), false, null); else ensureSession();
    }

    public void pause() { paused = true; flushTaps(); }
    public void destroy() { handler.removeCallbacksAndMessages(null); }

    private void renderNav() {
        navRow.removeAllViews();
        addNav("home", "⌂", "خانه");
        addNav("boosts", "⚡", "بوست");
        addNav("missions", "◆", "مأموریت");
        addNav("league", "🏆", "لیگ");
        addNav("referral", "👥", "دوستان");
        addNav("profile", "●", "پروفایل");
    }

    private void addNav(String id, String icon, String label) {
        boolean active = id.equals(section);
        LinearLayout chip = Ui.horizontal(activity);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(Ui.dp(activity, 12), 0, Ui.dp(activity, 12), 0);
        chip.setBackground(active
                ? Ui.gradient(Color.rgb(255, 224, 122), Color.rgb(255, 188, 46), 15, Color.argb(120,255,239,173), 1, activity)
                : Ui.gradient(Color.argb(235, 38, 43, 63), Color.argb(235, 22, 25, 38), 15, Color.argb(30,255,255,255), 1, activity));
        TextView i = Ui.text(activity, icon, 13, active ? Color.rgb(52, 31, 0) : Ui.GOLD2, true);
        i.setGravity(Gravity.CENTER);
        TextView l = Ui.text(activity, label, 10.5f, active ? Color.rgb(52, 31, 0) : Ui.TEXT, true);
        l.setGravity(Gravity.CENTER);
        chip.addView(i);
        Ui.gap(chip, activity, 6);
        chip.addView(l);
        chip.setOnClickListener(v -> { section = id; renderNav(); renderSection(); });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(activity, 42));
        p.setMargins(Ui.dp(activity, 4), 0, Ui.dp(activity, 4), 0);
        navRow.addView(chip, p);
    }

    private void showLoading(String text) {
        body.removeAllViews();
        LinearLayout box = Ui.card(activity);
        box.setGravity(Gravity.CENTER);
        TextView t = Ui.text(activity, "🐹", 48, Ui.GOLD, false); t.setGravity(Gravity.CENTER);
        TextView m = Ui.text(activity, text, 13, Ui.MUTED, false); m.setGravity(Gravity.CENTER);
        box.addView(t, Ui.lpMatchWrap(activity, 8, 10));
        box.addView(m, Ui.lpMatchWrap(activity, 0, 8));
        ProgressBar pb = new ProgressBar(activity);
        box.addView(pb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 42)));
        body.addView(box, Ui.lpMatchWrap(activity, 28, 0));
    }

    private void showError(String msg) {
        body.removeAllViews();
        LinearLayout c = Ui.goldCard(activity);
        c.setGravity(Gravity.CENTER);
        TextView icon = Ui.text(activity, "!", 32, Ui.RED, true); icon.setGravity(Gravity.CENTER);
        TextView t = Ui.text(activity, msg, 13, Ui.MUTED, false); t.setGravity(Gravity.CENTER);
        c.addView(icon, Ui.lpMatchWrap(activity, 0, 8));
        c.addView(t, Ui.lpMatchWrap(activity, 0, 14));
        Button r = Ui.button(activity, "تلاش دوباره", true);
        r.setOnClickListener(v -> ensureSession());
        c.addView(r, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 48)));
        body.addView(c, Ui.lpMatchWrap(activity, 28, 0));
    }

    private void ensureSession() {
        if (loadingSession) return;
        loadingSession = true;
        if (token.isEmpty()) {
            String cookie = CookieManager.getInstance().getCookie(ApiClient.SITE);
            String recovered = extractCookie(cookie, "hamster_hamsterToken");
            if (recovered.isEmpty()) recovered = extractCookie(cookie, "hamster_session_token");
            if (recovered.matches("[a-fA-F0-9]{64}")) {
                token = recovered.toLowerCase();
                prefs.edit().putString("session_token", token).apply();
            }
        }
        api.post("auth.php?action=guest", new JSONObject(), token, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) {
                loadingSession = false;
                applyAuthResponse(json);
                activity.toast(json.optBoolean("guestResumed", false) || json.optBoolean("accountResumed", false)
                        ? "حساب قبلی بازیابی شد" : "بازی آماده است");
            }
            @Override public void fail(String message) { loadingSession = false; showError(message); }
        });
    }

    private String extractCookie(String all, String name) {
        if (all == null) return "";
        for (String part : all.split(";")) {
            String p = part.trim();
            int eq = p.indexOf('=');
            if (eq > 0 && p.substring(0, eq).trim().equals(name)) return p.substring(eq + 1).trim();
        }
        return "";
    }

    private void applyAuthResponse(JSONObject json) {
        String t = json.optString("token");
        if (!t.isEmpty()) { token = t; prefs.edit().putString("session_token", t).apply(); }
        applyGameResponse(json);
    }

    private void applyGameResponse(JSONObject json) {
        JSONObject u = json.optJSONObject("user"); if (u != null) user = u;
        JSONObject m = json.optJSONObject("missions"); if (m != null) missions = m;
        JSONArray c = json.optJSONArray("cups"); if (c != null) cups = c;
        JSONArray bc = json.optJSONArray("boostCosts"); if (bc != null) boostCosts = bc;
        renderSection();
        double passive = json.optDouble("passiveEarned", 0);
        if (passive > .5) activity.toast("+" + Ui.faNumber(passive) + " سکه درآمد آفلاین");
    }

    private JSONObject game() { JSONObject g = user.optJSONObject("game"); return g == null ? new JSONObject() : g; }
    private boolean isGuest() { return user.optBoolean("isGuest", true); }

    private void callGame(String action, JSONObject payload, boolean toastErrors, Runnable after) {
        api.post("game.php?action=" + action, payload, token, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) { applyGameResponse(json); if (after != null) after.run(); }
            @Override public void fail(String message) { if (toastErrors) activity.toast(message); if (after != null) after.run(); }
        });
    }

    private void renderSection() {
        if (user.length() == 0) { showLoading("در حال دریافت اطلاعات بازی..."); return; }
        switch (section) {
            case "boosts": renderBoosts(); break;
            case "missions": renderMissions(); break;
            case "league": renderLeague(); break;
            case "referral": renderReferral(); break;
            case "profile": renderProfile(); break;
            default: renderHome();
        }
    }

    private void renderHome() {
        body.removeAllViews();
        JSONObject g = game();
        String leagueCode = g.optString("league", "Bronze");
        String cupFa = currentCupFa(leagueCode);

        LinearLayout hello = Ui.horizontal(activity);
        LinearLayout helloText = Ui.vertical(activity);
        helloText.addView(Ui.text(activity, "سلام " + user.optString("displayName", "بازیکن") + " 👋", 18, Ui.TEXT, true));
        helloText.addView(Ui.text(activity, "برای بالا رفتن در لیگ آماده‌ای؟", 10.5f, Ui.MUTED, false), Ui.lpMatchWrap(activity, 2, 0));
        hello.addView(helloText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView acct = Ui.pill(activity, isGuest() ? "مهمان" : "حساب فعال", isGuest() ? Ui.GOLD2 : Ui.GREEN,
                isGuest() ? Color.argb(24,255,197,51) : Color.argb(24,74,211,155));
        hello.addView(acct);
        body.addView(hello, Ui.lpMatchWrap(activity, 0, 12));

        LinearLayout leagueCard = Ui.goldCard(activity);
        LinearLayout leagueRow = Ui.horizontal(activity);
        ImageView trophy = new ImageView(activity);
        trophy.setImageResource(cupDrawable(leagueCode));
        trophy.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        leagueRow.addView(trophy, new LinearLayout.LayoutParams(Ui.dp(activity, 72), Ui.dp(activity, 72)));
        Ui.gap(leagueRow, activity, 10);
        LinearLayout leagueInfo = Ui.vertical(activity);
        leagueInfo.addView(Ui.sectionEyebrow(activity, "لیگ فعلی"));
        leagueInfo.addView(Ui.text(activity, cupFa, 20, Ui.TEXT, true), Ui.lpMatchWrap(activity, 1, 3));
        leagueInfo.addView(Ui.text(activity, "با افزایش سکه به لیگ‌های بالاتر برس", 10, Ui.MUTED, false));
        leagueRow.addView(leagueInfo, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView arrow = Ui.text(activity, "‹", 30, Ui.GOLD2, true); arrow.setGravity(Gravity.CENTER);
        leagueRow.addView(arrow, new LinearLayout.LayoutParams(Ui.dp(activity, 32), Ui.dp(activity, 52)));
        leagueCard.addView(leagueRow);
        leagueCard.setOnClickListener(v -> { section = "league"; renderNav(); renderLeague(); });
        body.addView(leagueCard, Ui.lpMatchWrap(activity, 0, 14));

        TextView balanceLabel = Ui.text(activity, "موجودی شما", 11, Ui.MUTED, true); balanceLabel.setGravity(Gravity.CENTER);
        body.addView(balanceLabel, Ui.lpMatchWrap(activity, 1, 2));
        TextView balance = Ui.text(activity, "🪙  " + Ui.faNumber(g.optDouble("coins")), 31, Ui.TEXT, true); balance.setGravity(Gravity.CENTER);
        body.addView(balance, Ui.lpMatchWrap(activity, 0, 4));
        TextView hourly = Ui.text(activity, "+" + Ui.faNumber(g.optDouble("hourlyIncome")) + " سکه در ساعت", 11, Ui.GREEN, true); hourly.setGravity(Gravity.CENTER);
        body.addView(hourly, Ui.lpMatchWrap(activity, 0, 8));

        FrameLayout tapFrame = new FrameLayout(activity);
        tapFrame.setBackground(Ui.ovalGradient(Color.rgb(63, 47, 20), Color.rgb(15, 16, 23), Color.argb(160,255,197,51), 2, activity));
        if (android.os.Build.VERSION.SDK_INT >= 21) tapFrame.setElevation(Ui.dp(activity, 6));
        ImageView hamster = new ImageView(activity);
        hamster.setImageResource(R.drawable.tap_hamster);
        hamster.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        hamster.setPadding(Ui.dp(activity, 8), Ui.dp(activity, 8), Ui.dp(activity, 8), Ui.dp(activity, 8));
        hamster.setOnClickListener(v -> onTapHamster(hamster));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        hp.setMargins(Ui.dp(activity, 5), Ui.dp(activity, 5), Ui.dp(activity, 5), Ui.dp(activity, 5));
        tapFrame.addView(hamster, hp);
        LinearLayout.LayoutParams tapLp = new LinearLayout.LayoutParams(Ui.dp(activity, 310), Ui.dp(activity, 310));
        tapLp.gravity = Gravity.CENTER_HORIZONTAL;
        tapLp.setMargins(0, Ui.dp(activity, 4), 0, Ui.dp(activity, 8));
        body.addView(tapFrame, tapLp);

        TextView tapHint = Ui.pill(activity, "برای کسب سکه روی همستر ضربه بزن", Ui.GOLD2, Color.argb(24,255,197,51));
        LinearLayout hintWrap = Ui.horizontal(activity); hintWrap.setGravity(Gravity.CENTER); hintWrap.addView(tapHint);
        body.addView(hintWrap, Ui.lpMatchWrap(activity, 0, 12));

        LinearLayout stats = Ui.horizontal(activity);
        stats.addView(statBox("قدرت ضربه", Ui.faNumber(g.optDouble("power", 1)), "👆", Ui.GOLD2), Ui.lpWeight(1));
        Ui.gap(stats, activity, 8);
        stats.addView(statBox("کل ضربه", Ui.faNumber(g.optDouble("taps")), "✦", Ui.BLUE), Ui.lpWeight(1));
        Ui.gap(stats, activity, 8);
        stats.addView(statBox("در ساعت", Ui.faNumber(g.optDouble("hourlyIncome")), "⏱", Ui.GREEN), Ui.lpWeight(1));
        body.addView(stats, Ui.lpMatchWrap(activity, 0, 12));

        double energy = g.optDouble("energy");
        double max = Math.max(1, g.optDouble("maxEnergy", 1000));
        LinearLayout energyCard = Ui.card(activity);
        LinearLayout energyHead = Ui.horizontal(activity);
        energyHead.addView(Ui.text(activity, "⚡ انرژی", 13, Ui.TEXT, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        energyHead.addView(Ui.text(activity, Ui.faNumber(energy) + " / " + Ui.faNumber(max), 12, Ui.GOLD2, true));
        energyCard.addView(energyHead, Ui.lpMatchWrap(activity, 0, 9));
        energyCard.addView(Ui.progress(activity, energy / max), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 9)));
        body.addView(energyCard, Ui.lpMatchWrap(activity, 0, 10));

        LinearLayout quick = Ui.horizontal(activity);
        Button turbo = Ui.button(activity, "🚀 توربو  " + Math.max(0, 3 - g.optInt("turboUsed")) + "/3", false);
        Button fill = Ui.button(activity, "⚡ انرژی فوری  " + Math.max(0, 3 - g.optInt("instantEnergyUsed")) + "/3", false);
        turbo.setOnClickListener(v -> quickBoost("turbo"));
        fill.setOnClickListener(v -> quickBoost("energy"));
        quick.addView(turbo, Ui.lpWeight(1)); Ui.gap(quick, activity, 8); quick.addView(fill, Ui.lpWeight(1));
        body.addView(quick, Ui.lpMatchWrap(activity, 0, 10));

        if (g.optLong("turboUntil", 0) > System.currentTimeMillis() / 1000L) {
            LinearLayout activeCard = Ui.softCard(activity);
            TextView active = Ui.text(activity, "🚀 توربو فعال است؛ قدرت ضربه دو برابر شده", 11.5f, Ui.GREEN, true);
            active.setGravity(Gravity.CENTER);
            activeCard.addView(active);
            body.addView(activeCard, Ui.lpMatchWrap(activity, 0, 7));
        }
    }

    private View statBox(String label, String value, String icon, int accent) {
        LinearLayout c = Ui.softCard(activity);
        c.setGravity(Gravity.CENTER);
        TextView i = Ui.text(activity, icon, 18, accent, false); i.setGravity(Gravity.CENTER);
        TextView v = Ui.text(activity, value, 13.5f, Ui.TEXT, true); v.setGravity(Gravity.CENTER);
        TextView l = Ui.text(activity, label, 9, Ui.MUTED, false); l.setGravity(Gravity.CENTER);
        c.addView(i, Ui.lpMatchWrap(activity, 0, 3));
        c.addView(v, Ui.lpMatchWrap(activity, 0, 1));
        c.addView(l);
        return c;
    }

    private String currentCupFa(String code) {
        for (int i = 0; i < cups.length(); i++) {
            JSONObject c = cups.optJSONObject(i);
            if (c != null && code.equalsIgnoreCase(c.optString("name"))) return c.optString("fa", code);
        }
        return code;
    }

    private int cupDrawable(String code) {
        String s = code == null ? "bronze" : code.toLowerCase(java.util.Locale.US).replace(" ", "");
        if (s.contains("silver")) return R.drawable.cup_silver;
        if (s.contains("gold")) return R.drawable.cup_gold;
        if (s.contains("platinum")) return R.drawable.cup_platinum;
        if (s.contains("diamond")) return R.drawable.cup_diamond;
        if (s.contains("grandmaster")) return R.drawable.cup_grandmaster;
        if (s.contains("master")) return R.drawable.cup_master;
        if (s.contains("champion")) return R.drawable.cup_champion;
        if (s.contains("legend")) return R.drawable.cup_legends;
        return R.drawable.cup_bronze;
    }

    private void onTapHamster(ImageView hamster) {
        JSONObject g = game();
        double power = g.optDouble("power", 1);
        if (g.optLong("turboUntil", 0) > System.currentTimeMillis() / 1000L) power *= 2;
        if (g.optDouble("energy") < power) { activity.toast("انرژی کافی نیست"); return; }
        pendingTaps = Math.min(250, pendingTaps + 1);
        hamster.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
        ObjectAnimator sx = ObjectAnimator.ofFloat(hamster, "scaleX", 1f, .91f, 1.025f, 1f);
        ObjectAnimator sy = ObjectAnimator.ofFloat(hamster, "scaleY", 1f, .91f, 1.025f, 1f);
        sx.setDuration(145); sy.setDuration(145); sx.start(); sy.start();
        handler.removeCallbacks(flushTapRunnable);
        handler.postDelayed(flushTapRunnable, 85);
    }

    private final Runnable flushTapRunnable = this::flushTaps;

    private void flushTaps() {
        if (tapRequestInFlight || pendingTaps <= 0 || token.isEmpty()) return;
        int count = Math.min(25, pendingTaps);
        pendingTaps -= count;
        tapRequestInFlight = true;
        JSONObject b = new JSONObject();
        try { b.put("count", count); } catch (Exception ignored) { }
        api.post("game.php?action=tap", b, token, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) {
                tapRequestInFlight = false;
                applyGameResponse(json);
                if (pendingTaps > 0) handler.postDelayed(flushTapRunnable, 40);
            }
            @Override public void fail(String message) {
                tapRequestInFlight = false;
                activity.toast(message);
                pendingTaps = 0;
            }
        });
    }

    private void quickBoost(String type) {
        JSONObject b = new JSONObject();
        try { b.put("type", type); } catch (Exception ignored) { }
        callGame("quick_boost", b, true, null);
    }

    private View sectionTitle(String eyebrow, String title, String sub) {
        LinearLayout v = Ui.vertical(activity);
        v.addView(Ui.sectionEyebrow(activity, eyebrow));
        v.addView(Ui.text(activity, title, 22, Ui.TEXT, true), Ui.lpMatchWrap(activity, 2, 2));
        v.addView(Ui.text(activity, sub, 11, Ui.MUTED, false));
        return v;
    }

    private void renderBoosts() {
        body.removeAllViews();
        body.addView(sectionTitle("POWER UPS", "قدرت‌ها و ارتقاها", "با ارتقا، سرعت پیشرفتت را چند برابر کن."), Ui.lpMatchWrap(activity, 0, 13));
        JSONObject g = game();
        body.addView(boostCard("👆", "قدرت ضربه", "هر ضربه سکه بیشتری می‌دهد", "power", g.optInt("tapLevel", 1), Ui.GOLD2), Ui.lpMatchWrap(activity, 0, 10));
        body.addView(boostCard("🔋", "ظرفیت انرژی", "حداکثر انرژی را بیشتر می‌کند", "energy", g.optInt("energyLevel", 1), Ui.BLUE), Ui.lpMatchWrap(activity, 0, 10));
        body.addView(boostCard("⚡", "سرعت شارژ", "انرژی سریع‌تر بازیابی می‌شود", "recharge", g.optInt("rechargeLevel", 1), Ui.GREEN), Ui.lpMatchWrap(activity, 0, 12));

        LinearLayout q = Ui.goldCard(activity);
        q.addView(Ui.text(activity, "بوست‌های روزانه", 17, Ui.TEXT, true), Ui.lpMatchWrap(activity, 0, 3));
        q.addView(Ui.text(activity, "هرکدام روزانه ۳ بار قابل استفاده‌اند.", 10.5f, Ui.MUTED, false), Ui.lpMatchWrap(activity, 0, 12));
        Button e = Ui.button(activity, "⚡ پرکردن کامل انرژی · " + Math.max(0, 3 - g.optInt("instantEnergyUsed")) + " بار باقی‌مانده", false);
        e.setOnClickListener(v -> quickBoost("energy"));
        q.addView(e, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 50)));
        Button t = Ui.button(activity, "🚀 توربو ۳۰ ثانیه · " + Math.max(0, 3 - g.optInt("turboUsed")) + " بار باقی‌مانده", true);
        t.setOnClickListener(v -> quickBoost("turbo"));
        q.addView(t, Ui.lpMatchWrap(activity, 9, 0));
        body.addView(q, Ui.lpMatchWrap(activity, 0, 0));
    }

    private View boostCard(String icon, String title, String desc, String type, int level, int accent) {
        LinearLayout c = Ui.card(activity);
        LinearLayout h = Ui.horizontal(activity);
        TextView badge = Ui.text(activity, icon, 26, accent, false); badge.setGravity(Gravity.CENTER);
        badge.setBackground(Ui.bg(Color.argb(28,255,255,255), 15, Color.argb(28,255,255,255), 1, activity));
        h.addView(badge, new LinearLayout.LayoutParams(Ui.dp(activity, 54), Ui.dp(activity, 54)));
        Ui.gap(h, activity, 11);
        LinearLayout info = Ui.vertical(activity);
        info.addView(Ui.text(activity, title, 15.5f, Ui.TEXT, true));
        info.addView(Ui.text(activity, desc, 10, Ui.MUTED, false), Ui.lpMatchWrap(activity, 3, 3));
        info.addView(Ui.text(activity, "سطح " + level + " از ۲۰", 10, accent, true));
        h.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        c.addView(h);
        c.addView(Ui.progress(activity, level / 20.0), Ui.lpMatchWrap(activity, 11, 10));
        if (level < 20) {
            double cost = level - 1 < boostCosts.length() ? boostCosts.optDouble(level - 1, 0) : 0;
            Button b = Ui.button(activity, "ارتقا  ·  " + Ui.faNumber(cost) + " سکه", true);
            b.setOnClickListener(v -> {
                JSONObject p = new JSONObject(); try { p.put("type", type); } catch (Exception ignored) { }
                callGame("boost_upgrade", p, true, null);
            });
            c.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 49)));
        } else {
            TextView max = Ui.pill(activity, "✓ حداکثر سطح", Ui.GREEN, Color.argb(25,74,211,155));
            LinearLayout w = Ui.horizontal(activity); w.setGravity(Gravity.CENTER); w.addView(max); c.addView(w, Ui.lpMatchWrap(activity, 2, 0));
        }
        return c;
    }

    private void renderMissions() {
        body.removeAllViews();
        body.addView(sectionTitle("MISSIONS", "مأموریت‌ها", "کارت‌ها را ارتقا بده و درآمد ساعتی بساز."), Ui.lpMatchWrap(activity, 0, 10));

        JSONArray cats = missions.optJSONArray("categories");
        HorizontalScrollView hsv = new HorizontalScrollView(activity); hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = Ui.horizontal(activity); addMissionChip(row, "", "همه");
        if (cats != null) for (int i = 0; i < cats.length(); i++) {
            JSONObject c = cats.optJSONObject(i); if (c != null && c.optBoolean("active", true)) addMissionChip(row, c.optString("id"), c.optString("name"));
        }
        hsv.addView(row, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        body.addView(hsv, Ui.lpMatchWrap(activity, 0, 12));

        JSONArray items = missions.optJSONArray("missions");
        if (items == null || items.length() == 0) { body.addView(emptyCard("هنوز مأموریتی منتشر نشده است.")); return; }
        JSONObject levels = game().optJSONObject("missionLevels");
        int shown = 0;
        for (int i = 0; i < items.length(); i++) {
            JSONObject m = items.optJSONObject(i);
            if (m == null || !m.optBoolean("active", true)) continue;
            if (!missionCategory.isEmpty() && !missionCategory.equals(m.optString("category"))) continue;
            int level = levels == null ? 0 : levels.optInt(m.optString("id"), 0);
            body.addView(missionCard(m, level), Ui.lpMatchWrap(activity, 0, 10));
            shown++;
        }
        if (shown == 0) body.addView(emptyCard("در این دسته مأموریتی وجود ندارد."));
    }

    private void addMissionChip(LinearLayout row, String id, String name) {
        boolean active = id.equals(missionCategory);
        Button b = Ui.button(activity, name, active);
        b.setTextSize(10.5f);
        b.setOnClickListener(v -> { missionCategory = id; renderMissions(); });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(activity, 40));
        p.setMargins(Ui.dp(activity, 4), 0, Ui.dp(activity, 4), 0);
        row.addView(b, p);
    }

    private View missionCard(JSONObject m, int level) {
        LinearLayout c = Ui.card(activity);
        LinearLayout top = Ui.horizontal(activity);
        String img = ApiClient.absolute(m.optString("image"));
        if (!img.isEmpty()) {
            ImageView im = new ImageView(activity); im.setScaleType(ImageView.ScaleType.CENTER_CROP);
            im.setBackground(Ui.bg(Ui.PANEL2, 16, Color.argb(40,255,255,255), 1, activity));
            top.addView(im, new LinearLayout.LayoutParams(Ui.dp(activity, 78), Ui.dp(activity, 78)));
            images.load(im, img); Ui.gap(top, activity, 11);
        } else {
            TextView icon = Ui.text(activity, "◆", 28, Ui.GOLD2, true); icon.setGravity(Gravity.CENTER);
            icon.setBackground(Ui.bg(Color.argb(26,255,197,51), 16, Color.argb(70,255,197,51), 1, activity));
            top.addView(icon, new LinearLayout.LayoutParams(Ui.dp(activity, 64), Ui.dp(activity, 64))); Ui.gap(top, activity, 11);
        }
        LinearLayout info = Ui.vertical(activity);
        info.addView(Ui.text(activity, m.optString("title"), 15.5f, Ui.TEXT, true));
        info.addView(Ui.text(activity, m.optString("description"), 10, Ui.MUTED, false), Ui.lpMatchWrap(activity, 4, 5));
        info.addView(Ui.text(activity, "سطح " + level + " / " + m.optInt("maxLevel", 0), 10, Ui.GOLD2, true));
        top.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        c.addView(top);

        JSONArray lv = m.optJSONArray("levels");
        if (lv != null && level < lv.length()) {
            JSONObject next = lv.optJSONObject(level);
            double cost = next == null ? 0 : next.optDouble("upgradeCost");
            double inc = next == null ? 0 : next.optDouble("profitIncrement", next.optDouble("hourlyIncome"));
            LinearLayout meta = Ui.horizontal(activity);
            meta.addView(Ui.pill(activity, "+" + Ui.faNumber(inc) + "/ساعت", Ui.GREEN, Color.argb(22,74,211,155)));
            Ui.gap(meta, activity, 7);
            meta.addView(Ui.pill(activity, Ui.faNumber(cost) + " سکه", Ui.GOLD2, Color.argb(22,255,197,51)));
            c.addView(meta, Ui.lpMatchWrap(activity, 11, 9));
            Button b = Ui.button(activity, "ارتقای کارت", true);
            b.setOnClickListener(v -> {
                JSONObject p = new JSONObject(); try { p.put("missionId", m.optString("id")); } catch (Exception ignored) { }
                callGame("mission_upgrade", p, true, null);
            });
            c.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 48)));
        } else {
            TextView max = Ui.pill(activity, "✓ حداکثر سطح", Ui.GREEN, Color.argb(22,74,211,155));
            LinearLayout w = Ui.horizontal(activity); w.setGravity(Gravity.CENTER); w.addView(max); c.addView(w, Ui.lpMatchWrap(activity, 11, 0));
        }
        return c;
    }

    private View emptyCard(String message) {
        LinearLayout c = Ui.card(activity);
        TextView icon = Ui.text(activity, "◇", 32, Ui.GOLD2, true); icon.setGravity(Gravity.CENTER);
        TextView m = Ui.text(activity, message, 12, Ui.MUTED, false); m.setGravity(Gravity.CENTER);
        c.addView(icon, Ui.lpMatchWrap(activity, 5, 7)); c.addView(m, Ui.lpMatchWrap(activity, 0, 5));
        return c;
    }

    private void renderLeague() {
        body.removeAllViews();
        JSONObject g = game();
        String code = g.optString("league", "Bronze");
        LinearLayout hero = Ui.goldCard(activity);
        hero.setGravity(Gravity.CENTER);
        ImageView cup = new ImageView(activity); cup.setImageResource(cupDrawable(code)); cup.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        hero.addView(cup, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 180)));
        TextView name = Ui.text(activity, currentCupFa(code), 25, Ui.TEXT, true); name.setGravity(Gravity.CENTER);
        hero.addView(name, Ui.lpMatchWrap(activity, 0, 3));
        TextView sub = Ui.text(activity, "لیگ فعلی شما", 10.5f, Ui.GOLD2, true); sub.setGravity(Gravity.CENTER); hero.addView(sub);
        body.addView(hero, Ui.lpMatchWrap(activity, 0, 13));

        LinearLayout cupsRow = Ui.horizontal(activity);
        for (int i = 0; i < cups.length(); i++) {
            JSONObject c = cups.optJSONObject(i); if (c == null) continue;
            boolean active = code.equalsIgnoreCase(c.optString("name"));
            TextView t = Ui.text(activity, active ? "●" : "•", active ? 12 : 10, active ? Ui.GOLD2 : Ui.MUTED2, active);
            t.setGravity(Gravity.CENTER);
            cupsRow.addView(t, Ui.lpWeight(1));
        }
        body.addView(cupsRow, Ui.lpMatchWrap(activity, 0, 12));
        TextView loading = Ui.text(activity, "در حال دریافت رتبه‌بندی...", 11.5f, Ui.MUTED, false); loading.setGravity(Gravity.CENTER);
        body.addView(loading);
        JSONObject p = new JSONObject(); try { p.put("cup", code); } catch (Exception ignored) { }
        api.post("game.php?action=leaderboard", p, token, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) { renderLeaderboard(json); }
            @Override public void fail(String message) { activity.toast(message); }
        });
    }

    private void renderLeaderboard(JSONObject json) {
        if (!"league".equals(section)) return;
        body.removeAllViews();
        String code = json.optString("cup", game().optString("league", "Bronze"));
        body.addView(sectionTitle("LEADERBOARD", "لیگ " + currentCupFa(code),
                "رتبه شما: " + (json.isNull("currentRank") ? "در حال محاسبه" : json.optInt("currentRank")) + "  ·  اعضا: " + json.optInt("totalInLeague")), Ui.lpMatchWrap(activity, 0, 12));
        JSONArray arr = json.optJSONArray("leaders");
        if (arr == null || arr.length() == 0) { body.addView(emptyCard("هنوز بازیکنی در این لیگ ثبت نشده است.")); return; }
        for (int i = 0; i < arr.length(); i++) {
            JSONObject r = arr.optJSONObject(i); if (r == null) continue;
            boolean me = r.optBoolean("isMe");
            LinearLayout c = me ? Ui.goldCard(activity) : Ui.card(activity);
            LinearLayout h = Ui.horizontal(activity);
            TextView rank = Ui.text(activity, "#" + r.optInt("rank"), 13, me ? Ui.GOLD2 : Ui.TEXT, true); rank.setGravity(Gravity.CENTER);
            rank.setBackground(Ui.bg(Color.argb(28,255,255,255), 12, Color.argb(30,255,255,255), 1, activity));
            h.addView(rank, new LinearLayout.LayoutParams(Ui.dp(activity, 48), Ui.dp(activity, 42)));
            Ui.gap(h, activity, 10);
            LinearLayout info = Ui.vertical(activity);
            info.addView(Ui.text(activity, r.optString("displayName", "بازیکن"), 13.5f, Ui.TEXT, true));
            info.addView(Ui.text(activity, me ? "این شما هستید" : "بازیکن لیگ", 9.5f, me ? Ui.GOLD2 : Ui.MUTED, false), Ui.lpMatchWrap(activity, 2, 0));
            h.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            h.addView(Ui.text(activity, Ui.faNumber(r.optDouble("coins")) + " 🪙", 11.5f, Ui.GOLD2, true));
            c.addView(h);
            body.addView(c, Ui.lpMatchWrap(activity, 0, 8));
        }
    }

    private void renderReferral() {
        body.removeAllViews();
        body.addView(sectionTitle("FRIENDS", "دعوت دوستان", "دوستانت را دعوت کن و از پیشرفت آن‌ها پاداش بگیر."), Ui.lpMatchWrap(activity, 0, 12));
        api.post("game.php?action=referral", new JSONObject(), token, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) { JSONObject r = json.optJSONObject("referral"); if (r != null) renderReferralData(r); }
            @Override public void fail(String message) { activity.toast(message); }
        });
    }

    private void renderReferralData(JSONObject r) {
        if (!"referral".equals(section)) return;
        body.removeAllViews();
        body.addView(sectionTitle("FRIENDS", "دعوت دوستان", "پاداش ثبت‌نام هر نفر " + Ui.faNumber(r.optDouble("signupReward", 2500)) + " سکه"), Ui.lpMatchWrap(activity, 0, 12));

        LinearLayout code = Ui.goldCard(activity); code.setGravity(Gravity.CENTER);
        TextView small = Ui.sectionEyebrow(activity, "کد دعوت اختصاصی"); small.setGravity(Gravity.CENTER); code.addView(small);
        TextView c = Ui.text(activity, r.optString("code", "—"), 27, Ui.GOLD2, true); c.setGravity(Gravity.CENTER);
        c.setTextIsSelectable(true);
        c.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager)activity.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Hamster invite", r.optString("code")));
            activity.toast("کد دعوت کپی شد");
        });
        code.addView(c, Ui.lpMatchWrap(activity, 8, 6));
        TextView hint = Ui.text(activity, "برای کپی، کد را لمس کن", 10, Ui.MUTED, false); hint.setGravity(Gravity.CENTER); code.addView(hint);
        body.addView(code, Ui.lpMatchWrap(activity, 0, 12));

        JSONObject totals = r.optJSONObject("totals");
        LinearLayout stats = Ui.horizontal(activity);
        stats.addView(statBox("زیرمجموعه", String.valueOf(r.optInt("invitedCount")), "👥", Ui.BLUE), Ui.lpWeight(1));
        Ui.gap(stats, activity, 8);
        stats.addView(statBox("کل پاداش", Ui.faNumber(totals == null ? 0 : totals.optDouble("total")), "🎁", Ui.GOLD2), Ui.lpWeight(1));
        body.addView(stats, Ui.lpMatchWrap(activity, 0, 13));

        JSONArray invited = r.optJSONArray("invited");
        if (invited != null && invited.length() > 0) {
            body.addView(Ui.text(activity, "زیرمجموعه‌های شما", 16, Ui.TEXT, true), Ui.lpMatchWrap(activity, 2, 9));
            for (int i = 0; i < invited.length(); i++) {
                JSONObject x = invited.optJSONObject(i); if (x == null) continue;
                LinearLayout row = Ui.card(activity); LinearLayout h = Ui.horizontal(activity);
                TextView av = Ui.text(activity, "🐹", 22, Ui.GOLD2, false); av.setGravity(Gravity.CENTER);
                av.setBackground(Ui.bg(Color.argb(25,255,197,51), 99, Color.argb(60,255,197,51), 1, activity));
                h.addView(av, new LinearLayout.LayoutParams(Ui.dp(activity, 44), Ui.dp(activity, 44)));
                Ui.gap(h, activity, 9);
                h.addView(Ui.text(activity, x.optString("displayName"), 12.5f, Ui.TEXT, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                h.addView(Ui.pill(activity, currentCupFa(x.optString("league")), Ui.GOLD2, Color.argb(22,255,197,51)));
                row.addView(h); body.addView(row, Ui.lpMatchWrap(activity, 0, 7));
            }
        }
    }

    private void renderProfile() {
        body.removeAllViews();
        JSONObject g = game();
        LinearLayout card = Ui.goldCard(activity); card.setGravity(Gravity.CENTER);
        TextView avatar = Ui.text(activity, "🐹", 55, Ui.GOLD, false); avatar.setGravity(Gravity.CENTER);
        avatar.setBackground(Ui.ovalGradient(Color.rgb(61,43,19), Color.rgb(24,24,29), Color.argb(140,255,197,51), 2, activity));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(Ui.dp(activity, 96), Ui.dp(activity, 96)); ap.gravity = Gravity.CENTER_HORIZONTAL;
        card.addView(avatar, ap);
        TextView name = Ui.text(activity, user.optString("displayName", "بازیکن"), 22, Ui.TEXT, true); name.setGravity(Gravity.CENTER); card.addView(name, Ui.lpMatchWrap(activity, 12, 3));
        TextView id = Ui.text(activity, user.optString("userId", ""), 9.5f, Ui.MUTED, false); id.setGravity(Gravity.CENTER); id.setTextIsSelectable(true); card.addView(id);
        TextView badge = Ui.pill(activity, (isGuest() ? "حساب مهمان" : "حساب ثبت‌شده") + "  ·  " + currentCupFa(g.optString("league", "Bronze")), Ui.GOLD2, Color.argb(22,255,197,51));
        LinearLayout badgeWrap = Ui.horizontal(activity); badgeWrap.setGravity(Gravity.CENTER); badgeWrap.addView(badge); card.addView(badgeWrap, Ui.lpMatchWrap(activity, 11, 2));
        body.addView(card, Ui.lpMatchWrap(activity, 0, 12));

        LinearLayout stats = Ui.horizontal(activity);
        stats.addView(statBox("سکه", Ui.faNumber(g.optDouble("coins")), "🪙", Ui.GOLD2), Ui.lpWeight(1)); Ui.gap(stats, activity, 8);
        stats.addView(statBox("ضربه‌ها", Ui.faNumber(g.optDouble("taps")), "👆", Ui.BLUE), Ui.lpWeight(1));
        body.addView(stats, Ui.lpMatchWrap(activity, 0, 12));

        if (isGuest()) {
            LinearLayout saveCard = Ui.card(activity);
            saveCard.addView(Ui.text(activity, "پیشرفتت را از دست نده", 16, Ui.TEXT, true));
            saveCard.addView(Ui.text(activity, "با ثبت حساب، سکه‌ها و تمام پیشرفت فعلی حفظ می‌شود.", 10.5f, Ui.MUTED, false), Ui.lpMatchWrap(activity, 4, 12));
            Button save = Ui.button(activity, "ثبت حساب و حفظ پیشرفت", true); save.setOnClickListener(v -> showRegisterDialog());
            saveCard.addView(save, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 50)));
            Button login = Ui.button(activity, "ورود به حساب قبلی", false); login.setOnClickListener(v -> showLoginDialog());
            saveCard.addView(login, Ui.lpMatchWrap(activity, 8, 0));
            body.addView(saveCard);
        } else {
            LinearLayout account = Ui.card(activity);
            account.addView(Ui.text(activity, "حساب کاربری", 16, Ui.TEXT, true));
            account.addView(Ui.text(activity, user.optString("email"), 11, Ui.MUTED, false), Ui.lpMatchWrap(activity, 4, 12));
            Button rename = Ui.button(activity, "ویرایش نام کاربری", false); rename.setOnClickListener(v -> showRenameDialog());
            account.addView(rename, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 48)));
            Button logout = Ui.button(activity, "خروج از حساب", false); logout.setTextColor(Ui.RED); logout.setOnClickListener(v -> logout());
            account.addView(logout, Ui.lpMatchWrap(activity, 8, 0));
            body.addView(account);
        }
    }

    private EditText input(String hint, boolean password) {
        EditText e = new EditText(activity);
        e.setHint(hint); e.setHintTextColor(Color.rgb(125, 130, 145)); e.setTextColor(Color.rgb(30, 30, 35)); e.setTextSize(14); e.setSingleLine(true);
        if (password) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        e.setPadding(Ui.dp(activity, 12), 0, Ui.dp(activity, 12), 0);
        e.setBackground(Ui.bg(Color.rgb(247, 248, 250), 12, Color.rgb(220, 222, 228), 1, activity));
        return e;
    }

    private void showRegisterDialog() {
        LinearLayout f = Ui.vertical(activity); f.setPadding(Ui.dp(activity, 20), 5, Ui.dp(activity, 20), 5);
        EditText name = input("نام کاربری", false), email = input("ایمیل", false), pass = input("رمز عبور (حداقل ۸ کاراکتر)", true), confirm = input("تکرار رمز", true), invite = input("کد دعوت (اختیاری)", false);
        for (EditText e : new EditText[]{name,email,pass,confirm,invite}) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 48)); p.setMargins(0,4,0,4); f.addView(e,p); }
        AlertDialog d = new AlertDialog.Builder(activity).setTitle("ثبت حساب و حفظ پیشرفت").setView(f).setNegativeButton("انصراف", null).setPositiveButton("ثبت حساب", null).create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            JSONObject b = new JSONObject(); try { b.put("displayName", name.getText().toString().trim()); b.put("email", email.getText().toString().trim()); b.put("password", pass.getText().toString()); b.put("confirmPassword", confirm.getText().toString()); b.put("inviteCode", invite.getText().toString().trim()); } catch (Exception ignored) {}
            api.post("auth.php?action=convert_guest", b, token, new ApiClient.Callback() {
                @Override public void ok(JSONObject j) { applyAuthResponse(j); d.dismiss(); activity.toast("حساب با حفظ پیشرفت ثبت شد"); }
                @Override public void fail(String m) { activity.toast(m); }
            });
        })); d.show();
    }

    private void showLoginDialog() {
        LinearLayout f = Ui.vertical(activity); f.setPadding(Ui.dp(activity, 20), 5, Ui.dp(activity, 20), 5);
        EditText email = input("ایمیل حساب قبلی", false), pass = input("رمز عبور", true);
        f.addView(email, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 50)));
        f.addView(pass, Ui.lpMatchWrap(activity, 7, 0));
        Button forgot = Ui.button(activity, "فراموشی رمز عبور", false); f.addView(forgot, Ui.lpMatchWrap(activity, 8, 0));
        AlertDialog d = new AlertDialog.Builder(activity).setTitle("ورود به حساب قبلی").setMessage("با ورود، حساب مهمان فعلی جایگزین حساب قبلی می‌شود.").setView(f).setNegativeButton("انصراف", null).setPositiveButton("ورود", null).create();
        forgot.setOnClickListener(v -> showForgotDialog(email.getText().toString().trim()));
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            JSONObject b = new JSONObject(); try { b.put("email", email.getText().toString().trim()); b.put("password", pass.getText().toString()); } catch (Exception ignored) {}
            api.post("auth.php?action=login_guest", b, token, new ApiClient.Callback() {
                @Override public void ok(JSONObject j) { applyAuthResponse(j); d.dismiss(); activity.toast("حساب قبلی بازیابی شد"); }
                @Override public void fail(String m) { activity.toast(m); }
            });
        })); d.show();
    }

    private void showForgotDialog(String initial) {
        LinearLayout f = Ui.vertical(activity); f.setPadding(Ui.dp(activity, 20), 5, Ui.dp(activity, 20), 5);
        EditText email = input("ایمیل", false); email.setText(initial); f.addView(email, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 50)));
        AlertDialog d = new AlertDialog.Builder(activity).setTitle("بازیابی رمز").setView(f).setNegativeButton("انصراف", null).setPositiveButton("ارسال کد", null).create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            JSONObject b = new JSONObject(); try { b.put("email", email.getText().toString().trim()); } catch (Exception ignored) {}
            api.post("auth.php?action=forgot", b, token, new ApiClient.Callback() {
                @Override public void ok(JSONObject j) { d.dismiss(); showResetDialog(email.getText().toString().trim()); activity.toast("در صورت ثبت بودن ایمیل، کد ارسال شد"); }
                @Override public void fail(String m) { activity.toast(m); }
            });
        })); d.show();
    }

    private void showResetDialog(String email) {
        LinearLayout f = Ui.vertical(activity); f.setPadding(Ui.dp(activity, 20), 5, Ui.dp(activity, 20), 5);
        EditText code = input("کد ۶ رقمی", false), pass = input("رمز جدید", true), confirm = input("تکرار رمز جدید", true);
        f.addView(code, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 50))); f.addView(pass, Ui.lpMatchWrap(activity, 7, 0)); f.addView(confirm, Ui.lpMatchWrap(activity, 7, 0));
        AlertDialog d = new AlertDialog.Builder(activity).setTitle("رمز جدید").setView(f).setNegativeButton("انصراف", null).setPositiveButton("تغییر رمز", null).create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            JSONObject b = new JSONObject(); try { b.put("email", email); b.put("code", code.getText().toString().trim()); b.put("password", pass.getText().toString()); b.put("confirmPassword", confirm.getText().toString()); } catch (Exception ignored) {}
            api.post("auth.php?action=reset", b, token, new ApiClient.Callback() {
                @Override public void ok(JSONObject j) { d.dismiss(); activity.toast("رمز عبور تغییر کرد"); }
                @Override public void fail(String m) { activity.toast(m); }
            });
        })); d.show();
    }

    private void showRenameDialog() {
        EditText e = input("نام کاربری", false); e.setText(user.optString("displayName"));
        LinearLayout f = Ui.vertical(activity); f.setPadding(Ui.dp(activity, 20), 5, Ui.dp(activity, 20), 5); f.addView(e, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 50)));
        AlertDialog d = new AlertDialog.Builder(activity).setTitle("ویرایش نام کاربری").setView(f).setNegativeButton("انصراف", null).setPositiveButton("ذخیره", null).create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            JSONObject b = new JSONObject(); try { b.put("displayName", e.getText().toString().trim()); } catch (Exception ignored) {}
            api.post("auth.php?action=profile_update", b, token, new ApiClient.Callback() {
                @Override public void ok(JSONObject j) { JSONObject u = j.optJSONObject("user"); if (u != null) user = u; d.dismiss(); renderProfile(); activity.toast("نام ذخیره شد"); }
                @Override public void fail(String m) { activity.toast(m); }
            });
        })); d.show();
    }

    private void logout() {
        new AlertDialog.Builder(activity).setTitle("خروج از حساب").setMessage("از حساب ثبت‌شده خارج می‌شوی و یک حساب مهمان جدید ساخته می‌شود.")
                .setNegativeButton("انصراف", null)
                .setPositiveButton("خروج", (d,w) -> api.post("auth.php?action=logout", new JSONObject(), token, new ApiClient.Callback() {
                    @Override public void ok(JSONObject j) { token = ""; prefs.edit().remove("session_token").apply(); user = new JSONObject(); missions = new JSONObject(); showLoading("در حال ساخت حساب مهمان..."); ensureSession(); }
                    @Override public void fail(String m) { activity.toast(m); }
                })).show();
    }
}
