package com.maniplus.notcoin;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private final ApiClient api = new ApiClient();
    private final ImageLoader images = new ImageLoader();
    private SharedPreferences prefs;
    private FrameLayout content;
    private LinearLayout tutorialsTab, gameTab;
    private TextView tutorialsIcon, tutorialsLabel, gameIcon, gameLabel;
    private JSONObject appConfig = new JSONObject();
    private TutorialsController tutorials;
    private GameController game;
    private String activeTab = "tutorials";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("hamster_native", Context.MODE_PRIVATE);
        styleSystemBars();
        buildShell();
        loadCachedConfig();
        String initial = appConfig.optString("defaultTab", "tutorials");
        showTab(initial, false);
        refreshConfig(true);
    }

    private void styleSystemBars() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 21) {
            w.setStatusBarColor(Color.rgb(5, 6, 10));
            w.setNavigationBarColor(Color.rgb(5, 6, 10));
        }
        if (Build.VERSION.SDK_INT >= 23) {
            w.getDecorView().setSystemUiVisibility(0);
        }
    }

    private void buildShell() {
        FrameLayout scene = new FrameLayout(this);
        scene.addView(new PremiumBackground(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout root = Ui.vertical(this);
        root.setBackgroundColor(Color.TRANSPARENT);
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout navOuter = Ui.horizontal(this);
        navOuter.setPadding(Ui.dp(this, 9), Ui.dp(this, 7), Ui.dp(this, 9), Ui.dp(this, 9));
        navOuter.setBackground(Ui.gradient(Color.argb(248, 23, 27, 41), Color.argb(248, 10, 12, 20), 24,
                Color.argb(45, 255, 255, 255), 1, this));

        tutorialsTab = buildMainTab("📚", "آموزش");
        gameTab = buildMainTab("🐹", "بازی همستر");
        tutorialsIcon = (TextView) tutorialsTab.getChildAt(0);
        tutorialsLabel = (TextView) tutorialsTab.getChildAt(1);
        gameIcon = (TextView) gameTab.getChildAt(0);
        gameLabel = (TextView) gameTab.getChildAt(1);

        tutorialsTab.setOnClickListener(v -> showTab("tutorials", true));
        gameTab.setOnClickListener(v -> showTab("game", true));

        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, Ui.dp(this, 62), 1f);
        p.setMargins(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
        navOuter.addView(tutorialsTab, p);
        navOuter.addView(gameTab, p);
        root.addView(navOuter, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        scene.addView(root, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(scene);
    }

    private LinearLayout buildMainTab(String icon, String label) {
        LinearLayout tab = Ui.vertical(this);
        tab.setGravity(Gravity.CENTER);
        TextView i = Ui.text(this, icon, 20, Ui.MUTED, false);
        i.setGravity(Gravity.CENTER);
        TextView l = Ui.text(this, label, 11.5f, Ui.MUTED, true);
        l.setGravity(Gravity.CENTER);
        tab.addView(i, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 30)));
        tab.addView(l, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 24)));
        return tab;
    }

    private void loadCachedConfig() {
        try {
            String raw = prefs.getString("app_config", "");
            if (raw != null && !raw.isEmpty()) appConfig = new JSONObject(raw);
        } catch (Exception ignored) { }
        if (!appConfig.has("defaultTab")) {
            try {
                appConfig.put("defaultTab", "tutorials");
                appConfig.put("gameStatus", "active");
                appConfig.put("comingSoonTitle", "بازی همستر به‌زودی");
                appConfig.put("comingSoonText", "این بخش به‌زودی فعال می‌شود.");
            } catch (Exception ignored) { }
        }
    }

    private void refreshConfig(boolean applyDefaultIfFresh) {
        api.post("app.php?action=config", new JSONObject(), null, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) {
                JSONObject cfg = json.optJSONObject("config");
                if (cfg == null) return;
                boolean changed = !cfg.toString().equals(appConfig.toString());
                appConfig = cfg;
                prefs.edit().putString("app_config", cfg.toString()).apply();
                if (applyDefaultIfFresh && !prefs.getBoolean("default_tab_applied_v9", false)) {
                    prefs.edit().putBoolean("default_tab_applied_v9", true).apply();
                    showTab(cfg.optString("defaultTab", "tutorials"), false);
                } else if (changed && "game".equals(activeTab)) {
                    showTab("game", false);
                }
            }
            @Override public void fail(String message) { }
        });
    }

    public void showTab(String tab, boolean userAction) {
        activeTab = "game".equals(tab) ? "game" : "tutorials";
        content.removeAllViews();
        boolean tutActive = "tutorials".equals(activeTab);
        styleMainTab(tutorialsTab, tutorialsIcon, tutorialsLabel, tutActive);
        styleMainTab(gameTab, gameIcon, gameLabel, !tutActive);

        if (tutActive) {
            if (game != null) game.pause();
            if (tutorials == null) tutorials = new TutorialsController(this, api, images);
            content.addView(tutorials.view(), new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            tutorials.refreshIfNeeded();
        } else {
            if (!"active".equals(appConfig.optString("gameStatus", "active"))) {
                content.addView(comingSoonView(), new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                return;
            }
            if (game == null) game = new GameController(this, api, images, prefs);
            content.addView(game.view(), new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            game.resume();
        }
    }

    private void styleMainTab(LinearLayout tab, TextView icon, TextView label, boolean active) {
        tab.setBackground(active
                ? Ui.gradient(Color.rgb(255, 224, 122), Color.rgb(255, 187, 44), 18, Color.argb(135,255,246,197), 1, this)
                : Ui.bg(Color.TRANSPARENT, 18, Color.TRANSPARENT, 0, this));
        int color = active ? Color.rgb(48, 29, 0) : Ui.MUTED;
        icon.setTextColor(color);
        label.setTextColor(color);
    }

    private View comingSoonView() {
        LinearLayout center = Ui.vertical(this);
        center.setGravity(Gravity.CENTER);
        center.setPadding(Ui.dp(this, 22), Ui.dp(this, 24), Ui.dp(this, 22), Ui.dp(this, 24));

        LinearLayout card = Ui.goldCard(this);
        card.setGravity(Gravity.CENTER);
        card.setPadding(Ui.dp(this, 24), Ui.dp(this, 28), Ui.dp(this, 24), Ui.dp(this, 28));
        TextView icon = Ui.text(this, "🐹", 72, Ui.GOLD, false); icon.setGravity(Gravity.CENTER);
        TextView badge = Ui.pill(this, "COMING SOON", Color.rgb(49, 30, 0), Ui.GOLD2); badge.setGravity(Gravity.CENTER);
        TextView title = Ui.text(this, appConfig.optString("comingSoonTitle", "بازی همستر به‌زودی"), 24, Ui.TEXT, true); title.setGravity(Gravity.CENTER);
        TextView body = Ui.text(this, appConfig.optString("comingSoonText", "این بخش به‌زودی فعال می‌شود."), 14, Ui.MUTED, false); body.setGravity(Gravity.CENTER);

        card.addView(icon, Ui.lpMatchWrap(this, 0, 12));
        LinearLayout badgeWrap = Ui.horizontal(this); badgeWrap.setGravity(Gravity.CENTER); badgeWrap.addView(badge); card.addView(badgeWrap, Ui.lpMatchWrap(this, 0, 14));
        card.addView(title, Ui.lpMatchWrap(this, 0, 12));
        card.addView(body, Ui.lpMatchWrap(this, 0, 0));
        center.addView(card, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return center;
    }

    public void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    @Override protected void onResume() {
        super.onResume();
        refreshConfig(false);
        if (game != null && "game".equals(activeTab)) game.resume();
    }

    @Override protected void onPause() {
        if (game != null) game.pause();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (game != null) game.destroy();
        super.onDestroy();
    }
}
