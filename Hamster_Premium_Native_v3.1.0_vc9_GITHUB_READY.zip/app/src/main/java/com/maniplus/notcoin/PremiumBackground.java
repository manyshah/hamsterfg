package com.maniplus.notcoin;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** Lightweight premium dark background inspired by the visual language of the reference app. */
public final class PremiumBackground extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);

    public PremiumBackground(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        dot.setColor(Color.argb(26, 255, 213, 92));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        final float w = getWidth();
        final float h = getHeight();
        if (w <= 0 || h <= 0) return;

        paint.setShader(new LinearGradient(
                0, 0, 0, h,
                new int[]{Color.rgb(5, 6, 10), Color.rgb(11, 13, 22), Color.rgb(5, 6, 10)},
                new float[]{0f, .52f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, paint);

        paint.setShader(new RadialGradient(w * .82f, h * .08f, w * .72f,
                new int[]{Color.argb(68, 255, 181, 44), Color.argb(20, 255, 181, 44), Color.TRANSPARENT},
                new float[]{0f, .43f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(w * .82f, h * .08f, w * .72f, paint);

        paint.setShader(new RadialGradient(w * .08f, h * .58f, w * .62f,
                new int[]{Color.argb(28, 72, 105, 190), Color.argb(10, 72, 105, 190), Color.TRANSPARENT},
                new float[]{0f, .48f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(w * .08f, h * .58f, w * .62f, paint);

        paint.setShader(null);
        final int cols = 8;
        final int rows = Math.max(10, (int)(h / Math.max(1f, w / cols)));
        for (int y = 1; y < rows; y++) {
            for (int x = 1; x < cols; x++) {
                if (((x * 13 + y * 7) % 11) == 0) {
                    float px = (x + .35f) * w / cols;
                    float py = (y + .2f) * h / rows;
                    canvas.drawCircle(px, py, 1.25f, dot);
                }
            }
        }
    }
}
