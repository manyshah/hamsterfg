package com.maniplus.notcoin;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

public final class TutorialsController {
    private final MainActivity activity;
    private final ApiClient api;
    private final ImageLoader images;
    private final LinearLayout root;
    private final LinearLayout categoryRow;
    private final LinearLayout list;
    private final EditText search;
    private final ProgressBar loading;
    private final TextView categoryCount;
    private JSONArray categories = new JSONArray();
    private JSONArray tutorials = new JSONArray();
    private String selectedCategory = "";
    private long lastLoadedAt = 0;
    private Runnable delayedSearch;
    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());

    public TutorialsController(MainActivity activity, ApiClient api, ImageLoader images) {
        this.activity = activity;
        this.api = api;
        this.images = images;
        root = Ui.vertical(activity);
        root.setBackgroundColor(Color.TRANSPARENT);

        LinearLayout headerWrap = Ui.vertical(activity);
        headerWrap.setPadding(Ui.dp(activity, 14), Ui.dp(activity, 12), Ui.dp(activity, 14), Ui.dp(activity, 7));

        LinearLayout hero = Ui.goldCard(activity);
        LinearLayout heroRow = Ui.horizontal(activity);
        LinearLayout heroText = Ui.vertical(activity);
        heroText.addView(Ui.sectionEyebrow(activity, "LEARN • فارسی"));
        heroText.addView(Ui.text(activity, "آموزش فارسی", 24, Ui.TEXT, true), Ui.lpMatchWrap(activity, 3, 4));
        heroText.addView(Ui.text(activity, "از موبایل و هوش مصنوعی تا کسب‌وکار و مهارت‌های روزمره", 10.5f, Ui.MUTED, false));
        heroRow.addView(heroText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView heroIcon = Ui.text(activity, "📚", 34, Ui.GOLD2, false); heroIcon.setGravity(Gravity.CENTER);
        heroIcon.setBackground(Ui.bg(Color.argb(28,255,197,51), 18, Color.argb(75,255,197,51), 1, activity));
        heroRow.addView(heroIcon, new LinearLayout.LayoutParams(Ui.dp(activity, 64), Ui.dp(activity, 64)));
        hero.addView(heroRow);
        LinearLayout meta = Ui.horizontal(activity);
        categoryCount = Ui.pill(activity, "در حال دریافت دسته‌ها...", Ui.GOLD2, Color.argb(20,255,197,51));
        meta.addView(categoryCount);
        Ui.gap(meta, activity, 7);
        meta.addView(Ui.pill(activity, "محتوای آنلاین", Ui.GREEN, Color.argb(20,74,211,155)));
        hero.addView(meta, Ui.lpMatchWrap(activity, 13, 0));
        headerWrap.addView(hero);

        LinearLayout searchBox = Ui.horizontal(activity);
        searchBox.setPadding(Ui.dp(activity, 12), 0, Ui.dp(activity, 12), 0);
        searchBox.setBackground(Ui.gradient(Color.rgb(30, 34, 51), Color.rgb(17, 20, 31), 18, Color.argb(38,255,255,255), 1, activity));
        TextView searchIcon = Ui.text(activity, "⌕", 24, Ui.GOLD2, true); searchIcon.setGravity(Gravity.CENTER);
        searchBox.addView(searchIcon, new LinearLayout.LayoutParams(Ui.dp(activity, 42), Ui.dp(activity, 52)));
        search = new EditText(activity);
        search.setHint("دنبال چه آموزشی هستی؟");
        search.setHintTextColor(Ui.MUTED2);
        search.setTextColor(Ui.TEXT);
        search.setTextSize(13.5f);
        search.setSingleLine(true);
        search.setPadding(Ui.dp(activity, 6), 0, Ui.dp(activity, 6), 0);
        search.setBackgroundColor(Color.TRANSPARENT);
        searchBox.addView(search, new LinearLayout.LayoutParams(0, Ui.dp(activity, 52), 1f));
        headerWrap.addView(searchBox, Ui.lpMatchWrap(activity, 11, 0));
        root.addView(headerWrap, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout labelRow = Ui.horizontal(activity);
        labelRow.setPadding(Ui.dp(activity, 16), Ui.dp(activity, 4), Ui.dp(activity, 16), Ui.dp(activity, 8));
        labelRow.addView(Ui.text(activity, "دسته‌بندی‌ها", 14.5f, Ui.TEXT, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        labelRow.addView(Ui.text(activity, "اسکرول کن", 9.5f, Ui.MUTED2, false));
        root.addView(labelRow);

        HorizontalScrollView hsv = new HorizontalScrollView(activity);
        hsv.setHorizontalScrollBarEnabled(false);
        categoryRow = Ui.horizontal(activity);
        categoryRow.setPadding(Ui.dp(activity, 12), 0, Ui.dp(activity, 12), Ui.dp(activity, 10));
        hsv.addView(categoryRow, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        loading = Ui.progress(activity, .72);
        loading.setIndeterminate(true);
        root.addView(loading, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 3)));

        ScrollView scroll = new ScrollView(activity);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        list = Ui.vertical(activity);
        list.setPadding(Ui.dp(activity, 14), Ui.dp(activity, 11), Ui.dp(activity, 14), Ui.dp(activity, 28));
        scroll.addView(list, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (delayedSearch != null) handler.removeCallbacks(delayedSearch);
                delayedSearch = TutorialsController.this::loadTutorials;
                handler.postDelayed(delayedSearch, 350);
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        loadCategories();
        loadTutorials();
    }

    public View view() {
        if (root.getParent() instanceof ViewGroup) ((ViewGroup)root.getParent()).removeView(root);
        return root;
    }

    public void refreshIfNeeded() {
        if (SystemClock.elapsedRealtime() - lastLoadedAt > 60000) {
            loadCategories();
            loadTutorials();
        }
    }

    private void loadCategories() {
        api.post("app.php?action=categories", new JSONObject(), null, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) {
                categories = json.optJSONArray("categories");
                if (categories == null) categories = new JSONArray();
                categoryCount.setText(categories.length() + " دسته آموزشی");
                renderCategories();
            }
            @Override public void fail(String message) { activity.toast(message); }
        });
    }

    private void renderCategories() {
        categoryRow.removeAllViews();
        addCategoryChip("", "همه", "✨");
        for (int i = 0; i < categories.length(); i++) {
            JSONObject c = categories.optJSONObject(i);
            if (c == null || !c.optBoolean("active", true)) continue;
            addCategoryChip(c.optString("id"), c.optString("name"), c.optString("icon", "📘"));
        }
    }

    private void addCategoryChip(String id, String name, String icon) {
        boolean active = id.equals(selectedCategory);
        LinearLayout chip = Ui.horizontal(activity);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(Ui.dp(activity, 12), 0, Ui.dp(activity, 12), 0);
        chip.setBackground(active
                ? Ui.gradient(Ui.GOLD2, Ui.GOLD, 16, Color.argb(120,255,239,173), 1, activity)
                : Ui.gradient(Color.rgb(35, 40, 59), Color.rgb(21, 24, 37), 16, Color.argb(32,255,255,255), 1, activity));
        TextView i = Ui.text(activity, icon, 13, active ? Color.rgb(50,30,0) : Ui.GOLD2, false); i.setGravity(Gravity.CENTER);
        TextView n = Ui.text(activity, name, 10.5f, active ? Color.rgb(50,30,0) : Ui.TEXT, true); n.setGravity(Gravity.CENTER);
        chip.addView(i); Ui.gap(chip, activity, 6); chip.addView(n);
        chip.setOnClickListener(v -> { selectedCategory = id; renderCategories(); loadTutorials(); });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(activity, 42));
        p.setMargins(Ui.dp(activity, 4), 0, Ui.dp(activity, 4), 0);
        categoryRow.addView(chip, p);
    }

    private void loadTutorials() {
        loading.setVisibility(View.VISIBLE);
        JSONObject body = new JSONObject();
        try {
            body.put("categoryId", selectedCategory);
            body.put("q", search.getText().toString().trim());
            body.put("limit", 100);
        } catch (Exception ignored) { }
        api.post("app.php?action=tutorials", body, null, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) {
                tutorials = json.optJSONArray("tutorials");
                if (tutorials == null) tutorials = new JSONArray();
                lastLoadedAt = SystemClock.elapsedRealtime();
                loading.setVisibility(View.GONE);
                renderTutorials();
            }
            @Override public void fail(String message) {
                loading.setVisibility(View.GONE);
                if (tutorials.length() == 0) empty(message);
            }
        });
    }

    private void renderTutorials() {
        list.removeAllViews();
        LinearLayout head = Ui.horizontal(activity);
        head.addView(Ui.text(activity, selectedCategory.isEmpty() ? "جدیدترین آموزش‌ها" : "آموزش‌های این دسته", 16.5f, Ui.TEXT, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(Ui.pill(activity, tutorials.length() + " مورد", Ui.GOLD2, Color.argb(20,255,197,51)));
        list.addView(head, Ui.lpMatchWrap(activity, 0, 11));
        if (tutorials.length() == 0) { empty("آموزشی در این بخش ثبت نشده است."); return; }
        for (int i = 0; i < tutorials.length(); i++) {
            JSONObject t = tutorials.optJSONObject(i);
            if (t != null) list.addView(tutorialCard(t), Ui.lpMatchWrap(activity, 0, 10));
        }
    }

    private void empty(String message) {
        list.removeAllViews();
        LinearLayout c = Ui.card(activity); c.setGravity(Gravity.CENTER);
        TextView icon = Ui.text(activity, "📚", 38, Ui.GOLD2, false); icon.setGravity(Gravity.CENTER);
        TextView t = Ui.text(activity, message, 12, Ui.MUTED, false); t.setGravity(Gravity.CENTER);
        c.addView(icon, Ui.lpMatchWrap(activity, 12, 9)); c.addView(t, Ui.lpMatchWrap(activity, 0, 12));
        list.addView(c);
    }

    private View tutorialCard(JSONObject t) {
        LinearLayout card = t.optBoolean("featured", false) ? Ui.goldCard(activity) : Ui.card(activity);
        card.setOnClickListener(v -> openDetail(t.optString("id")));
        LinearLayout top = Ui.horizontal(activity);
        String cover = ApiClient.absolute(t.optString("cover"));
        if (!cover.isEmpty()) {
            ImageView image = new ImageView(activity);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackground(Ui.bg(Ui.PANEL2, 16, Color.argb(36,255,255,255), 1, activity));
            top.addView(image, new LinearLayout.LayoutParams(Ui.dp(activity, 92), Ui.dp(activity, 92)));
            images.load(image, cover);
            Ui.gap(top, activity, 12);
        } else {
            TextView placeholder = Ui.text(activity, "📖", 34, Ui.GOLD2, false); placeholder.setGravity(Gravity.CENTER);
            placeholder.setBackground(Ui.gradient(Color.rgb(54, 42, 24), Color.rgb(28, 29, 37), 16, Color.argb(70,255,197,51), 1, activity));
            top.addView(placeholder, new LinearLayout.LayoutParams(Ui.dp(activity, 84), Ui.dp(activity, 84)));
            Ui.gap(top, activity, 12);
        }

        LinearLayout info = Ui.vertical(activity);
        if (t.optBoolean("featured", false)) info.addView(Ui.sectionEyebrow(activity, "⭐ پیشنهاد ویژه"));
        TextView title = Ui.text(activity, t.optString("title"), 16, Ui.TEXT, true);
        TextView summary = Ui.text(activity, t.optString("summary"), 10.5f, Ui.MUTED, false);
        summary.setMaxLines(2);
        info.addView(title, Ui.lpMatchWrap(activity, t.optBoolean("featured", false) ? 2 : 0, 4));
        info.addView(summary, Ui.lpMatchWrap(activity, 0, 8));
        LinearLayout meta = Ui.horizontal(activity);
        meta.addView(Ui.pill(activity, t.optString("level", "مبتدی"), Ui.GOLD2, Color.argb(18,255,197,51)));
        Ui.gap(meta, activity, 5);
        meta.addView(Ui.pill(activity, t.optInt("duration", 0) + " دقیقه", Ui.BLUE, Color.argb(18,107,167,255)));
        info.addView(meta);
        top.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout foot = Ui.horizontal(activity);
        foot.addView(Ui.text(activity, "برای مشاهده آموزش لمس کن", 9.5f, Ui.MUTED2, false), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        foot.addView(Ui.text(activity, "‹", 24, Ui.GOLD2, true));
        card.addView(foot, Ui.lpMatchWrap(activity, 11, 0));
        return card;
    }

    private void openDetail(String id) {
        JSONObject b = new JSONObject(); try { b.put("id", id); } catch (Exception ignored) { }
        activity.toast("در حال دریافت آموزش...");
        api.post("app.php?action=tutorial", b, null, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) { JSONObject t = json.optJSONObject("tutorial"); if (t != null) showDetailDialog(t); }
            @Override public void fail(String message) { activity.toast(message); }
        });
    }

    private void showDetailDialog(JSONObject t) {
        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout shell = Ui.vertical(activity);
        shell.setPadding(Ui.dp(activity, 14), Ui.dp(activity, 14), Ui.dp(activity, 14), Ui.dp(activity, 16));
        shell.setBackground(Ui.gradient(Color.rgb(29, 33, 49), Color.rgb(12, 14, 22), 26, Color.argb(60,255,255,255), 1, activity));

        LinearLayout topBar = Ui.horizontal(activity);
        LinearLayout titles = Ui.vertical(activity);
        titles.addView(Ui.sectionEyebrow(activity, "آموزش فارسی"));
        titles.addView(Ui.text(activity, t.optString("title"), 19, Ui.TEXT, true), Ui.lpMatchWrap(activity, 2, 0));
        topBar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = Ui.text(activity, "×", 28, Ui.MUTED, false); close.setGravity(Gravity.CENTER); close.setOnClickListener(v -> dialog.dismiss());
        topBar.addView(close, new LinearLayout.LayoutParams(Ui.dp(activity, 44), Ui.dp(activity, 44)));
        shell.addView(topBar, Ui.lpMatchWrap(activity, 0, 10));

        ScrollView sv = new ScrollView(activity);
        LinearLayout wrap = Ui.vertical(activity);
        String cover = ApiClient.absolute(t.optString("cover"));
        if (!cover.isEmpty()) {
            ImageView image = new ImageView(activity); image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackground(Ui.bg(Ui.PANEL2, 18, Color.argb(40,255,255,255), 1, activity));
            wrap.addView(image, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 210))); images.load(image, cover);
        }
        LinearLayout meta = Ui.horizontal(activity);
        meta.addView(Ui.pill(activity, t.optString("level", "مبتدی"), Ui.GOLD2, Color.argb(20,255,197,51)));
        Ui.gap(meta, activity, 6);
        meta.addView(Ui.pill(activity, t.optInt("duration", 0) + " دقیقه", Ui.BLUE, Color.argb(20,107,167,255)));
        wrap.addView(meta, Ui.lpMatchWrap(activity, 13, 10));
        TextView summary = Ui.text(activity, t.optString("summary"), 12, Ui.MUTED, false); summary.setLineSpacing(Ui.dp(activity, 1), 1.3f);
        wrap.addView(summary, Ui.lpMatchWrap(activity, 0, 12));
        TextView bodyText = Ui.text(activity, t.optString("body"), 14.5f, Ui.TEXT, false);
        bodyText.setTextIsSelectable(true); bodyText.setLineSpacing(Ui.dp(activity, 3), 1.4f);
        wrap.addView(bodyText, Ui.lpMatchWrap(activity, 0, 16));
        String video = t.optString("videoUrl").trim();
        if (!video.isEmpty()) {
            Button vb = Ui.button(activity, "▶  مشاهده ویدیو", true);
            vb.setOnClickListener(v -> { try { activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(video))); } catch (Exception e) { activity.toast("لینک ویدیو باز نشد"); } });
            wrap.addView(vb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 50)));
        }
        sv.addView(wrap, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        shell.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        dialog.setContentView(shell);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        dialog.setOnShowListener(x -> {
            Window win = dialog.getWindow();
            if (win != null) {
                win.setLayout((int)(activity.getResources().getDisplayMetrics().widthPixels * .94f), (int)(activity.getResources().getDisplayMetrics().heightPixels * .90f));
                win.setGravity(Gravity.CENTER);
            }
        });
        dialog.show();
    }
}
