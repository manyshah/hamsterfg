# آموزش همستر — Premium Native v3.1.0 (9)

نسخه بازطراحی‌شده رابط کاربری با الهام از زبان بصری بسته مرجع ارسالی کاربر، بدون تغییر در هویت برنامه یا Backend بازی.

## مشخصات انتشار

- applicationId: `com.maniplus.notcoin`
- versionName: `3.1.0`
- versionCode: `9`
- targetSdk: `36`
- minSdk: `21`
- Signing: همان keystore اصلی آموزش همستر
- Backend: `https://persian-melody.ir/api/`

## رابط جدید

- تم تیره حرفه‌ای با Accent طلایی
- پس‌زمینه گرادیانی و Glow سبک
- ناوبری اصلی پایین فقط: `آموزش` و `بازی همستر`
- بخش آموزش با Hero، جستجوی حرفه‌ای، Chip دسته‌بندی و کارت‌های Premium
- بخش بازی با Home شبیه بازی واقعی، موجودی بزرگ، لیگ، کاپ‌های تصویری، Tap Area، انرژی و Quick Boost
- صفحات بوست، مأموریت، لیگ، دوستان و پروفایل با همان زبان بصری
- Asset کاپ‌های لیگ از بسته مرجع ارسالی کاربر استفاده شده‌اند.
- رابط کاربری WebView نیست.

## منطق حفظ‌شده

- Backend فعلی بازی
- حساب مهمان و حساب ثبت‌شده
- مهاجرت Session قدیمی از Cookie Store همان Package
- Tap و Energy
- Turbo و Instant Energy
- Boost Upgrades
- Missions
- League / Leaderboard
- Referral
- Profile / Register / Login / Password Reset
- تنظیم صفحه شروع و Active/Coming Soon از Admin
- آموزش‌ها و دسته‌بندی‌ها از Backend

## Signing

- Store password: `1234`
- Alias: `hellosc`
- Key password: `1234`

## Build

ساختار Gradle عمداً با نسخه قبلی حفظ شده است؛ بنابراین همان Workflow تست‌شده `build-any-zip-hamster.yml` می‌تواند این ZIP را بدون Extract دستی Build کند.
