package com.maniplus.notcoin;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class PullRefreshLayout extends FrameLayout {
    public interface RefreshListener { void onRefresh(); }
    public interface BottomListener { void onBottom(); }

    private final ScrollView scroll;
    private final TextView indicator;
    private RefreshListener refreshListener;
    private BottomListener bottomListener;
    private float downX;
    private float pullStartY;
    private boolean pulling;
    private boolean refreshing;
    private boolean bottomArmed = true;
    private ObjectAnimator spin;
    private final int threshold;

    public PullRefreshLayout(Context context) {
        super(context);
        setClipChildren(false);
        setClipToPadding(false);
        threshold = Ui.dp(context, 72);

        scroll = new ScrollView(context);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_ALWAYS);
        addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        indicator = Ui.text(context, "↻", 24, Ui.PRIMARY, true);
        indicator.setGravity(Gravity.CENTER);
        indicator.setBackground(Ui.bg(Color.WHITE, 99, Ui.LINE, 1, context));
        indicator.setAlpha(0f);
        indicator.setScaleX(.72f);
        indicator.setScaleY(.72f);
        if (Build.VERSION.SDK_INT >= 21) indicator.setElevation(Ui.dp(context, 5));
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(Ui.dp(context, 44), Ui.dp(context, 44));
        ip.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        ip.topMargin = Ui.dp(context, 8);
        addView(indicator, ip);

        if (Build.VERSION.SDK_INT >= 23) {
            scroll.setOnScrollChangeListener((v, sx, sy, osx, osy) -> checkBottom());
        } else {
            scroll.getViewTreeObserver().addOnScrollChangedListener(this::checkBottom);
        }
    }

    @Override public boolean dispatchTouchEvent(MotionEvent e) {
        observePullGesture(e);
        return super.dispatchTouchEvent(e);
    }

    private void observePullGesture(MotionEvent e) {
        if (refreshing) return;
        int action = e.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            downX = e.getX();
            pulling = scroll.getScrollY() <= 0;
            pullStartY = e.getY();
            return;
        }

        if (action == MotionEvent.ACTION_MOVE) {
            if (scroll.getScrollY() <= 0) {
                if (!pulling) {
                    pulling = true;
                    pullStartY = e.getY();
                    downX = e.getX();
                }
                float dy = Math.max(0f, e.getY() - pullStartY);
                float dx = Math.abs(e.getX() - downX);
                if (dy > Ui.dp(getContext(), 6) && dy > dx * 1.15f) {
                    float progress = Math.min(1f, dy / threshold);
                    indicator.setAlpha(Math.min(1f, .2f + progress));
                    indicator.setScaleX(.72f + .28f * progress);
                    indicator.setScaleY(.72f + .28f * progress);
                    indicator.setRotation(300f * progress);
                }
            } else if (pulling) {
                pulling = false;
                hideIndicator();
            }
            return;
        }

        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            float dy = Math.max(0f, e.getY() - pullStartY);
            float dx = Math.abs(e.getX() - downX);
            boolean verticalPull = dy > dx * 1.15f;
            if (pulling && scroll.getScrollY() <= 0 && verticalPull && dy >= threshold && refreshListener != null) {
                setRefreshing(true);
                refreshListener.onRefresh();
            } else if (!refreshing) {
                hideIndicator();
            }
            pulling = false;
        }
    }

    public void setContent(View content) {
        scroll.removeAllViews();
        scroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    public ScrollView scrollView() { return scroll; }
    public void setOnRefreshListener(RefreshListener listener) { this.refreshListener = listener; }
    public void setOnBottomListener(BottomListener listener) { this.bottomListener = listener; }

    public void setRefreshing(boolean value) {
        refreshing = value;
        if (value) {
            indicator.setAlpha(1f);
            indicator.setScaleX(1f);
            indicator.setScaleY(1f);
            if (spin != null) spin.cancel();
            spin = ObjectAnimator.ofFloat(indicator, View.ROTATION, indicator.getRotation(), indicator.getRotation() + 360f);
            spin.setDuration(750);
            spin.setRepeatCount(ObjectAnimator.INFINITE);
            spin.setInterpolator(new LinearInterpolator());
            spin.start();
        } else {
            if (spin != null) { spin.cancel(); spin = null; }
            hideIndicator();
        }
    }

    public boolean isRefreshing() { return refreshing; }

    private void hideIndicator() {
        indicator.animate().alpha(0f).scaleX(.72f).scaleY(.72f).setDuration(150).start();
    }

    private void checkBottom() {
        if (bottomListener == null || scroll.getChildCount() == 0) return;
        View child = scroll.getChildAt(0);
        int remain = child.getHeight() - (scroll.getScrollY() + scroll.getHeight());
        if (remain > Ui.dp(getContext(), 320)) bottomArmed = true;
        if (bottomArmed && remain <= Ui.dp(getContext(), 180)) {
            bottomArmed = false;
            bottomListener.onBottom();
        }
    }
}
