package com.maniplus.notcoin;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public final class Ui {
    public static final int BG = Color.rgb(5, 6, 10);
    public static final int PANEL = Color.rgb(21, 24, 36);
    public static final int PANEL2 = Color.rgb(31, 36, 55);
    public static final int PANEL3 = Color.rgb(40, 46, 69);
    public static final int TEXT = Color.rgb(248, 249, 252);
    public static final int MUTED = Color.rgb(155, 163, 184);
    public static final int MUTED2 = Color.rgb(112, 121, 145);
    public static final int GOLD = Color.rgb(255, 197, 51);
    public static final int GOLD2 = Color.rgb(255, 226, 122);
    public static final int GOLD_DARK = Color.rgb(178, 118, 18);
    public static final int GREEN = Color.rgb(74, 211, 155);
    public static final int RED = Color.rgb(255, 105, 126);
    public static final int BLUE = Color.rgb(107, 167, 255);

    private Ui() {}

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static LinearLayout vertical(Context c) {
        LinearLayout v = new LinearLayout(c);
        v.setOrientation(LinearLayout.VERTICAL);
        if (Build.VERSION.SDK_INT >= 17) v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return v;
    }

    public static LinearLayout horizontal(Context c) {
        LinearLayout v = new LinearLayout(c);
        v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL);
        if (Build.VERSION.SDK_INT >= 17) v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return v;
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s == null ? "" : s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setLineSpacing(0, 1.23f);
        if (Build.VERSION.SDK_INT >= 21) t.setLetterSpacing(sp >= 20 ? -0.01f : 0f);
        return t;
    }

    public static TextView title(Context c, String s) {
        return text(c, s, 22, TEXT, true);
    }

    public static GradientDrawable bg(int color, float radius, int strokeColor, int strokeDp, Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radius));
        if (strokeDp > 0) d.setStroke(dp(c, strokeDp), strokeColor);
        return d;
    }

    public static GradientDrawable gradient(int c1, int c2, float radius, int strokeColor, int strokeDp, Context c) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        d.setCornerRadius(dp(c, radius));
        if (strokeDp > 0) d.setStroke(dp(c, strokeDp), strokeColor);
        return d;
    }

    public static GradientDrawable ovalGradient(int c1, int c2, int strokeColor, int strokeDp, Context c) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        d.setShape(GradientDrawable.OVAL);
        if (strokeDp > 0) d.setStroke(dp(c, strokeDp), strokeColor);
        return d;
    }

    public static Button button(Context c, String s, boolean primary) {
        Button b = new Button(c);
        b.setText(s);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(c, 46));
        b.setPadding(dp(c, 13), 0, dp(c, 13), 0);
        b.setTypeface(Typeface.create("sans", Typeface.BOLD));
        if (Build.VERSION.SDK_INT >= 21) {
            b.setStateListAnimator(null);
            b.setElevation(0);
        }
        if (primary) {
            b.setTextColor(Color.rgb(48, 29, 0));
            b.setBackground(gradient(GOLD2, GOLD, 15, Color.argb(160, 255, 239, 173), 1, c));
        } else {
            b.setTextColor(TEXT);
            b.setBackground(gradient(Color.argb(238, 41, 47, 69), Color.argb(238, 24, 28, 43), 15,
                    Color.argb(38, 255, 255, 255), 1, c));
        }
        return b;
    }

    public static LinearLayout card(Context c) {
        LinearLayout v = vertical(c);
        v.setPadding(dp(c, 15), dp(c, 15), dp(c, 15), dp(c, 15));
        v.setBackground(gradient(Color.rgb(28, 32, 48), Color.rgb(17, 20, 31), 22,
                Color.argb(42, 255, 255, 255), 1, c));
        if (Build.VERSION.SDK_INT >= 21) v.setElevation(dp(c, 2));
        return v;
    }

    public static LinearLayout goldCard(Context c) {
        LinearLayout v = vertical(c);
        v.setPadding(dp(c, 16), dp(c, 15), dp(c, 16), dp(c, 15));
        v.setBackground(gradient(Color.rgb(65, 48, 20), Color.rgb(25, 23, 25), 22,
                Color.argb(135, 255, 197, 51), 1, c));
        return v;
    }

    public static LinearLayout softCard(Context c) {
        LinearLayout v = vertical(c);
        v.setPadding(dp(c, 13), dp(c, 13), dp(c, 13), dp(c, 13));
        v.setBackground(bg(Color.argb(222, 25, 29, 44), 18, Color.argb(32, 255, 255, 255), 1, c));
        return v;
    }

    public static TextView pill(Context c, String text, int fg, int bgColor) {
        TextView t = Ui.text(c, text, 10.5f, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 11), dp(c, 6), dp(c, 11), dp(c, 6));
        t.setBackground(bg(bgColor, 99, Color.argb(25, 255, 255, 255), 1, c));
        return t;
    }

    public static TextView sectionEyebrow(Context c, String text) {
        TextView t = text(c, text, 10.5f, GOLD2, true);
        t.setGravity(Gravity.RIGHT);
        return t;
    }

    public static ProgressBar progress(Context c, double ratio) {
        ProgressBar pb = new ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(1000);
        pb.setProgress((int)Math.round(Math.max(0d, Math.min(1d, ratio)) * 1000d));
        GradientDrawable track = bg(Color.rgb(12, 15, 24), 99, Color.argb(25,255,255,255), 1, c);
        GradientDrawable fill = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Color.rgb(255, 169, 35), GOLD2});
        fill.setCornerRadius(dp(c, 99));
        ClipDrawable clip = new ClipDrawable(fill, Gravity.LEFT, ClipDrawable.HORIZONTAL);
        LayerDrawable layer = new LayerDrawable(new android.graphics.drawable.Drawable[]{track, clip});
        layer.setId(0, android.R.id.background);
        layer.setId(1, android.R.id.progress);
        pb.setProgressDrawable(layer);
        if (Build.VERSION.SDK_INT >= 21) pb.setProgressTintList(ColorStateList.valueOf(GOLD));
        return pb;
    }

    public static LinearLayout.LayoutParams lpMatchWrap(Context c, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(c, top), 0, dp(c, bottom));
        return p;
    }

    public static LinearLayout.LayoutParams lpWeight(float w) {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w);
    }

    public static void gap(LinearLayout parent, Context c, int dp) {
        View g = new View(c);
        parent.addView(g, new LinearLayout.LayoutParams(dp(c, dp), dp(c, dp)));
    }

    public static String faNumber(double n) {
        if (Math.abs(n - Math.rint(n)) < 0.00001) return String.format(java.util.Locale.US, "%,.0f", n);
        return String.format(java.util.Locale.US, "%,.1f", n);
    }
}
