package com.maniplus.notcoin;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ApiClient {
    public static final String SITE = "https://persian-melody.ir/";
    public static final String BASE = SITE + "api/";
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final Handler main = new Handler(Looper.getMainLooper());

    public interface Callback {
        void ok(JSONObject json);
        void fail(String message);
    }

    public void post(String relative, JSONObject body, String token, Callback callback) {
        pool.execute(() -> {
            HttpURLConnection c = null;
            try {
                URL u = new URL(BASE + relative);
                c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(12000);
                c.setReadTimeout(18000);
                c.setDoOutput(true);
                c.setRequestProperty("Accept", "application/json");
                c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                c.setRequestProperty("User-Agent", "HamsterEducation/3.1.0 Android");
                if (token != null && !token.trim().isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token.trim());
                byte[] data = (body == null ? "{}" : body.toString()).getBytes(StandardCharsets.UTF_8);
                c.setFixedLengthStreamingMode(data.length);
                try (OutputStream os = c.getOutputStream()) { os.write(data); }
                int status = c.getResponseCode();
                InputStream in = status >= 200 && status < 400 ? c.getInputStream() : c.getErrorStream();
                String raw = read(in);
                JSONObject json = raw.isEmpty() ? new JSONObject() : new JSONObject(raw);
                if (status >= 200 && status < 300 && json.optBoolean("ok", true)) {
                    main.post(() -> callback.ok(json));
                } else {
                    String msg = json.optString("error", json.optString("message", "خطای ارتباط با سرور"));
                    main.post(() -> callback.fail(msg));
                }
            } catch (Exception e) {
                String msg = "اتصال به سرور برقرار نشد";
                main.post(() -> callback.fail(msg));
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    private String read(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    public static String absolute(String path) {
        if (path == null || path.trim().isEmpty()) return "";
        if (path.startsWith("http://") || path.startsWith("https://")) return path;
        String p = path.startsWith("/") ? path.substring(1) : path;
        return SITE + p;
    }
}
