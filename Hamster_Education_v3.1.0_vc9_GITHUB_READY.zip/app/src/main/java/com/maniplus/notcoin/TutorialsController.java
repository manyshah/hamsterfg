package com.maniplus.notcoin;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public final class TutorialsController {
    private final MainActivity activity;
    private final ApiClient api;
    private final ImageLoader images;
    private final SharedPreferences prefs;
    private final LinearLayout root;
    private final LinearLayout categoryRow;
    private final LinearLayout featuredRow;
    private final LinearLayout list;
    private final EditText search;
    private final ProgressBar loading;
    private final TextView categoryCount;
    private final TextView tutorialCount;
    private final TextView sectionTitle;
    private final TextView networkBadge;
    private JSONArray categories = new JSONArray();
    private JSONArray tutorials = new JSONArray();
    private JSONObject seed = new JSONObject();
    private final Map<String, JSONObject> seedById = new HashMap<>();
    private String selectedCategory = "";
    private long lastLoadedAt = 0;
    private Runnable delayedSearch;
    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());

    public TutorialsController(MainActivity activity, ApiClient api, ImageLoader images) {
        this.activity = activity;
        this.api = api;
        this.images = images;
        this.prefs = activity.getSharedPreferences("hamster_education", Context.MODE_PRIVATE);

        seed = SeedData.load(activity);
        indexSeed();
        loadInitialData();

        root = Ui.vertical(activity);
        root.setBackgroundColor(Color.TRANSPARENT);

        LinearLayout headerWrap = Ui.vertical(activity);
        headerWrap.setPadding(Ui.dp(activity, 14), Ui.dp(activity, 10), Ui.dp(activity, 14), Ui.dp(activity, 8));

        LinearLayout hero = Ui.goldCard(activity);
        hero.setPadding(Ui.dp(activity, 17), Ui.dp(activity, 17), Ui.dp(activity, 17), Ui.dp(activity, 17));

        LinearLayout heroRow = Ui.horizontal(activity);
        LinearLayout heroText = Ui.vertical(activity);
        TextView brand = Ui.text(activity, "HAMSTER ACADEMY", 10.5f, Ui.GOLD2, true);
        heroText.addView(brand);
        TextView title = Ui.text(activity, "آموزش همستر", 27, Ui.TEXT, true);
        heroText.addView(title, Ui.lpMatchWrap(activity, 3, 4));
        TextView subtitle = Ui.text(activity, "راهنمای فارسی HamsterVerse، HMSTR، TON و امنیت", 11.5f, Ui.MUTED, false);
        subtitle.setLineSpacing(Ui.dp(activity, 1), 1.25f);
        heroText.addView(subtitle);
        heroRow.addView(heroText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView heroIcon = Ui.text(activity, "🐹", 40, Ui.GOLD2, false);
        heroIcon.setGravity(Gravity.CENTER);
        heroIcon.setBackground(Ui.gradient(Color.rgb(69, 49, 18), Color.rgb(31, 27, 27), 22,
                Color.argb(105,255,197,51), 1, activity));
        heroRow.addView(heroIcon, new LinearLayout.LayoutParams(Ui.dp(activity, 72), Ui.dp(activity, 72)));
        hero.addView(heroRow);

        LinearLayout meta = Ui.horizontal(activity);
        tutorialCount = Ui.pill(activity, tutorials.length() + " آموزش", Color.rgb(49,30,0), Ui.GOLD2);
        categoryCount = Ui.pill(activity, categories.length() + " دسته", Ui.GOLD2, Color.argb(22,255,197,51));
        networkBadge = Ui.pill(activity, "آفلاین آماده", Ui.GREEN, Color.argb(20,74,211,155));
        meta.addView(tutorialCount); Ui.gap(meta, activity, 6);
        meta.addView(categoryCount); Ui.gap(meta, activity, 6);
        meta.addView(networkBadge);
        hero.addView(meta, Ui.lpMatchWrap(activity, 14, 0));
        headerWrap.addView(hero);

        LinearLayout searchBox = Ui.horizontal(activity);
        searchBox.setPadding(Ui.dp(activity, 12), 0, Ui.dp(activity, 12), 0);
        searchBox.setBackground(Ui.gradient(Color.rgb(31, 36, 54), Color.rgb(17, 20, 31), 18,
                Color.argb(44,255,255,255), 1, activity));
        TextView searchIcon = Ui.text(activity, "⌕", 26, Ui.GOLD2, true);
        searchIcon.setGravity(Gravity.CENTER);
        searchBox.addView(searchIcon, new LinearLayout.LayoutParams(Ui.dp(activity, 42), Ui.dp(activity, 54)));
        search = new EditText(activity);
        search.setHint("مثلاً: دیلی کمبو، TON، کیف پول...");
        search.setHintTextColor(Ui.MUTED2);
        search.setTextColor(Ui.TEXT);
        search.setTextSize(13.5f);
        search.setSingleLine(true);
        search.setPadding(Ui.dp(activity, 6), 0, Ui.dp(activity, 6), 0);
        search.setBackgroundColor(Color.TRANSPARENT);
        searchBox.addView(search, new LinearLayout.LayoutParams(0, Ui.dp(activity, 54), 1f));
        headerWrap.addView(searchBox, Ui.lpMatchWrap(activity, 11, 0));
        root.addView(headerWrap);

        ScrollView scroll = new ScrollView(activity);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        LinearLayout page = Ui.vertical(activity);
        page.setPadding(0, 0, 0, Ui.dp(activity, 28));

        page.addView(labelRow("پیشنهاد ویژه", "راهنماهای مهم برای شروع"));

        HorizontalScrollView featuredScroll = new HorizontalScrollView(activity);
        featuredScroll.setHorizontalScrollBarEnabled(false);
        featuredRow = Ui.horizontal(activity);
        featuredRow.setPadding(Ui.dp(activity, 10), 0, Ui.dp(activity, 10), Ui.dp(activity, 7));
        featuredScroll.addView(featuredRow, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        page.addView(featuredScroll);

        page.addView(labelRow("دسته‌بندی‌ها", "برای فیلتر لمس کن"));
        HorizontalScrollView hsv = new HorizontalScrollView(activity);
        hsv.setHorizontalScrollBarEnabled(false);
        categoryRow = Ui.horizontal(activity);
        categoryRow.setPadding(Ui.dp(activity, 10), 0, Ui.dp(activity, 10), Ui.dp(activity, 9));
        hsv.addView(categoryRow, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        page.addView(hsv);

        loading = Ui.progress(activity, .72);
        loading.setIndeterminate(true);
        loading.setVisibility(View.GONE);
        page.addView(loading, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 3)));

        LinearLayout titleRow = Ui.horizontal(activity);
        titleRow.setPadding(Ui.dp(activity, 16), Ui.dp(activity, 14), Ui.dp(activity, 16), Ui.dp(activity, 7));
        sectionTitle = Ui.text(activity, "همه آموزش‌ها", 16, Ui.TEXT, true);
        titleRow.addView(sectionTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView hint = Ui.text(activity, "بروزرسانی آنلاین", 9.5f, Ui.MUTED2, false);
        titleRow.addView(hint);
        page.addView(titleRow);

        list = Ui.vertical(activity);
        list.setPadding(Ui.dp(activity, 14), 0, Ui.dp(activity, 14), Ui.dp(activity, 28));
        page.addView(list);

        scroll.addView(page, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (delayedSearch != null) handler.removeCallbacks(delayedSearch);
                delayedSearch = TutorialsController.this::renderAll;
                handler.postDelayed(delayedSearch, 160);
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        renderAll();
        refreshRemote();
    }

    public View view() {
        if (root.getParent() instanceof ViewGroup) ((ViewGroup)root.getParent()).removeView(root);
        return root;
    }

    public void refreshIfNeeded() {
        if (SystemClock.elapsedRealtime() - lastLoadedAt > 60000) refreshRemote();
    }

    private LinearLayout labelRow(String title, String caption) {
        LinearLayout row = Ui.horizontal(activity);
        row.setPadding(Ui.dp(activity, 16), Ui.dp(activity, 12), Ui.dp(activity, 16), Ui.dp(activity, 8));
        row.addView(Ui.text(activity, title, 15, Ui.TEXT, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(Ui.text(activity, caption, 9.5f, Ui.MUTED2, false));
        return row;
    }

    private void indexSeed() {
        seedById.clear();
        JSONArray a = seed.optJSONArray("tutorials");
        if (a == null) return;
        for (int i=0;i<a.length();i++) {
            JSONObject t = a.optJSONObject(i);
            if (t != null) seedById.put(t.optString("id"), t);
        }
    }

    private void loadInitialData() {
        try {
            String c = prefs.getString("categories_cache", "");
            String t = prefs.getString("tutorials_cache", "");
            categories = c.isEmpty() ? seed.optJSONArray("categories") : new JSONArray(c);
            tutorials = t.isEmpty() ? seed.optJSONArray("tutorials") : new JSONArray(t);
        } catch (Exception e) {
            categories = seed.optJSONArray("categories");
            tutorials = seed.optJSONArray("tutorials");
        }
        if (categories == null) categories = new JSONArray();
        if (tutorials == null) tutorials = new JSONArray();
        mergeSeedBodies();
    }

    private void mergeSeedBodies() {
        for (int i=0;i<tutorials.length();i++) {
            JSONObject remote = tutorials.optJSONObject(i);
            if (remote == null) continue;
            JSONObject local = seedById.get(remote.optString("id"));
            if (local != null) {
                if (remote.optString("body").trim().isEmpty()) {
                    try { remote.put("body", local.optString("body")); } catch (Exception ignored) {}
                }
                if (remote.optString("sourceUrl").trim().isEmpty()) {
                    try {
                        remote.put("sourceUrl", local.optString("sourceUrl"));
                        remote.put("sourceTitle", local.optString("sourceTitle"));
                    } catch (Exception ignored) {}
                }
            }
        }
    }

    private void refreshRemote() {
        loading.setVisibility(View.VISIBLE);
        api.post("app.php?action=categories", new JSONObject(), null, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) {
                JSONArray a = json.optJSONArray("categories");
                if (a != null && a.length() > 0) {
                    categories = a;
                    prefs.edit().putString("categories_cache", a.toString()).apply();
                    renderAll();
                }
            }
            @Override public void fail(String message) { }
        });

        JSONObject body = new JSONObject();
        try { body.put("limit", 100); } catch (Exception ignored) {}
        api.post("app.php?action=tutorials", body, null, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) {
                JSONArray a = json.optJSONArray("tutorials");
                if (a != null && a.length() > 0) {
                    tutorials = a;
                    mergeSeedBodies();
                    prefs.edit().putString("tutorials_cache", tutorials.toString()).apply();
                    lastLoadedAt = SystemClock.elapsedRealtime();
                    networkBadge.setText("آنلاین");
                    loading.setVisibility(View.GONE);
                    renderAll();
                } else {
                    loading.setVisibility(View.GONE);
                }
            }
            @Override public void fail(String message) {
                networkBadge.setText("آفلاین آماده");
                loading.setVisibility(View.GONE);
            }
        });
    }

    private void renderAll() {
        categoryCount.setText(categories.length() + " دسته");
        tutorialCount.setText(tutorials.length() + " آموزش");
        renderFeatured();
        renderCategories();
        renderTutorials();
    }

    private void renderFeatured() {
        featuredRow.removeAllViews();
        int added = 0;
        for (int i=0;i<tutorials.length() && added<7;i++) {
            JSONObject t = tutorials.optJSONObject(i);
            if (t == null || !t.optBoolean("active", true) || !t.optBoolean("featured", false)) continue;
            featuredRow.addView(featuredCard(t));
            added++;
        }
        if (added == 0) {
            TextView empty = Ui.text(activity, "مطلب ویژه‌ای ثبت نشده است.", 11, Ui.MUTED, false);
            empty.setPadding(Ui.dp(activity, 12), Ui.dp(activity, 12), Ui.dp(activity, 12), Ui.dp(activity, 12));
            featuredRow.addView(empty);
        }
    }

    private View featuredCard(JSONObject t) {
        LinearLayout card = Ui.goldCard(activity);
        card.setPadding(Ui.dp(activity, 14), Ui.dp(activity, 14), Ui.dp(activity, 14), Ui.dp(activity, 14));
        TextView icon = Ui.text(activity, categoryIcon(t.optString("categoryId")), 30, Ui.GOLD2, false);
        card.addView(icon, Ui.lpMatchWrap(activity, 0, 7));
        TextView title = Ui.text(activity, t.optString("title"), 14, Ui.TEXT, true);
        title.setMaxLines(2);
        card.addView(title);
        TextView summary = Ui.text(activity, t.optString("summary"), 9.5f, Ui.MUTED, false);
        summary.setMaxLines(3);
        card.addView(summary, Ui.lpMatchWrap(activity, 5, 10));
        LinearLayout meta = Ui.horizontal(activity);
        meta.addView(Ui.pill(activity, t.optInt("duration",0)+" دقیقه", Color.rgb(49,30,0), Ui.GOLD2));
        card.addView(meta);
        card.setOnClickListener(v -> openDetail(t));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(activity, 235), ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(Ui.dp(activity, 5), 0, Ui.dp(activity, 5), 0);
        card.setLayoutParams(p);
        return card;
    }

    private void renderCategories() {
        categoryRow.removeAllViews();
        addCategoryChip("", "همه", "✨");
        for (int i=0;i<categories.length();i++) {
            JSONObject c=categories.optJSONObject(i);
            if (c == null || !c.optBoolean("active",true) || c.optBoolean("deleted",false)) continue;
            addCategoryChip(c.optString("id"), c.optString("name"), c.optString("icon","📘"));
        }
    }

    private void addCategoryChip(String id, String name, String icon) {
        boolean active = id.equals(selectedCategory);
        LinearLayout chip = Ui.horizontal(activity);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(Ui.dp(activity, 12), 0, Ui.dp(activity, 12), 0);
        chip.setBackground(active
                ? Ui.gradient(Ui.GOLD2, Ui.GOLD, 16, Color.argb(120,255,239,173), 1, activity)
                : Ui.gradient(Color.rgb(35,40,59), Color.rgb(21,24,37), 16, Color.argb(34,255,255,255), 1, activity));
        TextView i=Ui.text(activity,icon,14,active?Color.rgb(50,30,0):Ui.GOLD2,false);
        TextView n=Ui.text(activity,name,10.5f,active?Color.rgb(50,30,0):Ui.TEXT,true);
        i.setGravity(Gravity.CENTER); n.setGravity(Gravity.CENTER);
        chip.addView(i); Ui.gap(chip,activity,6); chip.addView(n);
        chip.setOnClickListener(v->{selectedCategory=id; renderAll();});
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,Ui.dp(activity,42));
        p.setMargins(Ui.dp(activity,4),0,Ui.dp(activity,4),0);
        categoryRow.addView(chip,p);
    }

    private String categoryIcon(String id) {
        for(int i=0;i<categories.length();i++) {
            JSONObject c=categories.optJSONObject(i);
            if(c!=null && id.equals(c.optString("id"))) return c.optString("icon","📘");
        }
        return "📘";
    }

    private String categoryName(String id) {
        for(int i=0;i<categories.length();i++) {
            JSONObject c=categories.optJSONObject(i);
            if(c!=null && id.equals(c.optString("id"))) return c.optString("name","آموزش");
        }
        return "آموزش";
    }

    private void renderTutorials() {
        list.removeAllViews();
        String q = search.getText().toString().trim().toLowerCase();
        int shown=0;
        for(int i=0;i<tutorials.length();i++) {
            JSONObject t=tutorials.optJSONObject(i);
            if(t==null || !t.optBoolean("active",true) || t.optBoolean("deleted",false)) continue;
            if(!selectedCategory.isEmpty() && !selectedCategory.equals(t.optString("categoryId"))) continue;
            if(!q.isEmpty()) {
                String hay=(t.optString("title")+" "+t.optString("summary")+" "+String.valueOf(t.optJSONArray("tags"))).toLowerCase();
                if(!hay.contains(q)) continue;
            }
            LinearLayout card=tutorialCard(t);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
            p.setMargins(0,0,0,Ui.dp(activity,10));
            list.addView(card,p);
            shown++;
        }

        sectionTitle.setText(selectedCategory.isEmpty() ? "همه آموزش‌ها" : categoryName(selectedCategory));
        if(shown==0) {
            LinearLayout empty=Ui.card(activity);
            TextView icon=Ui.text(activity,"🔎",38,Ui.GOLD2,false); icon.setGravity(Gravity.CENTER);
            TextView title=Ui.text(activity,"چیزی پیدا نشد",16,Ui.TEXT,true); title.setGravity(Gravity.CENTER);
            TextView body=Ui.text(activity,"عبارت دیگری جستجو کن یا دسته «همه» را انتخاب کن.",11,Ui.MUTED,false); body.setGravity(Gravity.CENTER);
            empty.addView(icon); empty.addView(title,Ui.lpMatchWrap(activity,5,4)); empty.addView(body);
            list.addView(empty);
        }
    }

    private LinearLayout tutorialCard(JSONObject t) {
        LinearLayout card=Ui.card(activity);
        card.setPadding(Ui.dp(activity,14),Ui.dp(activity,14),Ui.dp(activity,14),Ui.dp(activity,14));

        LinearLayout top=Ui.horizontal(activity);
        String cover=ApiClient.absolute(t.optString("cover"));
        if(!cover.isEmpty()) {
            ImageView image=new ImageView(activity);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackground(Ui.bg(Ui.PANEL2,16,Color.argb(38,255,255,255),1,activity));
            top.addView(image,new LinearLayout.LayoutParams(Ui.dp(activity,86),Ui.dp(activity,86)));
            images.load(image,cover);
        } else {
            TextView placeholder=Ui.text(activity,categoryIcon(t.optString("categoryId")),32,Ui.GOLD2,false);
            placeholder.setGravity(Gravity.CENTER);
            placeholder.setBackground(Ui.gradient(Color.rgb(59,45,24),Color.rgb(27,29,39),18,
                    Color.argb(74,255,197,51),1,activity));
            top.addView(placeholder,new LinearLayout.LayoutParams(Ui.dp(activity,82),Ui.dp(activity,82)));
        }
        Ui.gap(top,activity,12);

        LinearLayout info=Ui.vertical(activity);
        LinearLayout tagRow=Ui.horizontal(activity);
        tagRow.addView(Ui.pill(activity,categoryName(t.optString("categoryId")),Ui.GOLD2,Color.argb(18,255,197,51)));
        if(t.optBoolean("featured",false)) {
            Ui.gap(tagRow,activity,5);
            tagRow.addView(Ui.pill(activity,"ویژه",Color.rgb(49,30,0),Ui.GOLD2));
        }
        info.addView(tagRow);
        TextView title=Ui.text(activity,t.optString("title"),16,Ui.TEXT,true); title.setMaxLines(2);
        info.addView(title,Ui.lpMatchWrap(activity,7,4));
        TextView summary=Ui.text(activity,t.optString("summary"),10.5f,Ui.MUTED,false); summary.setMaxLines(2);
        info.addView(summary);
        top.addView(info,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));
        card.addView(top);

        LinearLayout foot=Ui.horizontal(activity);
        TextView meta=Ui.text(activity,t.optString("level","مبتدی")+"  •  "+t.optInt("duration",0)+" دقیقه",9.5f,Ui.MUTED2,false);
        foot.addView(meta,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));
        TextView arrow=Ui.text(activity,"‹",25,Ui.GOLD2,true);
        foot.addView(arrow);
        card.addView(foot,Ui.lpMatchWrap(activity,10,0));

        card.setOnClickListener(v->openDetail(t));
        return card;
    }

    private void openDetail(JSONObject row) {
        String body=row.optString("body").trim();
        if(!body.isEmpty()) { showDetailDialog(row); return; }

        JSONObject cached=readDetailCache(row.optString("id"));
        if(cached!=null) { showDetailDialog(cached); return; }

        JSONObject b=new JSONObject();
        try { b.put("id",row.optString("id")); } catch(Exception ignored) {}
        activity.toast("در حال دریافت آموزش...");
        api.post("app.php?action=tutorial",b,null,new ApiClient.Callback(){
            @Override public void ok(JSONObject json){
                JSONObject t=json.optJSONObject("tutorial");
                if(t!=null){ cacheDetail(t); showDetailDialog(t); }
            }
            @Override public void fail(String message){
                JSONObject seedRow=seedById.get(row.optString("id"));
                if(seedRow!=null) showDetailDialog(seedRow); else activity.toast(message);
            }
        });
    }

    private void cacheDetail(JSONObject t) {
        prefs.edit().putString("detail_"+t.optString("id"),t.toString()).apply();
    }

    private JSONObject readDetailCache(String id) {
        try {
            String raw=prefs.getString("detail_"+id,"");
            return raw.isEmpty()?null:new JSONObject(raw);
        } catch(Exception ignored){ return null; }
    }

    private void showDetailDialog(JSONObject t) {
        Dialog dialog=new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout shell=Ui.vertical(activity);
        shell.setPadding(Ui.dp(activity,14),Ui.dp(activity,14),Ui.dp(activity,14),Ui.dp(activity,16));
        shell.setBackground(Ui.gradient(Color.rgb(29,33,49),Color.rgb(10,12,19),26,
                Color.argb(64,255,255,255),1,activity));

        LinearLayout topBar=Ui.horizontal(activity);
        LinearLayout titles=Ui.vertical(activity);
        titles.addView(Ui.sectionEyebrow(activity,categoryIcon(t.optString("categoryId"))+"  "+categoryName(t.optString("categoryId"))));
        TextView title=Ui.text(activity,t.optString("title"),20,Ui.TEXT,true);
        titles.addView(title,Ui.lpMatchWrap(activity,4,0));
        topBar.addView(titles,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));
        TextView close=Ui.text(activity,"×",30,Ui.MUTED,false); close.setGravity(Gravity.CENTER); close.setOnClickListener(v->dialog.dismiss());
        topBar.addView(close,new LinearLayout.LayoutParams(Ui.dp(activity,44),Ui.dp(activity,44)));
        shell.addView(topBar,Ui.lpMatchWrap(activity,0,10));

        ScrollView sv=new ScrollView(activity);
        LinearLayout wrap=Ui.vertical(activity);

        String cover=ApiClient.absolute(t.optString("cover"));
        if(!cover.isEmpty()){
            ImageView image=new ImageView(activity); image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackground(Ui.bg(Ui.PANEL2,18,Color.argb(40,255,255,255),1,activity));
            wrap.addView(image,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,210)));
            images.load(image,cover);
        }

        LinearLayout meta=Ui.horizontal(activity);
        meta.addView(Ui.pill(activity,t.optString("level","مبتدی"),Ui.GOLD2,Color.argb(20,255,197,51)));
        Ui.gap(meta,activity,6);
        meta.addView(Ui.pill(activity,t.optInt("duration",0)+" دقیقه",Ui.BLUE,Color.argb(20,107,167,255)));
        if(t.optBoolean("featured",false)){Ui.gap(meta,activity,6);meta.addView(Ui.pill(activity,"پیشنهاد ویژه",Color.rgb(49,30,0),Ui.GOLD2));}
        wrap.addView(meta,Ui.lpMatchWrap(activity,4,12));

        TextView summary=Ui.text(activity,t.optString("summary"),12,Ui.MUTED,false);
        summary.setLineSpacing(Ui.dp(activity,1),1.35f);
        summary.setBackground(Ui.bg(Color.argb(120,24,28,42),15,Color.argb(30,255,255,255),1,activity));
        summary.setPadding(Ui.dp(activity,12),Ui.dp(activity,11),Ui.dp(activity,12),Ui.dp(activity,11));
        wrap.addView(summary,Ui.lpMatchWrap(activity,0,14));

        TextView bodyText=Ui.text(activity,t.optString("body"),14.2f,Ui.TEXT,false);
        bodyText.setTextIsSelectable(true);
        bodyText.setLineSpacing(Ui.dp(activity,4),1.45f);
        wrap.addView(bodyText,Ui.lpMatchWrap(activity,0,18));

        LinearLayout actions=Ui.horizontal(activity);
        String source=t.optString("sourceUrl").trim();
        if(!source.isEmpty()){
            Button sourceBtn=Ui.button(activity,"مشاهده منبع",false);
            sourceBtn.setOnClickListener(v->openUrl(source));
            actions.addView(sourceBtn,new LinearLayout.LayoutParams(0,Ui.dp(activity,48),1f));
        }
        String video=t.optString("videoUrl").trim();
        if(!video.isEmpty()){
            if(actions.getChildCount()>0) Ui.gap(actions,activity,8);
            Button videoBtn=Ui.button(activity,"ویدیو",false);
            videoBtn.setOnClickListener(v->openUrl(video));
            actions.addView(videoBtn,new LinearLayout.LayoutParams(0,Ui.dp(activity,48),1f));
        }
        if(actions.getChildCount()>0) wrap.addView(actions,Ui.lpMatchWrap(activity,0,10));

        Button share=Ui.button(activity,"اشتراک‌گذاری عنوان آموزش",true);
        share.setOnClickListener(v->shareTutorial(t));
        wrap.addView(share,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,50)));

        TextView disclaimer=Ui.text(activity,"این محتوا آموزشی است و توصیه سرمایه‌گذاری محسوب نمی‌شود.",9.5f,Ui.MUTED2,false);
        disclaimer.setGravity(Gravity.CENTER);
        wrap.addView(disclaimer,Ui.lpMatchWrap(activity,12,4));

        sv.addView(wrap,new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
        shell.addView(sv,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f));

        dialog.setContentView(shell);
        dialog.show();
        Window w=dialog.getWindow();
        if(w!=null){
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout((int)(activity.getResources().getDisplayMetrics().widthPixels*.94f),
                    (int)(activity.getResources().getDisplayMetrics().heightPixels*.91f));
            w.setGravity(Gravity.CENTER);
        }
    }

    private void openUrl(String url) {
        try { activity.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url))); }
        catch(Exception e){ activity.toast("لینک باز نشد"); }
    }

    private void shareTutorial(JSONObject t) {
        try {
            Intent i=new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            String s=t.optString("title")+"\n\n"+t.optString("summary");
            String source=t.optString("sourceUrl").trim();
            if(!source.isEmpty()) s+="\n\nمنبع: "+source;
            i.putExtra(Intent.EXTRA_TEXT,s);
            activity.startActivity(Intent.createChooser(i,"اشتراک‌گذاری آموزش"));
        } catch(Exception e){ activity.toast("اشتراک‌گذاری انجام نشد"); }
    }
}
