# Hamster Native v3.1.0 (9)

نسخه Native برنامه آموزش همستر با Package اصلی:

- applicationId: `com.maniplus.notcoin`
- versionName: `3.1.0`
- versionCode: `9`
- targetSdk: `36`
- minSdk: `21`
- Signing: همان keystore اصلی نسخه Appche
- Backend: `https://persian-melody.ir/api/`

## ساختار برنامه

- سربرگ اصلی پایین: آموزش / بازی همستر
- آموزش: دسته‌بندی‌ها، جستجو، لیست و جزئیات آموزش از Backend
- بازی: خانه، بوست، مأموریت، لیگ، زیرمجموعه و پروفایل به صورت Native Android
- WebView برای رابط کاربری استفاده نشده است.
- بازی از API فعلی Backend استفاده می‌کند.
- Session قدیمی WebView در اولین اجرا از Cookie Store همان Package بازیابی می‌شود و سپس Token در Native app ذخیره می‌شود.
- صفحه شروع و وضعیت بازی (فعال/به‌زودی) از پنل مدیریت خوانده می‌شود.

## Signing

فایل `signing/hamster-release.jks` داخل پروژه قرار دارد.

- Store password: `1234`
- Alias: `hellosc`
- Key password: `1234`

## Build

Workflow همراه این تحویل ZIP را بدون استخراج دستی پیدا و Extract می‌کند و APK Release را می‌سازد.
