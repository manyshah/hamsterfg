package com.maniplus.notcoin;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

public final class TutorialsController {
    private final MainActivity activity;
    private final ApiClient api;
    private final ImageLoader images;
    private final LinearLayout root;
    private final LinearLayout categoryRow;
    private final LinearLayout list;
    private final EditText search;
    private final ProgressBar loading;
    private JSONArray categories = new JSONArray();
    private JSONArray tutorials = new JSONArray();
    private String selectedCategory = "";
    private long lastLoadedAt = 0;
    private Runnable delayedSearch;
    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());

    public TutorialsController(MainActivity activity, ApiClient api, ImageLoader images) {
        this.activity = activity;
        this.api = api;
        this.images = images;
        root = Ui.vertical(activity);
        root.setBackgroundColor(Color.rgb(10, 16, 28));

        LinearLayout header = Ui.vertical(activity);
        header.setPadding(Ui.dp(activity, 16), Ui.dp(activity, 16), Ui.dp(activity, 16), Ui.dp(activity, 10));
        TextView title = Ui.title(activity, "آموزش فارسی");
        TextView sub = Ui.text(activity, "آموزش‌های دسته‌بندی‌شده؛ محتوای جدید مستقیم از پنل منتشر می‌شود.", 12, Ui.MUTED, false);
        header.addView(title, Ui.lpMatchWrap(activity, 0, 5));
        header.addView(sub, Ui.lpMatchWrap(activity, 0, 12));

        search = new EditText(activity);
        search.setHint("جستجوی آموزش...");
        search.setHintTextColor(Color.rgb(120,130,150));
        search.setTextColor(Ui.TEXT);
        search.setTextSize(14);
        search.setSingleLine(true);
        search.setPadding(Ui.dp(activity,14), 0, Ui.dp(activity,14), 0);
        search.setBackground(Ui.bg(Ui.PANEL, 16, Color.argb(42,255,255,255), 1, activity));
        header.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 48)));
        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        HorizontalScrollView hsv = new HorizontalScrollView(activity);
        hsv.setHorizontalScrollBarEnabled(false);
        categoryRow = Ui.horizontal(activity);
        categoryRow.setPadding(Ui.dp(activity,12), 0, Ui.dp(activity,12), Ui.dp(activity,10));
        hsv.addView(categoryRow, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        loading = new ProgressBar(activity);
        root.addView(loading, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity, 3)));

        ScrollView scroll = new ScrollView(activity);
        scroll.setFillViewport(true);
        list = Ui.vertical(activity);
        list.setPadding(Ui.dp(activity,12), Ui.dp(activity,8), Ui.dp(activity,12), Ui.dp(activity,26));
        scroll.addView(list, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (delayedSearch != null) handler.removeCallbacks(delayedSearch);
                delayedSearch = () -> loadTutorials();
                handler.postDelayed(delayedSearch, 350);
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        loadCategories();
        loadTutorials();
    }

    public View view() {
        if (root.getParent() instanceof ViewGroup) ((ViewGroup)root.getParent()).removeView(root);
        return root;
    }

    public void refreshIfNeeded() {
        if (SystemClock.elapsedRealtime() - lastLoadedAt > 60000) {
            loadCategories();
            loadTutorials();
        }
    }

    private void loadCategories() {
        api.post("app.php?action=categories", new JSONObject(), null, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) {
                categories = json.optJSONArray("categories");
                if (categories == null) categories = new JSONArray();
                renderCategories();
            }
            @Override public void fail(String message) { activity.toast(message); }
        });
    }

    private void renderCategories() {
        categoryRow.removeAllViews();
        addCategoryChip("", "همه", "✨");
        for (int i=0;i<categories.length();i++) {
            JSONObject c = categories.optJSONObject(i);
            if (c == null || !c.optBoolean("active", true)) continue;
            addCategoryChip(c.optString("id"), c.optString("name"), c.optString("icon", "📘"));
        }
    }

    private void addCategoryChip(String id, String name, String icon) {
        boolean active = id.equals(selectedCategory);
        Button b = Ui.button(activity, icon + "  " + name, active);
        b.setTextSize(11);
        b.setMinHeight(Ui.dp(activity, 38));
        b.setOnClickListener(v -> { selectedCategory = id; renderCategories(); loadTutorials(); });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(activity, 40));
        p.setMargins(Ui.dp(activity,4), 0, Ui.dp(activity,4), 0);
        categoryRow.addView(b, p);
    }

    private void loadTutorials() {
        loading.setVisibility(View.VISIBLE);
        JSONObject body = new JSONObject();
        try {
            body.put("categoryId", selectedCategory);
            body.put("q", search.getText().toString().trim());
            body.put("limit", 100);
        } catch (Exception ignored) {}
        api.post("app.php?action=tutorials", body, null, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) {
                tutorials = json.optJSONArray("tutorials");
                if (tutorials == null) tutorials = new JSONArray();
                lastLoadedAt = SystemClock.elapsedRealtime();
                loading.setVisibility(View.GONE);
                renderTutorials();
            }
            @Override public void fail(String message) {
                loading.setVisibility(View.GONE);
                if (tutorials.length() == 0) empty(message);
            }
        });
    }

    private void renderTutorials() {
        list.removeAllViews();
        if (tutorials.length() == 0) { empty("آموزشی در این بخش ثبت نشده است."); return; }
        for (int i=0;i<tutorials.length();i++) {
            JSONObject t = tutorials.optJSONObject(i);
            if (t != null) list.addView(tutorialCard(t), Ui.lpMatchWrap(activity, 0, 10));
        }
    }

    private void empty(String message) {
        list.removeAllViews();
        TextView t = Ui.text(activity, message, 14, Ui.MUTED, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(activity,20), Ui.dp(activity,70), Ui.dp(activity,20), Ui.dp(activity,20));
        list.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private View tutorialCard(JSONObject t) {
        LinearLayout card = Ui.card(activity);
        card.setOnClickListener(v -> openDetail(t.optString("id")));
        LinearLayout top = Ui.horizontal(activity);
        String cover = ApiClient.absolute(t.optString("cover"));
        if (!cover.isEmpty()) {
            ImageView image = new ImageView(activity);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackground(Ui.bg(Ui.PANEL2, 14, Color.TRANSPARENT,0,activity));
            top.addView(image, new LinearLayout.LayoutParams(Ui.dp(activity,78), Ui.dp(activity,78)));
            images.load(image, cover);
            Ui.gap(top, activity, 12);
        }
        LinearLayout info = Ui.vertical(activity);
        TextView title = Ui.text(activity, t.optString("title"), 16, Ui.TEXT, true);
        TextView summary = Ui.text(activity, t.optString("summary"), 11, Ui.MUTED, false);
        info.addView(title, Ui.lpMatchWrap(activity,0,5));
        info.addView(summary, Ui.lpMatchWrap(activity,0,7));
        String meta = t.optString("level", "مبتدی") + "  ·  " + t.optInt("duration",0) + " دقیقه" + (t.optBoolean("featured",false) ? "  ·  ⭐ ویژه" : "");
        info.addView(Ui.text(activity, meta, 10, Ui.GOLD2, true));
        top.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return card;
    }

    private void openDetail(String id) {
        JSONObject b = new JSONObject(); try { b.put("id", id); } catch (Exception ignored) {}
        activity.toast("در حال دریافت آموزش...");
        api.post("app.php?action=tutorial", b, null, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) {
                JSONObject t = json.optJSONObject("tutorial"); if (t != null) showDetailDialog(t);
            }
            @Override public void fail(String message) { activity.toast(message); }
        });
    }

    private void showDetailDialog(JSONObject t) {
        ScrollView sv = new ScrollView(activity);
        LinearLayout wrap = Ui.vertical(activity);
        wrap.setPadding(Ui.dp(activity,18), Ui.dp(activity,8), Ui.dp(activity,18), Ui.dp(activity,18));
        String cover = ApiClient.absolute(t.optString("cover"));
        if (!cover.isEmpty()) {
            ImageView image = new ImageView(activity); image.setScaleType(ImageView.ScaleType.CENTER_CROP); image.setAdjustViewBounds(true); image.setMinimumHeight(Ui.dp(activity,180));
            wrap.addView(image, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(activity,200))); images.load(image,cover);
        }
        wrap.addView(Ui.text(activity,t.optString("title"),21,Color.rgb(30,30,35),true),Ui.lpMatchWrap(activity,14,7));
        wrap.addView(Ui.text(activity,t.optString("summary"),12,Color.rgb(95,95,105),false),Ui.lpMatchWrap(activity,0,8));
        wrap.addView(Ui.text(activity,t.optString("level","مبتدی")+" · "+t.optInt("duration",0)+" دقیقه",11,Color.rgb(150,100,0),true),Ui.lpMatchWrap(activity,0,14));
        TextView body=Ui.text(activity,t.optString("body"),15,Color.rgb(40,40,45),false); body.setTextIsSelectable(true); body.setLineSpacing(Ui.dp(activity,2),1.35f); wrap.addView(body,Ui.lpMatchWrap(activity,0,16));
        String video=t.optString("videoUrl").trim();
        if(!video.isEmpty()){
            Button vb=Ui.button(activity,"▶  مشاهده ویدیو",true); vb.setOnClickListener(v->{try{activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(video)));}catch(Exception e){activity.toast("لینک ویدیو باز نشد");}}); wrap.addView(vb,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,48)));
        }
        sv.addView(wrap,new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
        AlertDialog d=new AlertDialog.Builder(activity).setView(sv).setPositiveButton("بستن",null).create(); d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.rgb(160,105,0))); d.show();
    }
}
