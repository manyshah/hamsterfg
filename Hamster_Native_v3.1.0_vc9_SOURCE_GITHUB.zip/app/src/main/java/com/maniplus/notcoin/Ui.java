package com.maniplus.notcoin;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    public static final int BG = Color.rgb(8, 13, 23);
    public static final int PANEL = Color.rgb(18, 27, 46);
    public static final int PANEL2 = Color.rgb(24, 36, 59);
    public static final int TEXT = Color.rgb(247, 248, 252);
    public static final int MUTED = Color.rgb(168, 176, 194);
    public static final int GOLD = Color.rgb(246, 196, 83);
    public static final int GOLD2 = Color.rgb(255, 224, 122);
    public static final int GREEN = Color.rgb(67, 212, 150);
    public static final int RED = Color.rgb(255, 112, 128);
    public static final int BLUE = Color.rgb(104, 160, 255);

    private Ui() {}

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static LinearLayout vertical(Context c) {
        LinearLayout v = new LinearLayout(c);
        v.setOrientation(LinearLayout.VERTICAL);
        if (Build.VERSION.SDK_INT >= 17) v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return v;
    }

    public static LinearLayout horizontal(Context c) {
        LinearLayout v = new LinearLayout(c);
        v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL);
        if (Build.VERSION.SDK_INT >= 17) v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return v;
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s == null ? "" : s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLineSpacing(0, 1.22f);
        return t;
    }

    public static TextView title(Context c, String s) {
        return text(c, s, 22, TEXT, true);
    }

    public static GradientDrawable bg(int color, float radius, int strokeColor, int strokeDp, Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radius));
        if (strokeDp > 0) d.setStroke(dp(c, strokeDp), strokeColor);
        return d;
    }

    public static Button button(Context c, String s, boolean primary) {
        Button b = new Button(c);
        b.setText(s);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(c, 44));
        b.setPadding(dp(c, 12), 0, dp(c, 12), 0);
        if (primary) {
            b.setTextColor(Color.rgb(40, 25, 0));
            b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            b.setBackground(bg(GOLD2, 14, GOLD, 1, c));
        } else {
            b.setTextColor(TEXT);
            b.setBackground(bg(PANEL2, 14, Color.argb(45,255,255,255), 1, c));
        }
        return b;
    }

    public static LinearLayout card(Context c) {
        LinearLayout v = vertical(c);
        v.setPadding(dp(c, 14), dp(c, 14), dp(c, 14), dp(c, 14));
        v.setBackground(bg(PANEL, 20, Color.argb(38,255,255,255), 1, c));
        return v;
    }

    public static LinearLayout.LayoutParams lpMatchWrap(Context c, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(c, top), 0, dp(c, bottom));
        return p;
    }

    public static LinearLayout.LayoutParams lpWeight(float w) {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w);
    }

    public static void gap(LinearLayout parent, Context c, int dp) {
        View g = new View(c);
        parent.addView(g, new LinearLayout.LayoutParams(dp(c, dp), dp(c, dp)));
    }

    public static String faNumber(double n) {
        if (Math.abs(n - Math.rint(n)) < 0.00001) return String.format(java.util.Locale.US, "%,.0f", n);
        return String.format(java.util.Locale.US, "%,.1f", n);
    }
}
