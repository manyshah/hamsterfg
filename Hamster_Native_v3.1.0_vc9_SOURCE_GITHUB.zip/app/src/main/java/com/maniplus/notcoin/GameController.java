package com.maniplus.notcoin;

import android.animation.ObjectAnimator;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

public final class GameController {
    private final MainActivity activity;
    private final ApiClient api;
    private final ImageLoader images;
    private final SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final LinearLayout root;
    private final LinearLayout navRow;
    private final LinearLayout body;
    private JSONObject user = new JSONObject();
    private JSONObject missions = new JSONObject();
    private JSONArray cups = new JSONArray();
    private JSONArray boostCosts = new JSONArray();
    private String token = "";
    private String section = "home";
    private boolean loadingSession = false;
    private boolean paused = false;
    private int pendingTaps = 0;
    private boolean tapRequestInFlight = false;
    private String missionCategory = "";
    private final Runnable heartbeat = new Runnable() {
        @Override public void run() {
            if (!paused && !token.isEmpty()) callGame("heartbeat", new JSONObject(), false, null);
            handler.postDelayed(this, 30000);
        }
    };

    public GameController(MainActivity activity, ApiClient api, ImageLoader images, SharedPreferences prefs) {
        this.activity = activity; this.api = api; this.images = images; this.prefs = prefs;
        token = prefs.getString("session_token", "");
        root = Ui.vertical(activity);
        root.setBackgroundColor(Color.rgb(8,13,23));
        HorizontalScrollView hsv = new HorizontalScrollView(activity);
        hsv.setHorizontalScrollBarEnabled(false);
        navRow = Ui.horizontal(activity);
        navRow.setPadding(Ui.dp(activity,10), Ui.dp(activity,10), Ui.dp(activity,10), Ui.dp(activity,8));
        hsv.addView(navRow, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ScrollView scroll = new ScrollView(activity);
        scroll.setFillViewport(true);
        body = Ui.vertical(activity);
        body.setPadding(Ui.dp(activity,12), Ui.dp(activity,6), Ui.dp(activity,12), Ui.dp(activity,28));
        scroll.addView(body, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        renderNav();
        showLoading("در حال بازیابی حساب و دریافت اطلاعات...");
        ensureSession();
        handler.postDelayed(heartbeat, 30000);
    }

    public View view() {
        if (root.getParent() instanceof ViewGroup) ((ViewGroup)root.getParent()).removeView(root);
        return root;
    }

    public void resume() { paused = false; if (!token.isEmpty()) callGame("get", new JSONObject(), false, null); else ensureSession(); }
    public void pause() { paused = true; flushTaps(); }
    public void destroy() { handler.removeCallbacksAndMessages(null); }

    private void renderNav() {
        navRow.removeAllViews();
        addNav("home","🏠 خانه"); addNav("boosts","⚡ بوست"); addNav("missions","🎁 مأموریت"); addNav("league","🏆 لیگ"); addNav("referral","👥 زیرمجموعه"); addNav("profile","👤 پروفایل");
    }
    private void addNav(String id,String label){
        Button b=Ui.button(activity,label,id.equals(section)); b.setTextSize(10); b.setMinHeight(Ui.dp(activity,38)); b.setOnClickListener(v->{section=id;renderNav();renderSection();});
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,Ui.dp(activity,40));p.setMargins(Ui.dp(activity,3),0,Ui.dp(activity,3),0);navRow.addView(b,p);
    }

    private void showLoading(String text){body.removeAllViews();TextView t=Ui.text(activity,text,14,Ui.MUTED,false);t.setGravity(Gravity.CENTER);t.setPadding(10,Ui.dp(activity,80),10,20);body.addView(t);}
    private void showError(String msg){body.removeAllViews();LinearLayout c=Ui.card(activity);TextView t=Ui.text(activity,msg,14,Ui.RED,false);t.setGravity(Gravity.CENTER);c.addView(t,Ui.lpMatchWrap(activity,0,12));Button r=Ui.button(activity,"تلاش دوباره",true);r.setOnClickListener(v->ensureSession());c.addView(r,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,46)));body.addView(c,Ui.lpMatchWrap(activity,30,0));}

    private void ensureSession(){
        if(loadingSession)return;loadingSession=true;
        if(token.isEmpty()){
            String cookie=CookieManager.getInstance().getCookie(ApiClient.SITE);
            String recovered=extractCookie(cookie,"hamster_hamsterToken");if(recovered.isEmpty())recovered=extractCookie(cookie,"hamster_session_token");
            if(recovered.matches("[a-fA-F0-9]{64}")){token=recovered.toLowerCase();prefs.edit().putString("session_token",token).apply();}
        }
        JSONObject b=new JSONObject();
        api.post("auth.php?action=guest",b,token,new ApiClient.Callback(){
            @Override public void ok(JSONObject json){loadingSession=false;applyAuthResponse(json);activity.toast(json.optBoolean("guestResumed",false)||json.optBoolean("accountResumed",false)?"حساب قبلی بازیابی شد":"بازی آماده است");}
            @Override public void fail(String message){loadingSession=false;showError(message);}
        });
    }
    private String extractCookie(String all,String name){if(all==null)return"";for(String part:all.split(";")){String p=part.trim();int eq=p.indexOf('=');if(eq>0&&p.substring(0,eq).trim().equals(name))return p.substring(eq+1).trim();}return"";}

    private void applyAuthResponse(JSONObject json){String t=json.optString("token");if(!t.isEmpty()){token=t;prefs.edit().putString("session_token",t).apply();}applyGameResponse(json);}
    private void applyGameResponse(JSONObject json){JSONObject u=json.optJSONObject("user");if(u!=null)user=u;JSONObject m=json.optJSONObject("missions");if(m!=null)missions=m;JSONArray c=json.optJSONArray("cups");if(c!=null)cups=c;JSONArray bc=json.optJSONArray("boostCosts");if(bc!=null)boostCosts=bc;renderSection();double passive=json.optDouble("passiveEarned",0);if(passive>0.5)activity.toast("+"+Ui.faNumber(passive)+" سکه درآمد آفلاین");}

    private JSONObject game(){JSONObject g=user.optJSONObject("game");return g==null?new JSONObject():g;}
    private boolean isGuest(){return user.optBoolean("isGuest",true);}

    private void callGame(String action,JSONObject payload,boolean toastErrors,Runnable after){
        api.post("game.php?action="+action,payload,token,new ApiClient.Callback(){@Override public void ok(JSONObject json){applyGameResponse(json);if(after!=null)after.run();}@Override public void fail(String message){if(toastErrors)activity.toast(message);if(after!=null)after.run();}});
    }

    private void renderSection(){if(user.length()==0){showLoading("در حال دریافت اطلاعات بازی...");return;}switch(section){case"boosts":renderBoosts();break;case"missions":renderMissions();break;case"league":renderLeague();break;case"referral":renderReferral();break;case"profile":renderProfile();break;default:renderHome();}}

    private void renderHome(){
        body.removeAllViews();JSONObject g=game();
        LinearLayout stats=Ui.horizontal(activity);
        stats.addView(statBox("سکه",Ui.faNumber(g.optDouble("coins")),"🪙"),Ui.lpWeight(1));Ui.gap(stats,activity,7);stats.addView(statBox("قدرت ضربه",Ui.faNumber(g.optDouble("power",1)),"👆"),Ui.lpWeight(1));Ui.gap(stats,activity,7);stats.addView(statBox("در ساعت",Ui.faNumber(g.optDouble("hourlyIncome")),"⏱"),Ui.lpWeight(1));
        body.addView(stats,Ui.lpMatchWrap(activity,0,12));
        String cupFa=currentCupFa(g.optString("league","Bronze"));TextView league=Ui.text(activity,"🏆 "+cupFa+"   ·   "+Ui.faNumber(g.optDouble("coins"))+" سکه",12,Ui.GOLD2,true);league.setGravity(Gravity.CENTER);body.addView(league,Ui.lpMatchWrap(activity,0,10));
        ImageView hamster=new ImageView(activity);hamster.setImageResource(com.maniplus.notcoin.R.drawable.tap_hamster);hamster.setScaleType(ImageView.ScaleType.CENTER_INSIDE);hamster.setAdjustViewBounds(true);hamster.setOnClickListener(v->onTapHamster(hamster));body.addView(hamster,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,330)));
        double energy=g.optDouble("energy"),max=Math.max(1,g.optDouble("maxEnergy",1000));LinearLayout energyCard=Ui.card(activity);TextView e=Ui.text(activity,"⚡ "+Ui.faNumber(energy)+" / "+Ui.faNumber(max),14,Ui.TEXT,true);energyCard.addView(e,Ui.lpMatchWrap(activity,0,8));ProgressBar pb=new ProgressBar(activity,null,android.R.attr.progressBarStyleHorizontal);pb.setMax(1000);pb.setProgress((int)Math.max(0,Math.min(1000,energy/max*1000)));energyCard.addView(pb,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,8)));body.addView(energyCard,Ui.lpMatchWrap(activity,8,10));
        LinearLayout quick=Ui.horizontal(activity);Button turbo=Ui.button(activity,"🚀 توربو  "+Math.max(0,3-g.optInt("turboUsed"))+"/3",false);Button fill=Ui.button(activity,"⚡ انرژی فوری  "+Math.max(0,3-g.optInt("instantEnergyUsed"))+"/3",false);turbo.setOnClickListener(v->quickBoost("turbo"));fill.setOnClickListener(v->quickBoost("energy"));quick.addView(turbo,Ui.lpWeight(1));Ui.gap(quick,activity,8);quick.addView(fill,Ui.lpWeight(1));body.addView(quick,Ui.lpMatchWrap(activity,0,10));
        if(g.optLong("turboUntil",0)>System.currentTimeMillis()/1000L){TextView active=Ui.text(activity,"🚀 توربو فعال است؛ قدرت ضربه دو برابر شده.",12,Ui.GREEN,true);active.setGravity(Gravity.CENTER);body.addView(active,Ui.lpMatchWrap(activity,0,8));}
        TextView hint=Ui.text(activity,"روی همستر ضربه بزن و با ارتقاها و مأموریت‌ها درآمد ساعتی بساز.",11,Ui.MUTED,false);hint.setGravity(Gravity.CENTER);body.addView(hint,Ui.lpMatchWrap(activity,0,0));
    }

    private View statBox(String label,String value,String icon){LinearLayout c=Ui.card(activity);c.setGravity(Gravity.CENTER);TextView i=Ui.text(activity,icon,18,Ui.GOLD,false);i.setGravity(Gravity.CENTER);TextView v=Ui.text(activity,value,14,Ui.TEXT,true);v.setGravity(Gravity.CENTER);TextView l=Ui.text(activity,label,9,Ui.MUTED,false);l.setGravity(Gravity.CENTER);c.addView(i);c.addView(v);c.addView(l);return c;}
    private String currentCupFa(String code){for(int i=0;i<cups.length();i++){JSONObject c=cups.optJSONObject(i);if(c!=null&&code.equals(c.optString("name")))return c.optString("fa",code);}return code;}

    private void onTapHamster(ImageView hamster){JSONObject g=game();double power=g.optDouble("power",1);if(g.optLong("turboUntil",0)>System.currentTimeMillis()/1000L)power*=2;if(g.optDouble("energy")<power){activity.toast("انرژی کافی نیست");return;}pendingTaps=Math.min(250,pendingTaps+1);ObjectAnimator sx=ObjectAnimator.ofFloat(hamster,"scaleX",1f,.94f,1f);ObjectAnimator sy=ObjectAnimator.ofFloat(hamster,"scaleY",1f,.94f,1f);sx.setDuration(130);sy.setDuration(130);sx.start();sy.start();handler.removeCallbacks(flushTapRunnable);handler.postDelayed(flushTapRunnable,90);}
    private final Runnable flushTapRunnable=this::flushTaps;
    private void flushTaps(){if(tapRequestInFlight||pendingTaps<=0||token.isEmpty())return;int count=Math.min(25,pendingTaps);pendingTaps-=count;tapRequestInFlight=true;JSONObject b=new JSONObject();try{b.put("count",count);}catch(Exception ignored){}api.post("game.php?action=tap",b,token,new ApiClient.Callback(){@Override public void ok(JSONObject json){tapRequestInFlight=false;applyGameResponse(json);if(pendingTaps>0)handler.postDelayed(flushTapRunnable,40);}@Override public void fail(String message){tapRequestInFlight=false;activity.toast(message);pendingTaps=0;}});}

    private void quickBoost(String type){JSONObject b=new JSONObject();try{b.put("type",type);}catch(Exception ignored){}callGame("quick_boost",b,true,null);}

    private void renderBoosts(){
        body.removeAllViews();body.addView(sectionTitle("⚡ قدرت‌ها و ارتقاهای بازی","بوست‌ها"),Ui.lpMatchWrap(activity,0,10));JSONObject g=game();
        body.addView(boostCard("👆 قدرت ضربه","هر ضربه سکه بیشتری می‌دهد","power",g.optInt("tapLevel",1)),Ui.lpMatchWrap(activity,0,10));
        body.addView(boostCard("🔋 ظرفیت انرژی","حداکثر انرژی را بیشتر می‌کند","energy",g.optInt("energyLevel",1)),Ui.lpMatchWrap(activity,0,10));
        body.addView(boostCard("⚡ سرعت شارژ","انرژی سریع‌تر بازیابی می‌شود","recharge",g.optInt("rechargeLevel",1)),Ui.lpMatchWrap(activity,0,10));
        LinearLayout q=Ui.card(activity);q.addView(Ui.text(activity,"بوست‌های روزانه",16,Ui.TEXT,true),Ui.lpMatchWrap(activity,0,9));Button e=Ui.button(activity,"⚡ پرکردن کامل انرژی · "+Math.max(0,3-g.optInt("instantEnergyUsed"))+" بار باقی‌مانده",false);e.setOnClickListener(v->quickBoost("energy"));q.addView(e,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,48)));Button t=Ui.button(activity,"🚀 توربو ۳۰ ثانیه · "+Math.max(0,3-g.optInt("turboUsed"))+" بار باقی‌مانده",false);t.setOnClickListener(v->quickBoost("turbo"));q.addView(t,Ui.lpMatchWrap(activity,8,0));body.addView(q,Ui.lpMatchWrap(activity,0,0));
    }
    private View boostCard(String title,String desc,String type,int level){LinearLayout c=Ui.card(activity);LinearLayout h=Ui.horizontal(activity);LinearLayout info=Ui.vertical(activity);info.addView(Ui.text(activity,title,15,Ui.TEXT,true));info.addView(Ui.text(activity,desc,10,Ui.MUTED,false));h.addView(info,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));TextView lv=Ui.text(activity,"سطح "+level,11,Ui.GOLD2,true);h.addView(lv);c.addView(h);if(level<20){double cost=level-1<boostCosts.length()?boostCosts.optDouble(level-1,0):0;Button b=Ui.button(activity,"ارتقا · "+Ui.faNumber(cost)+" سکه",true);b.setOnClickListener(v->{JSONObject p=new JSONObject();try{p.put("type",type);}catch(Exception ignored){}callGame("boost_upgrade",p,true,null);});c.addView(b,Ui.lpMatchWrap(activity,12,0));}else c.addView(Ui.text(activity,"به حداکثر سطح رسیده است",11,Ui.GREEN,true),Ui.lpMatchWrap(activity,10,0));return c;}

    private View sectionTitle(String title,String sub){LinearLayout v=Ui.vertical(activity);v.addView(Ui.text(activity,title,20,Ui.TEXT,true));v.addView(Ui.text(activity,sub,11,Ui.MUTED,false),Ui.lpMatchWrap(activity,3,0));return v;}

    private void renderMissions(){
        body.removeAllViews();body.addView(sectionTitle("🎁 مأموریت‌ها","کارت‌ها را ارتقا بده و درآمد ساعتی بساز."),Ui.lpMatchWrap(activity,0,8));
        JSONArray cats=missions.optJSONArray("categories");HorizontalScrollView hsv=new HorizontalScrollView(activity);hsv.setHorizontalScrollBarEnabled(false);LinearLayout row=Ui.horizontal(activity);addMissionChip(row,"","همه");if(cats!=null)for(int i=0;i<cats.length();i++){JSONObject c=cats.optJSONObject(i);if(c!=null&&c.optBoolean("active",true))addMissionChip(row,c.optString("id"),c.optString("name"));}hsv.addView(row,new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT));body.addView(hsv,Ui.lpMatchWrap(activity,0,10));
        JSONArray items=missions.optJSONArray("missions");if(items==null||items.length()==0){body.addView(Ui.text(activity,"هنوز مأموریتی منتشر نشده است.",13,Ui.MUTED,false));return;}JSONObject levels=game().optJSONObject("missionLevels");int shown=0;for(int i=0;i<items.length();i++){JSONObject m=items.optJSONObject(i);if(m==null||!m.optBoolean("active",true))continue;if(!missionCategory.isEmpty()&&!missionCategory.equals(m.optString("category")))continue;int level=levels==null?0:levels.optInt(m.optString("id"),0);body.addView(missionCard(m,level),Ui.lpMatchWrap(activity,0,10));shown++;}if(shown==0)body.addView(Ui.text(activity,"در این دسته مأموریتی وجود ندارد.",13,Ui.MUTED,false));
    }
    private void addMissionChip(LinearLayout row,String id,String name){Button b=Ui.button(activity,name,id.equals(missionCategory));b.setTextSize(10);b.setOnClickListener(v->{missionCategory=id;renderMissions();});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,Ui.dp(activity,38));p.setMargins(3,0,3,0);row.addView(b,p);}
    private View missionCard(JSONObject m,int level){LinearLayout c=Ui.card(activity);LinearLayout top=Ui.horizontal(activity);String img=ApiClient.absolute(m.optString("image"));if(!img.isEmpty()){ImageView im=new ImageView(activity);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setBackground(Ui.bg(Ui.PANEL2,14,Color.TRANSPARENT,0,activity));top.addView(im,new LinearLayout.LayoutParams(Ui.dp(activity,72),Ui.dp(activity,72)));images.load(im,img);Ui.gap(top,activity,10);}LinearLayout info=Ui.vertical(activity);info.addView(Ui.text(activity,m.optString("title"),15,Ui.TEXT,true));info.addView(Ui.text(activity,m.optString("description"),10,Ui.MUTED,false),Ui.lpMatchWrap(activity,4,5));info.addView(Ui.text(activity,"سطح "+level+" / "+m.optInt("maxLevel",0),10,Ui.GOLD2,true));top.addView(info,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));c.addView(top);JSONArray lv=m.optJSONArray("levels");if(lv!=null&&level<lv.length()){JSONObject next=lv.optJSONObject(level);double cost=next==null?0:next.optDouble("upgradeCost");double inc=next==null?0:next.optDouble("profitIncrement",next.optDouble("hourlyIncome"));Button b=Ui.button(activity,"ارتقا · "+Ui.faNumber(cost)+" سکه   ·   +"+Ui.faNumber(inc)+"/ساعت",true);b.setOnClickListener(v->{JSONObject p=new JSONObject();try{p.put("missionId",m.optString("id"));}catch(Exception ignored){}callGame("mission_upgrade",p,true,null);});c.addView(b,Ui.lpMatchWrap(activity,12,0));}else c.addView(Ui.text(activity,"حداکثر سطح",11,Ui.GREEN,true),Ui.lpMatchWrap(activity,10,0));return c;}

    private void renderLeague(){
        body.removeAllViews();JSONObject g=game();String code=g.optString("league","Bronze");body.addView(sectionTitle("🏆 لیگ","لیگ فعلی: "+currentCupFa(code)),Ui.lpMatchWrap(activity,0,10));
        LinearLayout cupsRow=Ui.horizontal(activity);for(int i=0;i<cups.length();i++){JSONObject c=cups.optJSONObject(i);if(c==null)continue;boolean active=code.equals(c.optString("name"));TextView t=Ui.text(activity,(active?"● ":"")+c.optString("fa"),10,active?Ui.GOLD2:Ui.MUTED,active);cupsRow.addView(t,Ui.lpWeight(1));}body.addView(cupsRow,Ui.lpMatchWrap(activity,0,12));
        TextView loading=Ui.text(activity,"در حال دریافت رتبه‌بندی...",12,Ui.MUTED,false);body.addView(loading);JSONObject p=new JSONObject();try{p.put("cup",code);}catch(Exception ignored){}api.post("game.php?action=leaderboard",p,token,new ApiClient.Callback(){@Override public void ok(JSONObject json){renderLeaderboard(json);}@Override public void fail(String message){activity.toast(message);}});
    }
    private void renderLeaderboard(JSONObject json){if(!"league".equals(section))return;body.removeAllViews();String code=json.optString("cup",game().optString("league","Bronze"));body.addView(sectionTitle("🏆 لیگ "+currentCupFa(code),"رتبه شما: "+(json.isNull("currentRank")?"در حال محاسبه":json.optInt("currentRank"))+" · اعضای لیگ: "+json.optInt("totalInLeague")),Ui.lpMatchWrap(activity,0,10));JSONArray arr=json.optJSONArray("leaders");if(arr==null||arr.length()==0){body.addView(Ui.text(activity,"هنوز بازیکنی در این لیگ ثبت نشده است.",13,Ui.MUTED,false));return;}for(int i=0;i<arr.length();i++){JSONObject r=arr.optJSONObject(i);if(r==null)continue;LinearLayout c=Ui.card(activity);LinearLayout h=Ui.horizontal(activity);TextView rank=Ui.text(activity,"#"+r.optInt("rank"),13,r.optBoolean("isMe")?Ui.GOLD2:Ui.TEXT,true);TextView name=Ui.text(activity,r.optString("displayName","بازیکن"),13,Ui.TEXT,true);TextView coins=Ui.text(activity,Ui.faNumber(r.optDouble("coins"))+" 🪙",12,Ui.GOLD2,true);h.addView(rank,new LinearLayout.LayoutParams(Ui.dp(activity,46),ViewGroup.LayoutParams.WRAP_CONTENT));h.addView(name,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));h.addView(coins);c.addView(h);body.addView(c,Ui.lpMatchWrap(activity,0,7));}}

    private void renderReferral(){
        body.removeAllViews();body.addView(sectionTitle("👥 زیرمجموعه","دوستانت را دعوت کن و از ثبت‌نام و پیشرفت لیگ آن‌ها پاداش بگیر."),Ui.lpMatchWrap(activity,0,10));
        api.post("game.php?action=referral",new JSONObject(),token,new ApiClient.Callback(){@Override public void ok(JSONObject json){JSONObject r=json.optJSONObject("referral");if(r!=null)renderReferralData(r);}@Override public void fail(String message){activity.toast(message);}});
    }
    private void renderReferralData(JSONObject r){if(!"referral".equals(section))return;body.removeAllViews();body.addView(sectionTitle("👥 زیرمجموعه","پاداش ثبت‌نام هر نفر "+Ui.faNumber(r.optDouble("signupReward",2500))+" سکه"),Ui.lpMatchWrap(activity,0,10));LinearLayout code=Ui.card(activity);TextView c=Ui.text(activity,"کد دعوت: "+r.optString("code","—"),18,Ui.GOLD2,true);c.setGravity(Gravity.CENTER);c.setOnClickListener(v->{ClipboardManager cm=(ClipboardManager)activity.getSystemService(Context.CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("Hamster invite",r.optString("code")));activity.toast("کد دعوت کپی شد");});code.addView(c,Ui.lpMatchWrap(activity,4,6));TextView hint=Ui.text(activity,"برای کپی کردن لمس کن",10,Ui.MUTED,false);hint.setGravity(Gravity.CENTER);code.addView(hint);body.addView(code,Ui.lpMatchWrap(activity,0,10));JSONObject totals=r.optJSONObject("totals");LinearLayout stats=Ui.horizontal(activity);stats.addView(statBox("زیرمجموعه",String.valueOf(r.optInt("invitedCount")),"👥"),Ui.lpWeight(1));Ui.gap(stats,activity,8);stats.addView(statBox("کل پاداش",Ui.faNumber(totals==null?0:totals.optDouble("total")),"🎁"),Ui.lpWeight(1));body.addView(stats,Ui.lpMatchWrap(activity,0,10));JSONArray invited=r.optJSONArray("invited");if(invited!=null&&invited.length()>0){body.addView(Ui.text(activity,"زیرمجموعه‌ها",15,Ui.TEXT,true),Ui.lpMatchWrap(activity,4,8));for(int i=0;i<invited.length();i++){JSONObject x=invited.optJSONObject(i);LinearLayout row=Ui.card(activity);LinearLayout h=Ui.horizontal(activity);h.addView(Ui.text(activity,x.optString("displayName"),12,Ui.TEXT,true),Ui.lpWeight(1));h.addView(Ui.text(activity,x.optString("league"),10,Ui.GOLD2,true));row.addView(h);body.addView(row,Ui.lpMatchWrap(activity,0,6));}}}

    private void renderProfile(){
        body.removeAllViews();JSONObject g=game();LinearLayout card=Ui.card(activity);TextView avatar=Ui.text(activity,"🐹",54,Ui.GOLD,false);avatar.setGravity(Gravity.CENTER);card.addView(avatar);TextView name=Ui.text(activity,user.optString("displayName","بازیکن"),20,Ui.TEXT,true);name.setGravity(Gravity.CENTER);card.addView(name);TextView id=Ui.text(activity,user.optString("userId",""),10,Ui.MUTED,false);id.setGravity(Gravity.CENTER);card.addView(id);card.addView(Ui.text(activity,(isGuest()?"حساب مهمان":"حساب ثبت‌شده")+"   ·   "+currentCupFa(g.optString("league","Bronze")),11,Ui.GOLD2,true),Ui.lpMatchWrap(activity,8,8));body.addView(card,Ui.lpMatchWrap(activity,0,10));
        LinearLayout stats=Ui.horizontal(activity);stats.addView(statBox("سکه",Ui.faNumber(g.optDouble("coins")),"🪙"),Ui.lpWeight(1));Ui.gap(stats,activity,8);stats.addView(statBox("ضربه‌ها",Ui.faNumber(g.optDouble("taps")),"👆"),Ui.lpWeight(1));body.addView(stats,Ui.lpMatchWrap(activity,0,10));
        if(isGuest()){
            Button save=Ui.button(activity,"ثبت حساب و حفظ همین پیشرفت",true);save.setOnClickListener(v->showRegisterDialog());body.addView(save,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,50)));
            Button login=Ui.button(activity,"ورود به حساب قبلی",false);login.setOnClickListener(v->showLoginDialog());body.addView(login,Ui.lpMatchWrap(activity,8,0));
        }else{
            TextView email=Ui.text(activity,"ایمیل: "+user.optString("email"),12,Ui.MUTED,false);body.addView(email,Ui.lpMatchWrap(activity,4,10));Button rename=Ui.button(activity,"ویرایش نام کاربری",false);rename.setOnClickListener(v->showRenameDialog());body.addView(rename,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,48)));Button logout=Ui.button(activity,"خروج از حساب",false);logout.setOnClickListener(v->logout());body.addView(logout,Ui.lpMatchWrap(activity,8,0));
        }
    }

    private EditText input(String hint,boolean password){EditText e=new EditText(activity);e.setHint(hint);e.setHintTextColor(Color.rgb(115,120,130));e.setTextColor(Color.rgb(30,30,35));e.setTextSize(14);e.setSingleLine(true);if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);e.setPadding(Ui.dp(activity,12),0,Ui.dp(activity,12),0);e.setBackground(Ui.bg(Color.rgb(245,246,249),12,Color.rgb(220,222,228),1,activity));return e;}
    private void showRegisterDialog(){LinearLayout f=Ui.vertical(activity);f.setPadding(Ui.dp(activity,20),5,Ui.dp(activity,20),5);EditText name=input("نام کاربری",false),email=input("ایمیل",false),pass=input("رمز عبور (حداقل ۸ کاراکتر)",true),confirm=input("تکرار رمز",true),invite=input("کد دعوت (اختیاری)",false);for(EditText e:new EditText[]{name,email,pass,confirm,invite})f.addView(e,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,48)));AlertDialog d=new AlertDialog.Builder(activity).setTitle("ثبت حساب و حفظ پیشرفت").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ثبت حساب",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{JSONObject b=new JSONObject();try{b.put("displayName",name.getText().toString().trim());b.put("email",email.getText().toString().trim());b.put("password",pass.getText().toString());b.put("confirmPassword",confirm.getText().toString());b.put("inviteCode",invite.getText().toString().trim());}catch(Exception ignored){}api.post("auth.php?action=convert_guest",b,token,new ApiClient.Callback(){@Override public void ok(JSONObject j){applyAuthResponse(j);d.dismiss();activity.toast("حساب با حفظ پیشرفت ثبت شد");}@Override public void fail(String m){activity.toast(m);}});}));d.show();}
    private void showLoginDialog(){LinearLayout f=Ui.vertical(activity);f.setPadding(Ui.dp(activity,20),5,Ui.dp(activity,20),5);EditText email=input("ایمیل حساب قبلی",false),pass=input("رمز عبور",true);f.addView(email,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,50)));f.addView(pass,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,50)));Button forgot=Ui.button(activity,"فراموشی رمز عبور",false);f.addView(forgot,Ui.lpMatchWrap(activity,8,0));AlertDialog d=new AlertDialog.Builder(activity).setTitle("ورود به حساب قبلی").setMessage("با ورود، حساب مهمان فعلی جایگزین حساب قبلی می‌شود.").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ورود",null).create();forgot.setOnClickListener(v->showForgotDialog(email.getText().toString().trim()));d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{JSONObject b=new JSONObject();try{b.put("email",email.getText().toString().trim());b.put("password",pass.getText().toString());}catch(Exception ignored){}api.post("auth.php?action=login_guest",b,token,new ApiClient.Callback(){@Override public void ok(JSONObject j){applyAuthResponse(j);d.dismiss();activity.toast("حساب قبلی بازیابی شد");}@Override public void fail(String m){activity.toast(m);}});}));d.show();}
    private void showForgotDialog(String initial){LinearLayout f=Ui.vertical(activity);f.setPadding(Ui.dp(activity,20),5,Ui.dp(activity,20),5);EditText email=input("ایمیل",false);email.setText(initial);f.addView(email,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,50)));AlertDialog d=new AlertDialog.Builder(activity).setTitle("بازیابی رمز").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ارسال کد",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{JSONObject b=new JSONObject();try{b.put("email",email.getText().toString().trim());}catch(Exception ignored){}api.post("auth.php?action=forgot",b,token,new ApiClient.Callback(){@Override public void ok(JSONObject j){d.dismiss();showResetDialog(email.getText().toString().trim());activity.toast("در صورت ثبت بودن ایمیل، کد ارسال شد");}@Override public void fail(String m){activity.toast(m);}});}));d.show();}
    private void showResetDialog(String email){LinearLayout f=Ui.vertical(activity);f.setPadding(Ui.dp(activity,20),5,Ui.dp(activity,20),5);EditText code=input("کد ۶ رقمی",false),pass=input("رمز جدید",true),confirm=input("تکرار رمز جدید",true);f.addView(code,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,50)));f.addView(pass,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,50)));f.addView(confirm,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,50)));AlertDialog d=new AlertDialog.Builder(activity).setTitle("رمز جدید").setView(f).setNegativeButton("انصراف",null).setPositiveButton("تغییر رمز",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{JSONObject b=new JSONObject();try{b.put("email",email);b.put("code",code.getText().toString().trim());b.put("password",pass.getText().toString());b.put("confirmPassword",confirm.getText().toString());}catch(Exception ignored){}api.post("auth.php?action=reset",b,token,new ApiClient.Callback(){@Override public void ok(JSONObject j){d.dismiss();activity.toast("رمز عبور تغییر کرد");}@Override public void fail(String m){activity.toast(m);}});}));d.show();}
    private void showRenameDialog(){EditText e=input("نام کاربری",false);e.setText(user.optString("displayName"));LinearLayout f=Ui.vertical(activity);f.setPadding(Ui.dp(activity,20),5,Ui.dp(activity,20),5);f.addView(e,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,Ui.dp(activity,50)));AlertDialog d=new AlertDialog.Builder(activity).setTitle("ویرایش نام کاربری").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{JSONObject b=new JSONObject();try{b.put("displayName",e.getText().toString().trim());}catch(Exception ignored){}api.post("auth.php?action=profile_update",b,token,new ApiClient.Callback(){@Override public void ok(JSONObject j){JSONObject u=j.optJSONObject("user");if(u!=null)user=u;d.dismiss();renderProfile();activity.toast("نام ذخیره شد");}@Override public void fail(String m){activity.toast(m);}});}));d.show();}
    private void logout(){new AlertDialog.Builder(activity).setTitle("خروج از حساب").setMessage("از حساب ثبت‌شده خارج می‌شوی و یک حساب مهمان جدید ساخته می‌شود.").setNegativeButton("انصراف",null).setPositiveButton("خروج",(d,w)->api.post("auth.php?action=logout",new JSONObject(),token,new ApiClient.Callback(){@Override public void ok(JSONObject j){token="";prefs.edit().remove("session_token").apply();user=new JSONObject();missions=new JSONObject();showLoading("در حال ساخت حساب مهمان...");ensureSession();}@Override public void fail(String m){activity.toast(m);}})).show();}
}
