package com.maniplus.notcoin;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private final ApiClient api = new ApiClient();
    private final ImageLoader images = new ImageLoader();
    private SharedPreferences prefs;
    private FrameLayout content;
    private Button tutorialsTab, gameTab;
    private JSONObject appConfig = new JSONObject();
    private TutorialsController tutorials;
    private GameController game;
    private String activeTab = "tutorials";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("hamster_native", Context.MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Ui.BG);
            getWindow().setNavigationBarColor(Ui.BG);
        }
        buildShell();
        loadCachedConfig();
        String initial = appConfig.optString("defaultTab", "tutorials");
        showTab(initial, false);
        refreshConfig(true);
    }

    private void buildShell() {
        LinearLayout root = Ui.vertical(this);
        root.setBackgroundColor(Ui.BG);
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout nav = Ui.horizontal(this);
        nav.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 10));
        nav.setBackgroundColor(Color.rgb(10, 16, 28));
        tutorialsTab = Ui.button(this, "📚  آموزش", false);
        gameTab = Ui.button(this, "🐹  بازی همستر", false);
        tutorialsTab.setOnClickListener(v -> showTab("tutorials", true));
        gameTab.setOnClickListener(v -> showTab("game", true));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, Ui.dp(this, 52), 1f);
        p.setMargins(Ui.dp(this, 5), 0, Ui.dp(this, 5), 0);
        nav.addView(tutorialsTab, p);
        nav.addView(gameTab, p);
        root.addView(nav, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
    }

    private void loadCachedConfig() {
        try {
            String raw = prefs.getString("app_config", "");
            if (raw != null && !raw.isEmpty()) appConfig = new JSONObject(raw);
        } catch (Exception ignored) { }
        if (!appConfig.has("defaultTab")) {
            try {
                appConfig.put("defaultTab", "tutorials");
                appConfig.put("gameStatus", "active");
                appConfig.put("comingSoonTitle", "بازی همستر به‌زودی");
                appConfig.put("comingSoonText", "این بخش به‌زودی فعال می‌شود.");
            } catch (Exception ignored) { }
        }
    }

    private void refreshConfig(boolean applyDefaultIfFresh) {
        api.post("app.php?action=config", new JSONObject(), null, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) {
                JSONObject cfg = json.optJSONObject("config");
                if (cfg == null) return;
                boolean changed = !cfg.toString().equals(appConfig.toString());
                appConfig = cfg;
                prefs.edit().putString("app_config", cfg.toString()).apply();
                if (applyDefaultIfFresh && !prefs.getBoolean("default_tab_applied_v9", false)) {
                    prefs.edit().putBoolean("default_tab_applied_v9", true).apply();
                    showTab(cfg.optString("defaultTab", "tutorials"), false);
                } else if (changed && "game".equals(activeTab)) {
                    showTab("game", false);
                }
            }
            @Override public void fail(String message) { /* cached config keeps app usable */ }
        });
    }

    public void showTab(String tab, boolean userAction) {
        activeTab = "game".equals(tab) ? "game" : "tutorials";
        content.removeAllViews();
        boolean tutActive = "tutorials".equals(activeTab);
        styleMainTab(tutorialsTab, tutActive);
        styleMainTab(gameTab, !tutActive);
        if (tutActive) {
            if (game != null) game.pause();
            if (tutorials == null) tutorials = new TutorialsController(this, api, images);
            content.addView(tutorials.view(), new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            tutorials.refreshIfNeeded();
        } else {
            if (!"active".equals(appConfig.optString("gameStatus", "active"))) {
                content.addView(comingSoonView(), new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                return;
            }
            if (game == null) game = new GameController(this, api, images, prefs);
            content.addView(game.view(), new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            game.resume();
        }
    }

    private void styleMainTab(Button b, boolean active) {
        b.setTextColor(active ? Color.rgb(40,25,0) : Ui.TEXT);
        b.setBackground(Ui.bg(active ? Ui.GOLD2 : Ui.PANEL2, 15, active ? Ui.GOLD : Color.argb(40,255,255,255), 1, this));
    }

    private View comingSoonView() {
        LinearLayout wrap = Ui.vertical(this);
        wrap.setGravity(Gravity.CENTER);
        wrap.setPadding(Ui.dp(this, 28), Ui.dp(this, 28), Ui.dp(this, 28), Ui.dp(this, 28));
        TextView icon = Ui.text(this, "🐹", 72, Ui.GOLD, false); icon.setGravity(Gravity.CENTER);
        TextView title = Ui.text(this, appConfig.optString("comingSoonTitle", "بازی همستر به‌زودی"), 24, Ui.TEXT, true); title.setGravity(Gravity.CENTER);
        TextView body = Ui.text(this, appConfig.optString("comingSoonText", "این بخش به‌زودی فعال می‌شود."), 15, Ui.MUTED, false); body.setGravity(Gravity.CENTER);
        wrap.addView(icon, Ui.lpMatchWrap(this, 0, 12)); wrap.addView(title, Ui.lpMatchWrap(this, 0, 12)); wrap.addView(body, Ui.lpMatchWrap(this, 0, 0));
        return wrap;
    }

    public void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    @Override protected void onResume() {
        super.onResume();
        refreshConfig(false);
        if (game != null && "game".equals(activeTab)) game.resume();
    }

    @Override protected void onPause() {
        if (game != null) game.pause();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (game != null) game.destroy();
        super.onDestroy();
    }
}
