# Hamster Education Android v3.3.1 (10) — v40 source

Native Android client for `com.maniplus.notcoin`.

Current release focus:
- Splash is exactly 2.5 seconds and uses the supplied `splash_screen.webp` artwork.
- Splash shows a real indeterminate Android `ProgressBar` at the bottom; it is not baked into the image.
- Home slider is online-only: slider metadata/images/ads are never loaded from cache and the whole slider area is absent offline.
- Home slider remains full-snap, circular/infinite, and keeps the active capsule indicator.
- All Adivery banner placements remain `BannerSize.LARGE_BANNER` (the project-approved middle banner option, 320x100).
- Adivery slider ads still load fresh only while the user is actually on the ad slide and are released on exit.
- Category cards in «همه دسته‌بندی‌ها» use one fixed height so every card is equal-sized.
- Firebase Cloud Messaging is enabled with the supplied Firebase Android config for package `com.maniplus.notcoin`.
- Android uses `firebase-messaging:24.1.2` to retain project `minSdk 21` compatibility.
- Each app instance subscribes to topic `hamster_all` and registers its FCM token with the backend.
- Foreground/background data notifications are rendered by `HamsterMessagingService`; optional image and optional HTTP(S) destination link are supported.
- Android 13+ notification permission is requested after the 2.5-second splash finishes.
- Confirmed exit still moves the app task to the background and keeps its card in Recent Apps.

Build identity:
- applicationId: `com.maniplus.notcoin`
- versionName: `3.3.1`
- versionCode: `10`
- compileSdk / targetSdk: `36`
- minSdk: `21`
- Java: `17`

Adivery placements:
- App ID: `1ed3d9f1-ccaf-40a7-808f-aaee6ccd422f`
- Banner Zone ID: `4fb16d31-bfcd-4c85-9a0f-f787d8fc34f4`
- Interstitial Zone ID: `d027cb9f-ad5b-410e-a716-287fd8ec61e1`

Push analytics (v40):
- Every push is assigned a unique notification ID and tracking token by the backend.
- A real view is counted only after Android actually posts the notification to NotificationManager.
- A click is counted when the user taps that exact notification.
- View/click counts are deduplicated per app device and notification; a click also guarantees at least one view for that device.
- The admin panel shows per-notification target count at send time, views, clicks, CTR, send status, date, image and destination.

Security:
- `google-services.json` is bundled in the Android source as required by Firebase Android setup.
- The Firebase Admin service-account private key is NOT present anywhere in this Android/GitHub source ZIP; it exists only in the host/backend package.

The GitHub Actions workflow is intentionally unchanged from the verified v3.3.1/vc10 workflow.
