package com.maniplus.notcoin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final long SPLASH_DURATION_MS = 2500L;
    private static final long INTERSTITIAL_DELAY_MS = 10_000L;

    private final ApiClient api = new ApiClient();
    private ImageLoader images;
    private UsageTracker usage;
    private TutorialsController controller;
    private FrameLayout splash;
    private boolean exitDialogVisible;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private long appStartedAt;
    private boolean interstitialEnabled;
    private boolean adConfigResolved;
    private int interstitialLoadRetries;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        styleSystemBars();
        appStartedAt = SystemClock.elapsedRealtime();
        images = new ImageLoader(this);
        usage = new UsageTracker(this, api);
        HamsterMessagingService.initialize(this);
        configureAds();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        applySafeInsets(root);

        // Splash is deliberately time-bound. Network/cache state must never keep the user here.
        splash = buildSplash();

        controller = new TutorialsController(this, api, images, usage.deviceId(), () -> { });
        root.addView(controller.view(), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(splash, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        mainHandler.post(() -> handleNotificationIntent(getIntent()));

        mainHandler.postDelayed(this::hideSplash, SPLASH_DURATION_MS);
    }


    private void configureAds() {
        android.content.SharedPreferences p = getSharedPreferences("hamster_education_v35", MODE_PRIVATE);
        interstitialEnabled = p.getBoolean("adivery_interstitial_enabled", true);
        AdiveryManager.initialize(this);
        AdiveryManager.prepareInterstitial(this);

        api.post("app.php?action=config", new JSONObject(), null, new ApiClient.Callback() {
            @Override public void ok(JSONObject j) {
                JSONObject cfg = j.optJSONObject("config");
                JSONObject ad = cfg == null ? null : cfg.optJSONObject("adivery");
                if (ad != null) {
                    interstitialEnabled = ad.optBoolean("interstitialEnabled", interstitialEnabled);
                    p.edit().putBoolean("adivery_interstitial_enabled", interstitialEnabled).apply();
                }
                adConfigResolved = true;
            }

            @Override public void fail(String message) {
                adConfigResolved = true;
            }
        });

        mainHandler.postDelayed(this::showStartupInterstitialIfAllowed, INTERSTITIAL_DELAY_MS);
    }

    private void showStartupInterstitialIfAllowed() {
        if (isFinishing() || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
        // Give the launch config request a very short grace period so a panel-side OFF switch wins.
        if (!adConfigResolved && SystemClock.elapsedRealtime() - appStartedAt < 12_000L) {
            mainHandler.postDelayed(this::showStartupInterstitialIfAllowed, 250L);
            return;
        }
        if (!interstitialEnabled) return;
        if (!AdiveryManager.tryShowInterstitialOnce(this) && interstitialLoadRetries < 5) {
            interstitialLoadRetries++;
            mainHandler.postDelayed(this::showStartupInterstitialIfAllowed, 1_000L);
        }
    }

    private FrameLayout buildSplash() {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(Color.WHITE);

        ImageView artwork = new ImageView(this);
        artwork.setImageResource(R.drawable.splash_screen);
        artwork.setScaleType(ImageView.ScaleType.FIT_CENTER);
        artwork.setAdjustViewBounds(false);
        f.addView(artwork, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Real indeterminate app loading indicator. It is a View, not part of the supplied splash artwork.
        ProgressBar loading = new ProgressBar(this);
        loading.setIndeterminate(true);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Ui.dp(this, 38), Ui.dp(this, 38));
        lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        lp.bottomMargin = Ui.dp(this, 42);
        f.addView(loading, lp);
        return f;
    }

    private void hideSplash() {
        if (splash == null || splash.getVisibility() != View.VISIBLE) return;
        splash.animate().alpha(0f).setDuration(160).withEndAction(() -> {
            splash.setVisibility(View.GONE);
            splash.setClickable(false);
            requestNotificationPermissionIfNeeded();
        }).start();
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 3901);
        }
    }

    private void handleNotificationIntent(Intent intent) {
        if (intent == null) return;
        String url = intent.getStringExtra(HamsterMessagingService.EXTRA_TARGET_URL);
        String notificationId = intent.getStringExtra(HamsterMessagingService.EXTRA_NOTIFICATION_ID);
        String trackingToken = intent.getStringExtra(HamsterMessagingService.EXTRA_TRACKING_TOKEN);
        intent.removeExtra(HamsterMessagingService.EXTRA_TARGET_URL);
        intent.removeExtra(HamsterMessagingService.EXTRA_NOTIFICATION_ID);
        intent.removeExtra(HamsterMessagingService.EXTRA_TRACKING_TOKEN);

        if (notificationId != null && !notificationId.trim().isEmpty()
                && trackingToken != null && !trackingToken.trim().isEmpty()) {
            HamsterMessagingService.reportEvent(getApplicationContext(), notificationId, trackingToken, "click");
        }

        if (url == null) return;
        String v = url.trim();
        if (!(v.startsWith("https://") || v.startsWith("http://"))) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(v)));
        } catch (Exception ignored) { }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleNotificationIntent(intent);
    }

    private void applySafeInsets(View root) {
        if (Build.VERSION.SDK_INT >= 20) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top;
                int bottom;
                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                    top = bars.top;
                    bottom = bars.bottom;
                } else {
                    top = insets.getSystemWindowInsetTop();
                    bottom = insets.getSystemWindowInsetBottom();
                }
                v.setPadding(0, top, 0, bottom);
                return insets;
            });
            root.requestApplyInsets();
        }
    }

    private void styleSystemBars() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 21) {
            w.setStatusBarColor(Color.WHITE);
            w.setNavigationBarColor(Color.WHITE);
        }
        if (Build.VERSION.SDK_INT >= 23) {
            int flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            w.getDecorView().setSystemUiVisibility(flags);
        }
    }

    public void toast(String s) {
        android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show();
    }

    @Override public void onBackPressed() {
        if (controller != null && controller.goBack()) return;
        showExitDialog();
    }

    private void showExitDialog() {
        if (exitDialogVisible || isFinishing()) return;
        exitDialogVisible = true;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("خروج از برنامه")
                .setMessage("آیا می‌خواهید از برنامه خارج شوید؟")
                .setNegativeButton("انصراف", (d, which) -> d.dismiss())
                .setPositiveButton("خروج", (d, which) -> leaveAppKeepingRecentTask())
                .create();
        dialog.setOnDismissListener(d -> exitDialogVisible = false);
        dialog.show();
    }

    private void leaveAppKeepingRecentTask() {
        // User-confirmed exit should leave the task in Recent Apps instead of deleting it.
        // Moving the task to the background gives the expected Home/Recent behavior without killing the process.
        boolean moved = moveTaskToBack(true);
        if (!moved) {
            android.content.Intent home = new android.content.Intent(android.content.Intent.ACTION_MAIN);
            home.addCategory(android.content.Intent.CATEGORY_HOME);
            home.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(home);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (usage != null) usage.start();
        if (controller != null) controller.refreshIfNeeded();
    }

    @Override protected void onPause() {
        if (usage != null) usage.stop();
        super.onPause();
    }
}
