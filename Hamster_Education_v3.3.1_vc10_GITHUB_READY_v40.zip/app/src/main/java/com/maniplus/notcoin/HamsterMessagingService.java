package com.maniplus.notcoin;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.UUID;

public final class HamsterMessagingService extends FirebaseMessagingService {
    public static final String TOPIC_ALL = "hamster_all";
    public static final String EXTRA_TARGET_URL = "hamster_notification_url";
    public static final String EXTRA_NOTIFICATION_ID = "hamster_notification_id";
    public static final String EXTRA_TRACKING_TOKEN = "hamster_notification_tracking";
    private static final String CHANNEL_ID = "hamster_updates";
    private static final int NOTIFICATION_ID_BASE = 7300;

    @Override public void onNewToken(String token) {
        super.onNewToken(token);
        FirebaseMessaging.getInstance().subscribeToTopic(TOPIC_ALL);
        registerToken(getApplicationContext(), token);
    }

    @Override public void onMessageReceived(RemoteMessage message) {
        super.onMessageReceived(message);
        Map<String, String> data = message.getData();
        String title = clean(data.get("title"));
        String body = clean(data.get("body"));
        String imageUrl = clean(data.get("image"));
        String targetUrl = clean(data.get("url"));
        String notificationId = clean(data.get("notificationId"));
        String trackingToken = clean(data.get("trackingToken"));

        RemoteMessage.Notification n = message.getNotification();
        if (title.isEmpty() && n != null) title = clean(n.getTitle());
        if (body.isEmpty() && n != null) body = clean(n.getBody());
        if (imageUrl.isEmpty() && n != null && n.getImageUrl() != null) imageUrl = n.getImageUrl().toString();
        if (title.isEmpty()) title = getString(R.string.app_name);
        if (body.isEmpty()) return;

        showNotification(title, body, imageUrl, targetUrl, notificationId, trackingToken);
    }

    public static void initialize(Context context) {
        FirebaseMessaging messaging = FirebaseMessaging.getInstance();
        messaging.subscribeToTopic(TOPIC_ALL);
        messaging.getToken().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null && !task.getResult().trim().isEmpty()) {
                registerToken(context.getApplicationContext(), task.getResult());
            }
        });
    }

    private static String deviceId(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("hamster_education_device", Context.MODE_PRIVATE);
        String id = prefs.getString("device_id", "");
        if (id == null || id.trim().isEmpty()) {
            id = UUID.randomUUID().toString();
            prefs.edit().putString("device_id", id).apply();
        }
        return id;
    }

    private static void registerToken(Context context, String token) {
        if (token == null || token.trim().isEmpty()) return;
        JSONObject b = new JSONObject();
        try {
            b.put("token", token.trim());
            b.put("deviceId", deviceId(context));
            b.put("appVersion", BuildConfig.VERSION_NAME);
            b.put("versionCode", BuildConfig.VERSION_CODE);
        } catch (Exception ignored) { }
        new ApiClient().post("app.php?action=fcm_register", b, null, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) { }
            @Override public void fail(String message) { }
        });
    }

    public static void reportEvent(Context context, String notificationId, String trackingToken, String event) {
        String id = clean(notificationId);
        String tracker = clean(trackingToken);
        if (id.isEmpty() || tracker.isEmpty() || !("view".equals(event) || "click".equals(event))) return;
        JSONObject b = new JSONObject();
        try {
            b.put("id", id);
            b.put("trackingToken", tracker);
            b.put("event", event);
            b.put("deviceId", deviceId(context.getApplicationContext()));
        } catch (Exception ignored) { return; }
        new ApiClient().post("app.php?action=push_event", b, null, new ApiClient.Callback() {
            @Override public void ok(JSONObject json) { }
            @Override public void fail(String message) { }
        });
    }

    private void showNotification(String title, String body, String imageUrl, String targetUrl, String notificationId, String trackingToken) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "اعلان‌های آموزش همستر", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("اعلان‌های ارسالی از پنل مدیریت آموزش همستر");
            nm.createNotificationChannel(channel);
        }

        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        open.putExtra(EXTRA_TARGET_URL, targetUrl == null ? "" : targetUrl);
        open.putExtra(EXTRA_NOTIFICATION_ID, notificationId == null ? "" : notificationId);
        open.putExtra(EXTRA_TRACKING_TOKEN, trackingToken == null ? "" : trackingToken);

        int requestCode;
        if (notificationId != null && !notificationId.trim().isEmpty()) {
            requestCode = notificationId.hashCode() & 0x7fffffff;
        } else {
            requestCode = (int) (System.currentTimeMillis() & 0x7fffffff);
        }
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(this, requestCode, open, flags);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(body)
                .setContentIntent(pending)
                .setAutoCancel(true)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true);
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH);

        Bitmap picture = downloadBitmap(imageUrl);
        if (picture != null) {
            b.setLargeIcon(picture);
            Notification.BigPictureStyle style = new Notification.BigPictureStyle();
            style.bigPicture(picture);
            style.setBigContentTitle(title);
            style.setSummaryText(body);
            b.setStyle(style);
        } else {
            b.setStyle(new Notification.BigTextStyle().bigText(body));
        }

        int systemId = notificationId != null && !notificationId.trim().isEmpty()
                ? NOTIFICATION_ID_BASE + ((notificationId.hashCode() & 0x7fffffff) % 100000)
                : NOTIFICATION_ID_BASE + (requestCode % 100000);
        nm.notify(systemId, b.build());
        reportEvent(getApplicationContext(), notificationId, trackingToken, "view");
    }

    private static Bitmap downloadBitmap(String raw) {
        if (!isHttpUrl(raw)) return null;
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(raw).openConnection();
            c.setConnectTimeout(5000);
            c.setReadTimeout(7000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "HamsterEducation/3.3.1 Android");
            int status = c.getResponseCode();
            if (status < 200 || status >= 300) return null;
            try (InputStream in = c.getInputStream()) {
                return BitmapFactory.decodeStream(in);
            }
        } catch (Exception ignored) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static String clean(String s) { return s == null ? "" : s.trim(); }
    private static boolean isHttpUrl(String s) {
        if (s == null) return false;
        String v = s.trim().toLowerCase(java.util.Locale.US);
        return v.startsWith("https://") || v.startsWith("http://");
    }
}
