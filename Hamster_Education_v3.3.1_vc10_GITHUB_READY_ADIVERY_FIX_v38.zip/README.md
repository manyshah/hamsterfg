# Hamster Education Android v3.3.1 (10)

Native Android client for `com.maniplus.notcoin`.

Current release focus:
- Splash is time-bound at 2.5 seconds; network/cache never blocks it.
- Adivery Android SDK 4.9.0 integration.
- Home slider accepts unlimited mixed slides: normal image slides or Adivery medium banners.
- Slider navigation is full-snap and circular: every swipe lands on one complete slide; last→first and first→last both work.
- The active slider indicator is a small horizontal capsule; inactive indicators remain dots.
- Every Adivery banner placement uses `BannerSize.LARGE_BANNER` (the middle fixed banner option, 320x100).
- Slider Adivery views are not preloaded or cached: a fresh banner is created only when the user enters that slide, released when leaving it, and requested again on re-entry.
- Each slide supports an independent `displaySeconds` value from admin; `0` keeps manual-only navigation.
- Adivery slider impressions/clicks are reported to backend per slide.
- Adivery medium banner is shown under the cover image on tutorial/news detail pages when an ad is available.
- Pull-to-refresh observes gestures across the full scrollable content surface, including cards/images/text.
- Offline cache entry is silent; the extra splash/offline status text is not shown.
- One startup interstitial is prepared at launch and attempted once per app process after ~10 seconds when enabled by backend/admin.
- System Back is the only internal back navigation; no extra header back arrow is introduced.
- Back on Favorites/News root returns Home; Back on Home shows exit confirmation.
- Confirmed exit moves the app task to the background and keeps its card in Recent Apps; the task/process is not explicitly removed or killed.
- Category images are category-only; tutorial/news covers remain independent.

Build identity:
- applicationId: `com.maniplus.notcoin`
- versionName: `3.3.1`
- versionCode: `10`
- compileSdk / targetSdk: `36`
- minSdk: `21`
- Java: `17`

Adivery placements:
- App ID: `1ed3d9f1-ccaf-40a7-808f-aaee6ccd422f`
- Banner Zone ID: `4fb16d31-bfcd-4c85-9a0f-f787d8fc34f4`
- Interstitial Zone ID: `d027cb9f-ad5b-410e-a716-287fd8ec61e1`

The GitHub Actions workflow is intentionally unchanged from the verified v3.3.1/vc10 workflow.
