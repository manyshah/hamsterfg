<?php
require __DIR__ . '/_lib.php';
ensure_storage();
out([
    'ok'=>true,
    'service'=>'hamster-web-api',
    'version'=>'30.0.0',
    'php'=>PHP_VERSION,
    'dataWritable'=>is_writable(DATA_DIR),
    'missionUploadWritable'=>is_writable(UPLOAD_DIR),
    'time'=>now_iso(),
]);
