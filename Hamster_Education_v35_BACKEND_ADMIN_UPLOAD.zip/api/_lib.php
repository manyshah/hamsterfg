<?php
declare(strict_types=1);

if (!defined('API_NO_DEFAULT_HEADERS')) {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-CSRF-Token');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') { http_response_code(204); exit; }
}

const DATA_DIR = __DIR__ . '/data';
const UPLOAD_DIR = __DIR__ . '/../uploads/missions';
const DEFAULT_ADMIN_USERNAME = 'admin';
const DEFAULT_ADMIN_PASSWORD_HASH = '$2y$12$lV83CrQR5mw4lPOctEL45OtM9rXwNVU8pnzvwWahABDE4Doi.8z6e';
const MAX_OFFLINE_SECONDS = 31536000;
const ONLINE_WINDOW_SECONDS = 120;
const USER_SESSION_TTL_SECONDS = 31536000; // 365 days
const SESSION_COOKIE_NAME = 'hamster_session_token';
const LEGACY_TOKEN_COOKIE_NAME = 'hamster_hamsterToken';

function request_is_https(): bool {
    $https = strtolower((string)($_SERVER['HTTPS'] ?? ''));
    if ($https !== '' && $https !== 'off' && $https !== '0') return true;
    return strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
}
function session_cookie_domain(): string {
    $host = strtolower(preg_replace('/:\\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')) ?? '');
    return ($host === 'persian-melody.ir' || ($host !== '' && substr($host, -strlen('.persian-melody.ir')) === '.persian-melody.ir')) ? '.persian-melody.ir' : '';
}
function write_session_cookie(string $name, string $value, int $expires, bool $httpOnly): void {
    $options = [
        'expires' => $expires,
        'path' => '/',
        'secure' => request_is_https(),
        'httponly' => $httpOnly,
        'samesite' => 'Lax',
    ];
    $domain = session_cookie_domain();
    if ($domain !== '') $options['domain'] = $domain;
    setcookie($name, $value, $options);
    if ($expires > time()) $_COOKIE[$name] = $value; else unset($_COOKIE[$name]);
}
function persist_session_cookie(string $token): void {
    $token = strtolower(trim($token));
    if (!preg_match('/^[a-f0-9]{64}$/', $token)) return;
    $expires = time() + USER_SESSION_TTL_SECONDS;
    // HttpOnly cookie is the authoritative server-side recovery channel.
    write_session_cookie(SESSION_COOKIE_NAME, $token, $expires, true);
    // Readable fallback keeps the existing SafeStore implementation compatible.
    write_session_cookie(LEGACY_TOKEN_COOKIE_NAME, $token, $expires, false);
}
function clear_session_cookie(): void {
    write_session_cookie(SESSION_COOKIE_NAME, '', time() - 3600, true);
    write_session_cookie(LEGACY_TOKEN_COOKIE_NAME, '', time() - 3600, false);
    // Also clear possible host-only cookies created by older JavaScript versions.
    foreach ([SESSION_COOKIE_NAME, LEGACY_TOKEN_COOKIE_NAME] as $name) {
        setcookie($name, '', ['expires'=>time()-3600,'path'=>'/','secure'=>request_is_https(),'httponly'=>$name===SESSION_COOKIE_NAME,'samesite'=>'Lax']);
    }
}
function ensure_storage(): void {
    if (!is_dir(DATA_DIR)) @mkdir(DATA_DIR, 0755, true);
    if (!is_dir(UPLOAD_DIR)) @mkdir(UPLOAD_DIR, 0755, true);
}
function json_input(): array {
    $raw = file_get_contents('php://input') ?: '';
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}
function out(array $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function now_iso(): string { return gmdate('c'); }
function tehran_date(string $format = 'Y-m-d', ?int $timestamp = null): string {
    $dt = new DateTimeImmutable('@' . ($timestamp ?? time()));
    return $dt->setTimezone(new DateTimeZone('Asia/Tehran'))->format($format);
}
function clean_email(string $email): string { return strtolower(trim($email)); }
function valid_email(string $email): bool { return (bool) filter_var($email, FILTER_VALIDATE_EMAIL); }
function is_guest_email(string $email): bool { return (bool) preg_match('/^guest_[a-f0-9]{24}@guest\.hamster\.local$/', clean_email($email)); }
function is_guest_user(array $user): bool { return !empty($user['isGuest']) || is_guest_email((string)($user['email'] ?? '')); }
function guest_display_name(): string {
    for ($i=0; $i<40; $i++) {
        $name = 'Ghost' . (string) random_int(100000, 999999);
        $exists = false;
        foreach (all_users() as $u) {
            if (strcasecmp((string)($u['displayName'] ?? $u['username'] ?? ''), $name) === 0) { $exists = true; break; }
        }
        if (!$exists) return $name;
    }
    return 'Ghost' . (string) time();
}
function guest_internal_email(): string {
    do { $email = 'guest_' . bin2hex(random_bytes(12)) . '@guest.hamster.local'; }
    while (is_file(user_file($email)));
    return $email;
}
function update_token_email(string $token, string $email): void {
    if ($token === '') return;
    $file = token_file($token);
    $row = read_json_file($file) ?? [];
    $row['email'] = clean_email($email);
    $row['lastRefreshAt'] = time();
    $row['expiresAt'] = time() + USER_SESSION_TTL_SECONDS;
    if (empty($row['createdAt'])) $row['createdAt'] = time();
    write_json_file($file, $row);
}
function delete_tokens_for_email(string $email): void {
    $email = clean_email($email);
    if ($email === '') return;
    ensure_storage();
    foreach (glob(DATA_DIR . '/token_*.json') ?: [] as $file) {
        $row = read_json_file($file);
        if ($row && clean_email((string)($row['email'] ?? '')) === $email) @unlink($file);
    }
}
function delete_guest_user(array $user): void {
    if (!is_guest_user($user)) return;
    $email = clean_email((string)($user['email'] ?? ''));
    if ($email === '') return;
    @unlink(user_file($email));
    @unlink(referral_rewards_file($email));
    @unlink(admin_coin_history_file($email));
}
function clean_username(string $username): string { return strtolower(trim($username)); }
function valid_username(string $username): bool { return (bool) preg_match('/^[a-z0-9][a-z0-9._-]{1,22}[a-z0-9]$/', $username); }
function u_strlen(string $value): int {
    if (function_exists('mb_strlen')) return mb_strlen($value, 'UTF-8');
    preg_match_all('/./us', $value, $matches);
    return count($matches[0] ?? []);
}
function u_substr(string $value, int $start, int $length): string {
    if (function_exists('mb_substr')) return mb_substr($value, $start, $length, 'UTF-8');
    preg_match_all('/./us', $value, $matches);
    return implode('', array_slice($matches[0] ?? [], $start, $length));
}
function clean_display_name(string $name): string {
    $name = preg_replace('/\s+/u', ' ', trim($name)) ?? '';
    return u_substr($name, 0, 30);
}
function valid_display_name(string $name): bool {
    $len = u_strlen($name);
    return $len >= 2 && $len <= 30 && !preg_match('/[<>]/u', $name);
}
function clean_text(string $value, int $max = 120): string {
    $value = preg_replace('/\s+/u', ' ', trim($value)) ?? '';
    return u_substr(strip_tags($value), 0, $max);
}
function safe_id(string $value): string {
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9_-]+/', '-', $value) ?? '';
    return trim(substr($value, 0, 60), '-_');
}
function user_file(string $email): string { ensure_storage(); return DATA_DIR . '/user_' . sha1(clean_email($email)) . '.json'; }
function token_file(string $token): string { ensure_storage(); return DATA_DIR . '/token_' . preg_replace('/[^a-f0-9]/', '', strtolower($token)) . '.json'; }
function username_file(string $username): string { ensure_storage(); return DATA_DIR . '/username_' . sha1(clean_username($username)) . '.json'; }
function missions_file(): string { ensure_storage(); return DATA_DIR . '/missions.json'; }
function admin_file(): string { ensure_storage(); return DATA_DIR . '/admin.json'; }
function audit_file(): string { ensure_storage(); return DATA_DIR . '/admin_audit.jsonl'; }
function login_rate_file(string $ip): string { ensure_storage(); return DATA_DIR . '/admin_rate_' . sha1($ip) . '.json'; }
function referral_lock_file(): string { ensure_storage(); return DATA_DIR . '/referral.lock'; }
function referral_rewards_file(string $email): string { ensure_storage(); return DATA_DIR . '/referral_rewards_' . sha1(clean_email($email)) . '.jsonl'; }
function admin_coin_history_file(string $email): string { ensure_storage(); return DATA_DIR . '/admin_coin_' . sha1(clean_email($email)) . '.jsonl'; }



function read_json_file(string $file): ?array {
    if (!is_file($file)) return null;
    $data = json_decode((string) @file_get_contents($file), true);
    return is_array($data) ? $data : null;
}
function write_json_file(string $file, array $data): void {
    ensure_storage();
    $tmp = $file . '.tmp.' . bin2hex(random_bytes(4));
    $encoded = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if ($encoded === false || @file_put_contents($tmp, $encoded, LOCK_EX) === false) {
        @unlink($tmp); out(['ok'=>false,'error'=>'خطا در ذخیره اطلاعات سرور'], 500);
    }
    @chmod($tmp, 0640);
    if (!@rename($tmp, $file)) { @unlink($tmp); out(['ok'=>false,'error'=>'خطا در نهایی‌سازی اطلاعات سرور'], 500); }
}

function append_jsonl(string $file, array $row): void {
    ensure_storage();
    $line = json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($line === false || @file_put_contents($file, $line . PHP_EOL, FILE_APPEND | LOCK_EX) === false) {
        out(['ok'=>false,'error'=>'خطا در ثبت تاریخچه سرور'], 500);
    }
    @chmod($file, 0640);
}
function read_jsonl(string $file, int $limit = 100): array {
    if (!is_file($file)) return [];
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
    $rows = [];
    foreach (array_slice(array_reverse($lines), 0, max(1, $limit)) as $line) {
        $row = json_decode($line, true);
        if (is_array($row)) $rows[] = $row;
    }
    return $rows;
}
function with_referral_lock(callable $callback) {
    ensure_storage();
    $handle = @fopen(referral_lock_file(), 'c+');
    if ($handle === false || !@flock($handle, LOCK_EX)) {
        if (is_resource($handle)) @fclose($handle);
        out(['ok'=>false,'error'=>'قفل اطلاعات زیرمجموعه در دسترس نیست'], 503);
    }
    try { return $callback(); }
    finally { @flock($handle, LOCK_UN); @fclose($handle); }
}

function append_audit(string $action, array $meta = []): void {
    ensure_storage();
    $line = json_encode([
        'time'=>now_iso(), 'action'=>$action, 'ip'=>client_ip(),
        'admin'=>$_SESSION['admin_user'] ?? null, 'meta'=>$meta
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    @file_put_contents(audit_file(), $line . PHP_EOL, FILE_APPEND | LOCK_EX);
}
function client_ip(): string {
    $raw = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    return preg_replace('/[^0-9a-fA-F:.]/', '', $raw) ?: '0.0.0.0';
}
function reserve_username(string $username, string $email): bool {
    ensure_storage(); $file = username_file($username); $handle = @fopen($file, 'x');
    if ($handle === false) return false;
    $ok = @fwrite($handle, json_encode(['username'=>$username,'email'=>clean_email($email)], JSON_UNESCAPED_UNICODE)) !== false;
    @fclose($handle); @chmod($file, 0640); if (!$ok) @unlink($file); return $ok;
}
function release_username(string $username, string $email): void {
    if ($username === '') return; $file = username_file($username); $data = read_json_file($file);
    if (!$data || clean_email((string)($data['email'] ?? '')) === clean_email($email)) @unlink($file);
}

function boost_costs(): array {
    return [100,200,500,1000,5000,50000,150000,200000,300000,400000,500000,650000,800000,1000000,1200000,1400000,1600000,1800000,2000000];
}
function cups_config(): array {
    return [
        ['name'=>'Bronze','fa'=>'برنزی','min'=>0,'max'=>2499],
        ['name'=>'Silver','fa'=>'نقره‌ای','min'=>2500,'max'=>49999],
        ['name'=>'Gold','fa'=>'طلایی','min'=>50000,'max'=>999999],
        ['name'=>'Platinum','fa'=>'پلاتینی','min'=>1000000,'max'=>9999999],
        ['name'=>'Diamond','fa'=>'الماسی','min'=>10000000,'max'=>49999999],
        ['name'=>'Master','fa'=>'استاد','min'=>50000000,'max'=>99999999],
        ['name'=>'Grandmaster','fa'=>'استاد بزرگ','min'=>100000000,'max'=>249999999],
        ['name'=>'Champion','fa'=>'قهرمان','min'=>250000000,'max'=>999999999],
        ['name'=>'Legends','fa'=>'افسانه‌ها','min'=>1000000000,'max'=>null],
    ];
}
function cup_for_coins(float $coins): array {
    foreach (array_reverse(cups_config()) as $cup) {
        if ($coins >= $cup['min'] && ($cup['max'] === null || $coins <= $cup['max'])) return $cup;
    }
    return cups_config()[0];
}
function default_game(): array {
    return [
        'coins'=>0.0, 'energy'=>1000.0, 'maxEnergy'=>1000, 'power'=>1,
        'taps'=>0, 'tapLevel'=>1, 'energyLevel'=>1, 'rechargeLevel'=>1,
        'turboUntil'=>0, 'hourlyIncome'=>0.0, 'lastPassiveAt'=>time(), 'lastEnergyAt'=>time(),
        'missionLevels'=>[], 'missions'=>[], 'league'=>'Bronze',
        'quickResetDate'=>tehran_date(), 'instantEnergyUsed'=>0, 'turboUsed'=>0,
        'acceptedTerms'=>true, 'scoreReachedAt'=>0, 'updatedAt'=>now_iso(),
    ];
}
function normalize_game(array $game): array {
    $game = array_merge(default_game(), $game);
    if (!isset($game['missionLevels']) || !is_array($game['missionLevels'])) {
        $game['missionLevels'] = is_array($game['missions'] ?? null) ? $game['missions'] : [];
    }
    $game['coins'] = max(0, min((float)$game['coins'], 1.0e18));
    $game['tapLevel'] = max(1, min((int)$game['tapLevel'], 20));
    $game['energyLevel'] = max(1, min((int)$game['energyLevel'], 20));
    $game['rechargeLevel'] = max(1, min((int)$game['rechargeLevel'], 20));
    $game['power'] = $game['tapLevel'];
    $game['maxEnergy'] = 1000 + (($game['energyLevel'] - 1) * 500);
    $game['energy'] = max(0, min((float)$game['energy'], (float)$game['maxEnergy']));
    $game['taps'] = max(0, (int)$game['taps']);
    $game['turboUntil'] = max(0, (int)$game['turboUntil']);
    $game['scoreReachedAt'] = max(0, (int)($game['scoreReachedAt'] ?? 0));
    $game['lastPassiveAt'] = max(0, (int)$game['lastPassiveAt']);
    $game['lastEnergyAt'] = max(0, (int)$game['lastEnergyAt']);
    $game['instantEnergyUsed'] = max(0, min((int)$game['instantEnergyUsed'], 3));
    $game['turboUsed'] = max(0, min((int)$game['turboUsed'], 3));
    if ($game['quickResetDate'] !== tehran_date()) {
        $game['quickResetDate'] = tehran_date(); $game['instantEnergyUsed']=0; $game['turboUsed']=0;
    }
    $cleanLevels=[];
    foreach ($game['missionLevels'] as $id=>$level) {
        $sid=safe_id((string)$id); if ($sid!=='') $cleanLevels[$sid]=max(0,min((int)$level,100));
    }
    $game['missionLevels']=$cleanLevels;
    $game['league']=cup_for_coins((float)$game['coins'])['name'];
    return $game;
}
function normalize_mission_categories(array $rows, bool $includeDeleted = false): array {
    $categories = [];
    foreach ($rows as $index => $row) {
        if (!is_array($row)) continue;
        $id = safe_id((string)($row['id'] ?? ''));
        $name = clean_text((string)($row['name'] ?? ''), 50);
        if ($id === '' || $name === '') continue;
        $categories[] = [
            'id'=>$id,
            'name'=>$name,
            'active'=>(bool)($row['active'] ?? true),
            'deleted'=>(bool)($row['deleted'] ?? false),
            'sortOrder'=>max(-9999,min(9999,(int)($row['sortOrder'] ?? $index))),
            'createdAt'=>$row['createdAt'] ?? null,
            'updatedAt'=>$row['updatedAt'] ?? null,
        ];
    }
    if (!$includeDeleted) $categories = array_values(array_filter($categories, fn($c)=>empty($c['deleted'])));
    usort($categories, fn($a,$b)=>((int)($a['sortOrder']??0)<=> (int)($b['sortOrder']??0)) ?: strcmp((string)($a['name']??''),(string)($b['name']??'')));
    return $categories;
}
function missions_config(bool $includeDeleted = false): array {
    $data = read_json_file(missions_file()) ?? ['version'=>1,'categories'=>[],'missions'=>[],'updatedAt'=>now_iso()];
    $hasManagedCategories = array_key_exists('categories', $data) && is_array($data['categories']);
    $categories = normalize_mission_categories($hasManagedCategories ? $data['categories'] : [], $includeDeleted);
    $missions = is_array($data['missions'] ?? null) ? $data['missions'] : [];
    $legacyCategoryIds = ['markets','team','legal','specials'];
    foreach ($missions as &$mission) {
        $category = safe_id((string)($mission['category'] ?? ''));
        // v16 removes the four hard-coded categories. Legacy missions remain safe under «همه» until reassigned.
        if (!$hasManagedCategories && in_array($category, $legacyCategoryIds, true)) $category = '';
        $mission['category'] = $category;
        $levels = is_array($mission['levels'] ?? null) ? $mission['levels'] : [];
        $cumulative = 0.0;
        foreach ($levels as $index => &$row) {
            if (!is_array($row)) $row = [];
            $increment = max(0, (float)($row['profitIncrement'] ?? $row['hourlyIncome'] ?? 0));
            $cumulative += $increment;
            $row['level'] = $index + 1;
            $row['upgradeCost'] = max(0, (float)($row['upgradeCost'] ?? 0));
            $row['profitIncrement'] = $increment;
            $row['hourlyIncome'] = $increment; // compatibility with older clients
            $row['cumulativeIncome'] = $cumulative;
        }
        unset($row);
        $mission['levels'] = array_values($levels);
        $mission['maxLevel'] = count($levels);
    }
    unset($mission);
    if (!$includeDeleted) $missions = array_values(array_filter($missions, fn($m)=>empty($m['deleted'])));
    usort($missions, fn($a,$b)=>((int)($a['sortOrder']??0)<=> (int)($b['sortOrder']??0)) ?: strcmp((string)($a['title']??''),(string)($b['title']??'')));
    return ['version'=>(int)($data['version']??1),'categories'=>$categories,'missions'=>$missions,'updatedAt'=>$data['updatedAt']??null];
}
function save_missions(array $missions, ?array $categories = null): void {
    if ($categories === null) $categories = missions_config(true)['categories'];
    write_json_file(missions_file(), ['version'=>time(),'categories'=>array_values($categories),'missions'=>array_values($missions),'updatedAt'=>now_iso()]);
}
function mission_category_by_id(string $id, bool $includeDeleted = true): ?array {
    foreach (missions_config($includeDeleted)['categories'] as $category) if (($category['id'] ?? '') === $id) return $category;
    return null;
}
function mission_by_id(string $id, bool $includeDeleted = true): ?array {
    foreach (missions_config($includeDeleted)['missions'] as $mission) if (($mission['id'] ?? '') === $id) return $mission;
    return null;
}
function mission_level_income(array $mission, int $level): float {
    if ($level <= 0) return 0.0;
    $levels = is_array($mission['levels'] ?? null) ? $mission['levels'] : [];
    $level = min($level, count($levels));
    $total = 0.0;
    for ($i = 0; $i < $level; $i++) {
        $row = is_array($levels[$i] ?? null) ? $levels[$i] : [];
        $total += max(0, (float)($row['profitIncrement'] ?? $row['hourlyIncome'] ?? 0));
    }
    return max(0, $total);
}
function calculate_hourly_income(array $game): float {
    $all = missions_config(true)['missions']; $map=[]; foreach($all as $m) $map[(string)($m['id']??'')]=$m;
    $total=0.0;
    foreach (($game['missionLevels'] ?? []) as $id=>$level) if(isset($map[$id])) $total += mission_level_income($map[$id], (int)$level);
    return max(0,$total);
}
function settle_game(array $game, ?int $now = null): array {
    $now ??= time(); $game = normalize_game($game);
    $game['hourlyIncome'] = calculate_hourly_income($game);
    $lastPassive = max(0,(int)$game['lastPassiveAt']);
    if ($lastPassive <= 0) $lastPassive=$now;
    $elapsed = max(0,min(MAX_OFFLINE_SECONDS,$now-$lastPassive));
    $earned = ($game['hourlyIncome']/3600)*$elapsed;
    if ($earned>0) { $game['coins'] += $earned; $game['scoreReachedAt'] = $now; }
    $game['lastPassiveAt']=$now;
    $lastEnergy=max(0,(int)$game['lastEnergyAt']); if($lastEnergy<=0)$lastEnergy=$now;
    $energyElapsed=max(0,min(MAX_OFFLINE_SECONDS,$now-$lastEnergy));
    if($energyElapsed>0 && $game['energy']<$game['maxEnergy']) {
        $game['energy']=min((float)$game['maxEnergy'],(float)$game['energy']+($energyElapsed*$game['rechargeLevel']));
    }
    $game['lastEnergyAt']=$now;
    $game['league']=cup_for_coins((float)$game['coins'])['name'];
    $game['updatedAt']=now_iso();
    $game['_passiveEarned']=$earned;
    return $game;
}
function find_user_by_email(string $email): ?array { return read_json_file(user_file($email)); }
function save_user(array $user): void { $user['updatedAt']=now_iso(); write_json_file(user_file((string)$user['email']),$user); }
function new_token(string $email): string {
    $token=bin2hex(random_bytes(32)); write_json_file(token_file($token),['email'=>clean_email($email),'createdAt'=>time(),'lastRefreshAt'=>time(),'expiresAt'=>time()+USER_SESSION_TTL_SECONDS]); return $token;
}
function token_from_header(): string {
    $header=$_SERVER['HTTP_AUTHORIZATION']??$_SERVER['REDIRECT_HTTP_AUTHORIZATION']??'';
    if (preg_match('/Bearer\s+([a-f0-9]{64})/i',$header,$m)) return strtolower($m[1]);
    foreach ([SESSION_COOKIE_NAME, LEGACY_TOKEN_COOKIE_NAME] as $cookieName) {
        $candidate = strtolower(trim((string)($_COOKIE[$cookieName] ?? '')));
        if (preg_match('/^[a-f0-9]{64}$/', $candidate)) return $candidate;
    }
    return '';
}
function session_user_from_token(string $token, bool $touch = true): ?array {
    if (!preg_match('/^[a-f0-9]{64}$/', $token)) return null;
    $tokenPath=token_file($token);
    $td=read_json_file($tokenPath);
    if(!$td||($td['expiresAt']??0)<time()) { @unlink($tokenPath); return null; }
    // Sliding one-year session: every successful app open renews the persistent session.
    if ((int)($td['lastRefreshAt']??0) < time()-86400) {
        $td['lastRefreshAt']=time();
        $td['expiresAt']=time()+USER_SESSION_TTL_SECONDS;
        write_json_file($tokenPath,$td);
    }
    $user=find_user_by_email((string)($td['email']??''));
    if(!$user) return null;
    if($touch){ $last=(int)($user['lastSeen']??0); if(time()-$last>=20){$user['lastSeen']=time(); save_user($user);} }
    return $user;
}
function auth_user(bool $touch = true): array {
    $token=token_from_header(); if($token==='') out(['ok'=>false,'error'=>'unauthorized'],401);
    $user=session_user_from_token($token,$touch); if(!$user) out(['ok'=>false,'error'=>'session_expired'],401);
    if(!empty($user['suspended'])) out(['ok'=>false,'error'=>'این حساب توسط مدیریت غیرفعال شده است'],403);
    persist_session_cookie($token);
    return $user;
}
function fallback_username(array $user): string {
    $prefix=preg_replace('/[^a-z0-9]/','',strtolower((string)strtok((string)($user['email']??'player'),'@')))?:'player';
    return substr($prefix.substr(sha1((string)($user['email']??'')),0,5),0,24);
}
function public_user(array $user, bool $settle = false): array {
    $game = $settle ? settle_game(is_array($user['game']??null)?$user['game']:[]) : normalize_game(is_array($user['game']??null)?$user['game']:[]);
    $display = clean_display_name((string)($user['displayName'] ?? $user['username'] ?? ''));
    if ($display === '') $display = 'بازیکن';
    return [
        'email'=>$user['email'],
        'username'=>$display, // legacy response key; this is a non-unique display name
        'displayName'=>$display,
        'userId'=>$user['userId']??substr(strtoupper(sha1((string)$user['email'])),0,8),
        'game'=>$game,'createdAt'=>$user['createdAt']??null,'updatedAt'=>$user['updatedAt']??null,
        'lastSeen'=>(int)($user['lastSeen']??0),'suspended'=>(bool)($user['suspended']??false),
        'isGuest'=>is_guest_user($user),
    ];
}
function all_users(): array {
    ensure_storage(); $users=[];
    foreach(glob(DATA_DIR.'/user_*.json')?:[] as $file){$u=read_json_file($file);if(is_array($u)&&isset($u['email']))$users[]=$u;}
    return $users;
}
function save_settled_user(array $user): array {
    $settled=settle_game(is_array($user['game']??null)?$user['game']:[]); $earned=(float)($settled['_passiveEarned']??0); unset($settled['_passiveEarned']);
    $user['game']=$settled; $user['lastSeen']=time(); save_user($user); award_pending_referral_leagues((string)$user['email']);
    $user=find_user_by_email((string)$user['email'])??$user; $user['_passiveEarned']=$earned; return $user;
}


function clean_referral_code(string $code): string {
    return strtoupper(preg_replace('/[^A-Za-z0-9]/', '', trim($code)) ?? '');
}
function referral_signup_reward(): float { return 2500.0; }
function referral_league_reward(string $league): float { return $league === 'Bronze' ? 0.0 : 2500.0; }
function referral_code_candidate(array $user, int $salt = 0): string {
    $seed = clean_email((string)($user['email'] ?? '')) . '|' . (string)($user['userId'] ?? '') . '|' . $salt;
    return 'HM' . strtoupper(substr(hash('sha256', $seed), 0, 8));
}
function ensure_referral_code(array $user, bool $persist = true): array {
    $current = clean_referral_code((string)($user['referralCode'] ?? ''));
    if (preg_match('/^HM[A-Z0-9]{8}$/', $current)) {
        $user['referralCode'] = $current;
        return $user;
    }
    $used = [];
    foreach (all_users() as $other) {
        if (clean_email((string)($other['email'] ?? '')) === clean_email((string)($user['email'] ?? ''))) continue;
        $code = clean_referral_code((string)($other['referralCode'] ?? ''));
        if ($code === '') $code = referral_code_candidate($other);
        $used[$code] = true;
    }
    $salt = 0;
    do { $current = referral_code_candidate($user, $salt++); } while (isset($used[$current]) && $salt < 1000);
    $user['referralCode'] = $current;
    if ($persist && !empty($user['email'])) save_user($user);
    return $user;
}
function find_user_by_referral_code(string $code): ?array {
    $code = clean_referral_code($code);
    if ($code === '') return null;
    foreach (all_users() as $user) {
        $candidate = clean_referral_code((string)($user['referralCode'] ?? ''));
        if ($candidate === '') $candidate = referral_code_candidate($user);
        if (hash_equals($candidate, $code)) {
            if (($user['referralCode'] ?? '') !== $candidate) { $user['referralCode'] = $candidate; save_user($user); }
            return $user;
        }
    }
    return null;
}
function referral_reward_totals(string $email): array {
    $file = referral_rewards_file($email);
    if (!is_file($file)) return ['total'=>0.0,'signup'=>0.0,'league'=>0.0,'count'=>0];
    $total = $signup = $league = 0.0; $count = 0;
    $handle = @fopen($file, 'rb');
    if ($handle) {
        while (($line = fgets($handle)) !== false) {
            $row = json_decode(trim($line), true);
            if (!is_array($row)) continue;
            $amount = max(0, (float)($row['amount'] ?? 0));
            $total += $amount; $count++;
            if (($row['type'] ?? '') === 'signup') $signup += $amount;
            if (($row['type'] ?? '') === 'league') $league += $amount;
        }
        fclose($handle);
    }
    return ['total'=>$total,'signup'=>$signup,'league'=>$league,'count'=>$count];
}
function referral_summary(array $user): array {
    $user = ensure_referral_code($user, true);
    $email = clean_email((string)$user['email']);
    $invited = [];
    foreach (all_users() as $candidate) {
        if (clean_email((string)($candidate['referredByEmail'] ?? '')) !== $email) continue;
        $p = public_user($candidate);
        $invited[] = [
            'email'=>$p['email'],'displayName'=>$p['displayName'],'userId'=>$p['userId'],
            'league'=>cup_for_coins((float)($p['game']['coins'] ?? 0))['fa'],
            'createdAt'=>$candidate['createdAt'] ?? null,
        ];
    }
    usort($invited, fn($a,$b)=>strcmp((string)($b['createdAt']??''),(string)($a['createdAt']??'')));
    $inviter = null;
    if (!empty($user['referredByEmail'])) {
        $up = find_user_by_email((string)$user['referredByEmail']);
        if ($up) { $p = public_user($up); $inviter=['displayName'=>$p['displayName'],'userId'=>$p['userId']]; }
    }
    return [
        'code'=>$user['referralCode'],
        'invitedCount'=>count($invited),
        'invited'=>array_slice($invited,0,100),
        'inviter'=>$inviter,
        'totals'=>referral_reward_totals($email),
        'rewards'=>read_jsonl(referral_rewards_file($email),100),
        'signupReward'=>referral_signup_reward(),
        'leagueReward'=>2500.0,
    ];
}
function award_pending_referral_leagues(string $email): void {
    $email = clean_email($email);
    if ($email === '') return;
    with_referral_lock(function() use ($email): void {
        $queue = [$email]; $iterations = 0;
        while ($queue && $iterations++ < 50) {
            $currentEmail = array_shift($queue);
            $downline = find_user_by_email($currentEmail);
            if (!$downline || empty($downline['referredByEmail'])) continue;
            $inviterEmail = clean_email((string)$downline['referredByEmail']);
            if ($inviterEmail === '' || $inviterEmail === $currentEmail) continue;
            $game = normalize_game(is_array($downline['game'] ?? null) ? $downline['game'] : []);
            $currentLeague = (string)$game['league'];
            $cups = cups_config();
            $currentIndex = -1;
            foreach ($cups as $i=>$cup) if ($cup['name'] === $currentLeague) { $currentIndex = $i; break; }
            if ($currentIndex <= 0) continue;
            $paid = array_values(array_unique(array_map('strval', is_array($downline['referralRewardedLeagues'] ?? null) ? $downline['referralRewardedLeagues'] : [])));
            $inviter = find_user_by_email($inviterEmail);
            if (!$inviter) continue;
            $inviterGame = settle_game(is_array($inviter['game'] ?? null) ? $inviter['game'] : []);
            unset($inviterGame['_passiveEarned']);
            $added = 0.0;
            for ($i=1; $i<=$currentIndex; $i++) {
                $league = (string)$cups[$i]['name'];
                if (in_array($league, $paid, true)) continue;
                $amount = referral_league_reward($league);
                $paid[] = $league;
                if ($amount <= 0) continue;
                $inviterGame['coins'] += $amount;
                $inviterGame['scoreReachedAt'] = time();
                $added += $amount;
                append_jsonl(referral_rewards_file($inviterEmail), [
                    'id'=>'league:'.sha1($currentEmail.'|'.$league),
                    'type'=>'league','amount'=>$amount,'league'=>$league,'leagueFa'=>$cups[$i]['fa'],
                    'fromEmail'=>$currentEmail,'fromUserId'=>$downline['userId']??null,
                    'fromDisplayName'=>$downline['displayName']??$downline['username']??'بازیکن','time'=>now_iso(),
                ]);
            }
            $downline['referralRewardedLeagues'] = $paid;
            save_user($downline);
            if ($added > 0) {
                $inviter['game'] = normalize_game($inviterGame);
                save_user($inviter);
                $queue[] = $inviterEmail;
            }
        }
    });
}
function save_user_with_referral_awards(array $user): array {
    save_user($user);
    award_pending_referral_leagues((string)($user['email'] ?? ''));
    return find_user_by_email((string)($user['email'] ?? '')) ?? $user;
}
function admin_coin_history(string $email, int $limit = 100): array { return read_jsonl(admin_coin_history_file($email), $limit); }


function start_admin_session(): void {
    if(session_status()===PHP_SESSION_ACTIVE)return;
    $secure=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off');
    session_name('hamster_admin');
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$secure,'httponly'=>true,'samesite'=>'Strict']);
    session_start();
}
function admin_config(): array {
    $cfg=read_json_file(admin_file());
    if(!$cfg){$cfg=['username'=>DEFAULT_ADMIN_USERNAME,'passwordHash'=>DEFAULT_ADMIN_PASSWORD_HASH,'updatedAt'=>now_iso()];write_json_file(admin_file(),$cfg);}
    return $cfg;
}
function admin_logged_in(): bool { start_admin_session(); return !empty($_SESSION['admin_ok']) && (int)($_SESSION['admin_expires']??0)>time(); }
function admin_csrf(): string { start_admin_session(); if(empty($_SESSION['admin_csrf']))$_SESSION['admin_csrf']=bin2hex(random_bytes(24)); return (string)$_SESSION['admin_csrf']; }
function require_admin(bool $csrf = false): void {
    if(!admin_logged_in())out(['ok'=>false,'error'=>'admin_unauthorized'],401);
    $_SESSION['admin_expires']=time()+3600;
    if($csrf){$sent=$_SERVER['HTTP_X_CSRF_TOKEN']??'';if(!hash_equals(admin_csrf(),$sent))out(['ok'=>false,'error'=>'csrf_invalid'],419);}
}
function login_rate_state(): array { return read_json_file(login_rate_file(client_ip()))??['attempts'=>[]]; }
function login_rate_check(): void {
    $state=login_rate_state();$cut=time()-900;$attempts=array_values(array_filter($state['attempts']??[],fn($t)=>(int)$t>=$cut));
    if(count($attempts)>=5)out(['ok'=>false,'error'=>'تلاش‌های ورود بیش از حد است؛ ۱۵ دقیقه بعد دوباره امتحان کن'],429);
}
function login_rate_fail(): void {$s=login_rate_state();$s['attempts'][]=time();write_json_file(login_rate_file(client_ip()),$s);}
function login_rate_clear(): void {@unlink(login_rate_file(client_ip()));}


// ===== Education-only app + Persian Hamster Academy CMS (v34) =====
// Legacy app config kept for backward compatibility with the existing website/API.
function app_config_file(): string { ensure_storage(); return DATA_DIR . '/app_config.json'; }
function default_app_config(): array {
    return [
        'defaultTab'=>'tutorials',
        'gameStatus'=>'coming_soon',
        'comingSoonTitle'=>'بازی همستر',
        'comingSoonText'=>'نسخه فعلی اپ فقط آموزشی است.',
        'updatedAt'=>now_iso(),
    ];
}
function app_config(): array {
    $cfg=array_merge(default_app_config(), read_json_file(app_config_file()) ?? []);
    $cfg['defaultTab']=in_array(($cfg['defaultTab']??''),['tutorials','game'],true)?$cfg['defaultTab']:'tutorials';
    $cfg['gameStatus']=in_array(($cfg['gameStatus']??''),['active','coming_soon'],true)?$cfg['gameStatus']:'coming_soon';
    $cfg['comingSoonTitle']=clean_text((string)($cfg['comingSoonTitle']??'بازی همستر'),80);
    $cfg['comingSoonText']=clean_text((string)($cfg['comingSoonText']??'نسخه فعلی اپ فقط آموزشی است.'),240);
    return $cfg;
}
function save_app_config(array $cfg): void {
    $out=[
        'defaultTab'=>in_array(($cfg['defaultTab']??''),['tutorials','game'],true)?$cfg['defaultTab']:'tutorials',
        'gameStatus'=>in_array(($cfg['gameStatus']??''),['active','coming_soon'],true)?$cfg['gameStatus']:'coming_soon',
        'comingSoonTitle'=>clean_text((string)($cfg['comingSoonTitle']??'بازی همستر'),80),
        'comingSoonText'=>clean_text((string)($cfg['comingSoonText']??'نسخه فعلی اپ فقط آموزشی است.'),240),
        'updatedAt'=>now_iso(),
    ];
    write_json_file(app_config_file(),$out);
}
function tutorials_file(): string { ensure_storage(); return DATA_DIR . '/tutorials.json'; }
function tutorial_upload_dir(): string { $d=__DIR__ . '/../uploads/tutorials'; if(!is_dir($d)) @mkdir($d,0755,true); return $d; }
function education_seed_file(): string { return __DIR__ . '/seed/education_v34.json'; }
function education_seed_data(): array {
    $raw=@file_get_contents(education_seed_file());
    $d=is_string($raw)?json_decode($raw,true):null;
    return is_array($d)?$d:['seedVersion'=>34,'categories'=>[],'tutorials'=>[]];
}
function default_tutorial_categories(): array {
    $seed=education_seed_data();
    return is_array($seed['categories']??null)?$seed['categories']:[];
}
function normalize_tutorial_categories(array $rows,bool $includeDeleted=false): array {
    $out=[];
    foreach($rows as $i=>$row){if(!is_array($row))continue;$id=safe_id((string)($row['id']??''));$name=clean_text((string)($row['name']??''),70);if($id===''||$name==='')continue;$out[]=[
        'id'=>$id,'name'=>$name,'icon'=>u_substr(trim((string)($row['icon']??'📘')),0,6),'parentId'=>safe_id((string)($row['parentId']??'')),
        'description'=>clean_text((string)($row['description']??''),220),'image'=>trim((string)($row['image']??'')),
        'active'=>(bool)($row['active']??true),'deleted'=>(bool)($row['deleted']??false),'sortOrder'=>max(-9999,min(9999,(int)($row['sortOrder']??$i))),
        'createdAt'=>$row['createdAt']??null,'updatedAt'=>$row['updatedAt']??null,
    ];}
    if(!$includeDeleted)$out=array_values(array_filter($out,fn($x)=>empty($x['deleted'])));
    usort($out,fn($a,$b)=>($a['sortOrder']<=>$b['sortOrder'])?:strcmp((string)$a['name'],(string)$b['name']));return $out;
}
function normalize_tutorial(array $t): array {
    $sourceUrl=trim((string)($t['sourceUrl']??''));
    if($sourceUrl!==''&&!filter_var($sourceUrl,FILTER_VALIDATE_URL))$sourceUrl='';
    return [
        'id'=>safe_id((string)($t['id']??'')),'title'=>clean_text((string)($t['title']??''),120),
        'summary'=>clean_text((string)($t['summary']??''),280),'body'=>trim((string)($t['body']??'')),
        'categoryId'=>safe_id((string)($t['categoryId']??'')),'cover'=>trim((string)($t['cover']??'')),
        'videoUrl'=>trim((string)($t['videoUrl']??'')),'sourceUrl'=>$sourceUrl,'sourceTitle'=>clean_text((string)($t['sourceTitle']??''),80),
        'level'=>in_array(($t['level']??''),['مبتدی','متوسط','حرفه‌ای'],true)?$t['level']:'مبتدی',
        'duration'=>max(0,min(9999,(int)($t['duration']??0))),'tags'=>array_values(array_slice(array_filter(array_map(fn($x)=>clean_text((string)$x,30),is_array($t['tags']??null)?$t['tags']:[])),0,20)),
        'featured'=>(bool)($t['featured']??false),'active'=>(bool)($t['active']??true),'deleted'=>(bool)($t['deleted']??false),
        'views'=>max(0,(int)($t['views']??0)),
        'sortOrder'=>max(-9999,min(9999,(int)($t['sortOrder']??0))),'createdAt'=>$t['createdAt']??null,'updatedAt'=>$t['updatedAt']??null,
    ];
}
function tutorial_seed_merge(array $d): array {
    $seed=education_seed_data();
    $seedVersion=(int)($seed['seedVersion']??34);
    if((int)($d['seedVersion']??0)>=$seedVersion)return $d;

    $legacyDefaults=['mobile','computer','internet','social','ai','programming','graphics','video','business','freelance','crypto','finance','software','games','english','languages','school','exam','cooking','home','mobile-repair','pc-repair','electronics','car','sewing','art','music','photography','fitness','health','agriculture','livestock','career','office','banking','travel','general','security','cloud','office-suite','content','marketing','seo','ecommerce','hardware','science','math','legal'];

    $existingTutorials=is_array($d['tutorials']??null)?$d['tutorials']:[];
    $used=[];
    foreach($existingTutorials as $t){
        if(!is_array($t)||!empty($t['deleted'])||($t['id']??'')==='welcome')continue;
        $cid=safe_id((string)($t['categoryId']??'')); if($cid!=='')$used[$cid]=true;
    }

    $cats=[];
    foreach(is_array($d['categories']??null)?$d['categories']:[] as $c){
        if(!is_array($c))continue;
        $id=safe_id((string)($c['id']??''));
        if(in_array($id,$legacyDefaults,true)&&empty($used[$id]))continue;
        $cats[$id]=$c;
    }
    foreach(is_array($seed['categories']??null)?$seed['categories']:[] as $c){
        if(!is_array($c))continue;$id=safe_id((string)($c['id']??''));if($id==='')continue;
        if(!isset($cats[$id]))$cats[$id]=$c;else $cats[$id]=array_merge($c,$cats[$id]);
    }

    $items=[];
    foreach($existingTutorials as $t){
        if(!is_array($t)||($t['id']??'')==='welcome')continue;
        $id=safe_id((string)($t['id']??''));if($id!=='')$items[$id]=$t;
    }
    foreach(is_array($seed['tutorials']??null)?$seed['tutorials']:[] as $t){
        if(!is_array($t))continue;$id=safe_id((string)($t['id']??''));if($id==='')continue;
        if(!isset($items[$id]))$items[$id]=$t;else $items[$id]=array_merge($t,$items[$id]);
    }

    return [
        'seedVersion'=>$seedVersion,
        'version'=>(int)($d['version']??1),
        'categories'=>array_values($cats),
        'tutorials'=>array_values($items),
        'updatedAt'=>now_iso(),
    ];
}
function tutorials_config(bool $includeDeleted=false): array {
    $d=read_json_file(tutorials_file());
    if(!$d){
        $seed=education_seed_data();
        $d=[
            'seedVersion'=>(int)($seed['seedVersion']??34),
            'version'=>1,
            'categories'=>is_array($seed['categories']??null)?$seed['categories']:[],
            'tutorials'=>is_array($seed['tutorials']??null)?$seed['tutorials']:[],
            'updatedAt'=>now_iso()
        ];
        write_json_file(tutorials_file(),$d);
    }else{
        $merged=tutorial_seed_merge($d);
        if(json_encode($merged,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)!==json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)){
            $d=$merged;write_json_file(tutorials_file(),$d);
        }
    }
    $cats=normalize_tutorial_categories(is_array($d['categories']??null)?$d['categories']:default_tutorial_categories(),$includeDeleted);
    $tutorials=[];foreach(is_array($d['tutorials']??null)?$d['tutorials']:[] as $t){if(!is_array($t))continue;$n=normalize_tutorial($t);if($n['id']===''||$n['title']==='')continue;if(!$includeDeleted&&!empty($n['deleted']))continue;$tutorials[]=$n;}
    usort($tutorials,fn($a,$b)=>($a['sortOrder']<=>$b['sortOrder'])?:strcmp((string)$b['updatedAt'],(string)$a['updatedAt']));
    return ['seedVersion'=>(int)($d['seedVersion']??34),'version'=>(int)($d['version']??1),'categories'=>$cats,'tutorials'=>$tutorials,'updatedAt'=>$d['updatedAt']??null];
}
function save_tutorials(array $tutorials,?array $categories=null): void {
    $current=read_json_file(tutorials_file())??[];
    if($categories===null)$categories=tutorials_config(true)['categories'];
    write_json_file(tutorials_file(),[
        'seedVersion'=>max(34,(int)($current['seedVersion']??34)),
        'version'=>time(),'categories'=>array_values($categories),'tutorials'=>array_values($tutorials),'updatedAt'=>now_iso()
    ]);
}
function tutorial_by_id(string $id,bool $includeDeleted=false): ?array {foreach(tutorials_config($includeDeleted)['tutorials'] as $t)if(($t['id']??'')===$id)return $t;return null;}


// ===== App-only CMS: sliders, online news and popularity counters (v34) =====
function app_content_file(): string { ensure_storage(); return DATA_DIR . '/app_content.json'; }
function app_content_seed_file(): string { return __DIR__ . '/seed/app_v34.json'; }
function app_content_seed(): array {
    $raw=@file_get_contents(app_content_seed_file());$d=is_string($raw)?json_decode($raw,true):null;
    return is_array($d)?$d:['seedVersion'=>34,'sliders'=>[],'news'=>[]];
}
function normalize_slider(array $s): array {
    $type=in_array(($s['targetType']??''),['tutorial','category','news','url'],true)?$s['targetType']:'category';
    return [
        'id'=>safe_id((string)($s['id']??'')),'title'=>clean_text((string)($s['title']??''),100),
        'subtitle'=>clean_text((string)($s['subtitle']??''),220),'kicker'=>clean_text((string)($s['kicker']??''),50),
        'buttonText'=>clean_text((string)($s['buttonText']??'مشاهده'),40),'icon'=>u_substr(trim((string)($s['icon']??'🎓')),0,6),
        'image'=>trim((string)($s['image']??'')),'targetType'=>$type,'targetValue'=>trim((string)($s['targetValue']??'')),
        'active'=>(bool)($s['active']??true),'deleted'=>(bool)($s['deleted']??false),'sortOrder'=>max(-9999,min(9999,(int)($s['sortOrder']??0))),
        'createdAt'=>$s['createdAt']??null,'updatedAt'=>$s['updatedAt']??null,
    ];
}
function normalize_news(array $n): array {
    $source=trim((string)($n['sourceUrl']??''));if($source!==''&&!filter_var($source,FILTER_VALIDATE_URL))$source='';
    return [
        'id'=>safe_id((string)($n['id']??'')),'title'=>clean_text((string)($n['title']??''),140),
        'summary'=>clean_text((string)($n['summary']??''),320),'body'=>trim((string)($n['body']??'')),'cover'=>trim((string)($n['cover']??'')),
        'sourceTitle'=>clean_text((string)($n['sourceTitle']??''),90),'sourceUrl'=>$source,
        'publishedAt'=>clean_text((string)($n['publishedAt']??''),50),'views'=>max(0,(int)($n['views']??0)),
        'active'=>(bool)($n['active']??true),'deleted'=>(bool)($n['deleted']??false),'sortOrder'=>max(-9999,min(9999,(int)($n['sortOrder']??0))),
        'createdAt'=>$n['createdAt']??null,'updatedAt'=>$n['updatedAt']??null,
    ];
}
function app_content(bool $includeDeleted=false): array {
    $seed=app_content_seed();$d=read_json_file(app_content_file());
    if(!$d){$d=['seedVersion'=>34,'version'=>1,'sliders'=>$seed['sliders']??[],'news'=>$seed['news']??[],'updatedAt'=>now_iso()];write_json_file(app_content_file(),$d);}
    elseif((int)($d['seedVersion']??0)<34){
        $sl=[];foreach(is_array($d['sliders']??null)?$d['sliders']:[] as $x){if(is_array($x)&&!empty($x['id']))$sl[$x['id']]=$x;}foreach(is_array($seed['sliders']??null)?$seed['sliders']:[] as $x){if(is_array($x)&&!empty($x['id'])&&!isset($sl[$x['id']]))$sl[$x['id']]=$x;}
        $nw=[];foreach(is_array($d['news']??null)?$d['news']:[] as $x){if(is_array($x)&&!empty($x['id']))$nw[$x['id']]=$x;}foreach(is_array($seed['news']??null)?$seed['news']:[] as $x){if(is_array($x)&&!empty($x['id'])&&!isset($nw[$x['id']]))$nw[$x['id']]=$x;}
        $d=['seedVersion'=>34,'version'=>time(),'sliders'=>array_values($sl),'news'=>array_values($nw),'updatedAt'=>now_iso()];write_json_file(app_content_file(),$d);
    }
    $sl=[];foreach(is_array($d['sliders']??null)?$d['sliders']:[] as $x){if(!is_array($x))continue;$n=normalize_slider($x);if($n['id']==='')continue;if(!$includeDeleted&&!empty($n['deleted']))continue;$sl[]=$n;}
    usort($sl,fn($a,$b)=>($a['sortOrder']<=>$b['sortOrder']));
    $nw=[];foreach(is_array($d['news']??null)?$d['news']:[] as $x){if(!is_array($x))continue;$n=normalize_news($x);if($n['id']===''||$n['title']==='')continue;if(!$includeDeleted&&!empty($n['deleted']))continue;$nw[]=$n;}
    usort($nw,function($a,$b){$d=strcmp((string)$b['publishedAt'],(string)$a['publishedAt']);return $d!==0?$d:($a['sortOrder']<=>$b['sortOrder']);});
    return ['seedVersion'=>(int)($d['seedVersion']??34),'version'=>(int)($d['version']??1),'sliders'=>$sl,'news'=>$nw,'updatedAt'=>$d['updatedAt']??null];
}
function save_app_content(array $sliders,array $news): void { write_json_file(app_content_file(),['seedVersion'=>34,'version'=>time(),'sliders'=>array_values($sliders),'news'=>array_values($news),'updatedAt'=>now_iso()]); }
function news_by_id(string $id,bool $includeDeleted=false): ?array { foreach(app_content($includeDeleted)['news'] as $n)if(($n['id']??'')===$id)return $n;return null; }
function increment_content_view(string $type,string $id): int {
    if($type==='tutorial'){
        $cfg=tutorials_config(true);$items=$cfg['tutorials'];$count=0;$found=false;
        foreach($items as &$t)if(($t['id']??'')===$id){$t['views']=max(0,(int)($t['views']??0))+1;$count=(int)$t['views'];$found=true;break;}unset($t);
        if($found){save_tutorials($items,$cfg['categories']);record_app_view_day('tutorial');}return $count;
    }
    if($type==='news'){
        $cfg=app_content(true);$news=$cfg['news'];$count=0;$found=false;
        foreach($news as &$n)if(($n['id']??'')===$id){$n['views']=max(0,(int)($n['views']??0))+1;$count=(int)$n['views'];$found=true;break;}unset($n);
        if($found){save_app_content($cfg['sliders'],$news);record_app_view_day('news');}return $count;
    }
    return 0;
}


// ===== App education analytics / presence (v35) =====
function app_analytics_file(): string { ensure_storage(); return DATA_DIR . '/app_analytics.json'; }
function app_analytics(): array {
    $d=read_json_file(app_analytics_file());
    if(!is_array($d))$d=[];
    if(!is_array($d['devices']??null))$d['devices']=[];
    if(!is_array($d['days']??null))$d['days']=[];
    if(!is_array($d['viewsByDay']??null))$d['viewsByDay']=[];
    if(!isset($d['schema']))$d['schema']=1;
    return $d;
}
function save_app_analytics(array $d): void { write_json_file(app_analytics_file(),$d); }
function app_tehran_dt(?int $ts=null): DateTimeImmutable { $d=new DateTimeImmutable('@'.($ts??time())); return $d->setTimezone(new DateTimeZone('Asia/Tehran')); }
function app_day_key(?int $ts=null): string { return app_tehran_dt($ts)->format('Y-m-d'); }
function app_prune_analytics(array &$d): void {
    $cut=date('Y-m-d',strtotime('-120 days'));
    foreach(array_keys($d['days']??[]) as $day)if($day<$cut)unset($d['days'][$day]);
    foreach(array_keys($d['viewsByDay']??[]) as $day)if($day<$cut)unset($d['viewsByDay'][$day]);
}
function record_app_presence(string $deviceId,string $version='',string $event='heartbeat'): array {
    $deviceId=preg_replace('/[^a-zA-Z0-9._:-]/','',substr($deviceId,0,120));
    if($deviceId==='')return ['ok'=>false];
    $d=app_analytics();$now=time();$day=app_day_key($now);
    $row=is_array($d['devices'][$deviceId]??null)?$d['devices'][$deviceId]:[];
    if(empty($row['firstSeen']))$row['firstSeen']=$now;
    $row['lastSeen']=$now;$row['lastVersion']=clean_text($version,32);
    if($event==='open')$row['openCount']=max(0,(int)($row['openCount']??0))+1;
    else $row['openCount']=max(0,(int)($row['openCount']??0));
    $d['devices'][$deviceId]=$row;
    if(!is_array($d['days'][$day]??null))$d['days'][$day]=[];
    $d['days'][$day][$deviceId]=1;
    app_prune_analytics($d);save_app_analytics($d);
    return ['ok'=>true,'serverTime'=>$now];
}
function record_app_view_day(string $type): void {
    if(!in_array($type,['tutorial','news'],true))return;
    $d=app_analytics();$day=app_day_key();
    if(!is_array($d['viewsByDay'][$day]??null))$d['viewsByDay'][$day]=['tutorial'=>0,'news'=>0];
    $d['viewsByDay'][$day][$type]=max(0,(int)($d['viewsByDay'][$day][$type]??0))+1;
    app_prune_analytics($d);save_app_analytics($d);
}
function app_unique_between(string $from,string $to,array $d): int {
    $ids=[];$tz=new DateTimeZone('Asia/Tehran');$cur=new DateTimeImmutable($from,$tz);$end=new DateTimeImmutable($to,$tz);
    while($cur<=$end){$day=$cur->format('Y-m-d');foreach(array_keys(is_array($d['days'][$day]??null)?$d['days'][$day]:[]) as $id)$ids[$id]=1;$cur=$cur->modify('+1 day');}return count($ids);
}
function app_analytics_stats(): array {
    $d=app_analytics();$now=time();$td=app_tehran_dt($now);$today=$td->format('Y-m-d');$yesterday=$td->modify('-1 day')->format('Y-m-d');
    $online=0;foreach($d['devices'] as $row)if(is_array($row)&&$now-(int)($row['lastSeen']??0)<=180)$online++;
    $daysSinceSaturday=((int)$td->format('w')+1)%7;$weekStart=$td->modify('-'.$daysSinceSaturday.' days')->format('Y-m-d');
    $monthStart=$td->format('Y-m-01');
    $vd=is_array($d['viewsByDay'][$today]??null)?$d['viewsByDay'][$today]:[];
    return [
        'online'=>$online,
        'today'=>count(is_array($d['days'][$today]??null)?$d['days'][$today]:[]),
        'yesterday'=>count(is_array($d['days'][$yesterday]??null)?$d['days'][$yesterday]:[]),
        'week'=>app_unique_between($weekStart,$today,$d),
        'month'=>app_unique_between($monthStart,$today,$d),
        'totalUsers'=>count($d['devices']),
        'tutorialViewsToday'=>(int)($vd['tutorial']??0),
        'newsViewsToday'=>(int)($vd['news']??0),
    ];
}
function ensure_real_views_baseline(): void {
    $marker=DATA_DIR.'/real_views_v35.marker';if(is_file($marker))return;
    $tc=tutorials_config(true);$changed=false;
    foreach($tc['tutorials'] as &$t){if((int)($t['views']??0)!==0){$t['views']=0;$changed=true;}}unset($t);
    if($changed)save_tutorials($tc['tutorials'],$tc['categories']);
    $ac=app_content(true);$changed=false;
    foreach($ac['news'] as &$n){if((int)($n['views']??0)!==0){$n['views']=0;$changed=true;}}unset($n);
    if($changed)save_app_content($ac['sliders'],$ac['news']);
    @file_put_contents($marker,now_iso());
}
