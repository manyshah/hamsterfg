<?php
require __DIR__ . '/_lib.php';
start_admin_session();
$in = json_input();
$action = $_GET['action'] ?? ($in['action'] ?? 'session');

if ($action === 'session') {
    out([
        'ok' => true,
        'loggedIn' => admin_logged_in(),
        'csrf' => admin_logged_in() ? admin_csrf() : null,
        'username' => $_SESSION['admin_user'] ?? null,
    ]);
}

if ($action === 'login') {
    login_rate_check();
    $cfg = admin_config();
    $username = trim((string)($in['username'] ?? ''));
    $password = (string)($in['password'] ?? '');
    if (!hash_equals((string)$cfg['username'], $username) || !password_verify($password, (string)$cfg['passwordHash'])) {
        login_rate_fail();
        append_audit('login_failed', ['username' => $username]);
        out(['ok' => false, 'error' => 'نام کاربری یا رمز عبور اشتباه است'], 401);
    }
    login_rate_clear();
    session_regenerate_id(true);
    $_SESSION['admin_ok'] = true;
    $_SESSION['admin_user'] = $username;
    $_SESSION['admin_expires'] = time() + 3600;
    $_SESSION['admin_csrf'] = bin2hex(random_bytes(24));
    append_audit('login_success');
    out(['ok' => true, 'csrf' => admin_csrf(), 'username' => $username]);
}

if ($action === 'logout') {
    require_admin(true);
    append_audit('logout');
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
    out(['ok' => true]);
}

$readOnly = in_array($action, ['dashboard','users','user_detail','missions','audit','health','app_settings','app_dashboard','tutorial_categories','tutorials','tutorial_detail','sliders','news_admin','news_detail_admin'], true);
require_admin(!$readOnly);

if ($action === 'dashboard') {
    $now = time();
    $today = tehran_date('Y-m-d', $now);
    $yesterday = tehran_date('Y-m-d', $now - 86400);
    $month = tehran_date('Y-m', $now);
    $online = $todayCount = $yesterdayCount = $weekCount = $monthCount = 0;
    $users = all_users();
    foreach ($users as $u) {
        $last = (int)($u['lastSeen'] ?? 0);
        if ($last >= $now - ONLINE_WINDOW_SECONDS) $online++;
        if ($last > 0) {
            $d = tehran_date('Y-m-d', $last);
            if ($d === $today) $todayCount++;
            if ($d === $yesterday) $yesterdayCount++;
            if ($last >= $now - 7 * 86400) $weekCount++;
            if (tehran_date('Y-m', $last) === $month) $monthCount++;
        }
    }
    out([
        'ok' => true,
        'stats' => [
            'onlineNow' => $online,
            'activeToday' => $todayCount,
            'activeYesterday' => $yesterdayCount,
            'activeWeek' => $weekCount,
            'activeMonth' => $monthCount,
            'totalUsers' => count($users),
        ],
        'missionCount' => count(array_filter(missions_config(false)['missions'], fn($m) => !empty($m['active']))),
        'serverTime' => now_iso(),
    ]);
}

if ($action === 'users') {
    $q = clean_text((string)($in['q'] ?? ''), 100);
    $sort = (string)($in['sort'] ?? 'last_seen_desc');
    $league = preg_replace('/[^A-Za-z]/','',(string)($in['league'] ?? '')) ?: '';
    $activity = (string)($in['activity'] ?? 'all');
    $referrals = (string)($in['referrals'] ?? 'all');
    $status = (string)($in['status'] ?? 'all');
    $inactiveDays = max(1,min(3650,(int)($in['inactiveDays'] ?? 30)));
    $page = max(1,(int)($in['page'] ?? 1));
    $perPage = max(10,min(100,(int)($in['perPage'] ?? 25)));
    $registeredFrom = trim((string)($in['registeredFrom'] ?? ''));
    $registeredTo = trim((string)($in['registeredTo'] ?? ''));
    $fromTs = $registeredFrom !== '' ? strtotime($registeredFrom.' 00:00:00 Asia/Tehran') : false;
    $toTs = $registeredTo !== '' ? strtotime($registeredTo.' 23:59:59 Asia/Tehran') : false;
    $allowedSorts=['last_seen_desc','last_seen_asc','coins_desc','coins_asc','registered_desc','registered_asc','referrals_desc','referrals_asc','name_asc','name_desc'];
    if(!in_array($sort,$allowedSorts,true))$sort='last_seen_desc';
    if(!in_array($activity,['all','online','today','yesterday','week','month','inactive'],true))$activity='all';
    if(!in_array($referrals,['all','has','none'],true))$referrals='all';
    if(!in_array($status,['all','active','suspended'],true))$status='all';

    $all=all_users(); $refCounts=[];
    foreach($all as $raw){$parent=clean_email((string)($raw['referredByEmail']??''));if($parent!=='')$refCounts[$parent]=($refCounts[$parent]??0)+1;}
    $cupIndex=[];foreach(cups_config() as $i=>$c)$cupIndex[$c['name']]=$i;
    $rows=[];$now=time();$today=tehran_date('Y-m-d',$now);$yesterday=tehran_date('Y-m-d',$now-86400);$month=tehran_date('Y-m',$now);
    foreach($all as $u){
        $p=public_user($u);$email=clean_email((string)($p['email']??''));$g=normalize_game(is_array($u['game']??null)?$u['game']:[]);$cup=cup_for_coins((float)$g['coins']);
        $lastSeen=(int)($u['lastSeen']??0);$createdRaw=$u['createdAt']??null;$createdTs=$createdRaw?strtotime((string)$createdRaw):0;$refCode=clean_referral_code((string)($u['referralCode']??''));if($refCode==='')$refCode=referral_code_candidate($u);
        $count=(int)($refCounts[$email]??0);$suspended=(bool)($u['suspended']??false);
        $hay=strtolower($email.' '.($p['username']??'').' '.($p['displayName']??'').' '.($p['userId']??'').' '.$refCode);
        if($q!==''&&!str_contains($hay,strtolower($q)))continue;
        if($league!==''&&$cup['name']!==$league)continue;
        if($status==='active'&&$suspended)continue;if($status==='suspended'&&!$suspended)continue;
        if($referrals==='has'&&$count<=0)continue;if($referrals==='none'&&$count>0)continue;
        if($fromTs!==false&&$createdTs<$fromTs)continue;if($toTs!==false&&$createdTs>$toTs)continue;
        $lastDate=$lastSeen>0?tehran_date('Y-m-d',$lastSeen):'';
        if($activity==='online'&&$lastSeen<$now-ONLINE_WINDOW_SECONDS)continue;
        if($activity==='today'&&$lastDate!==$today)continue;
        if($activity==='yesterday'&&$lastDate!==$yesterday)continue;
        if($activity==='week'&&$lastSeen<$now-7*86400)continue;
        if($activity==='month'&&($lastSeen<=0||tehran_date('Y-m',$lastSeen)!==$month))continue;
        if($activity==='inactive'&&$lastSeen>=$now-$inactiveDays*86400)continue;
        $rows[]=['email'=>$email,'username'=>$p['username'],'displayName'=>$p['displayName'],'userId'=>$p['userId'],'referralCode'=>$refCode,'referralCount'=>$count,'coins'=>(float)$g['coins'],'league'=>$cup['fa'],'leagueCode'=>$cup['name'],'leagueIndex'=>$cupIndex[$cup['name']]??0,'lastSeen'=>$lastSeen,'online'=>$lastSeen>=$now-ONLINE_WINDOW_SECONDS,'createdAt'=>$createdRaw,'createdTs'=>$createdTs,'suspended'=>$suspended];
    }
    usort($rows,function($a,$b)use($sort){
        return match($sort){
            'last_seen_asc'=>($a['lastSeen']<=>$b['lastSeen'])?:strcmp((string)$a['displayName'],(string)$b['displayName']),
            'coins_desc'=>($b['coins']<=>$a['coins'])?:strcmp((string)$a['userId'],(string)$b['userId']),
            'coins_asc'=>($a['coins']<=>$b['coins'])?:strcmp((string)$a['userId'],(string)$b['userId']),
            'registered_desc'=>($b['createdTs']<=>$a['createdTs'])?:strcmp((string)$a['userId'],(string)$b['userId']),
            'registered_asc'=>($a['createdTs']<=>$b['createdTs'])?:strcmp((string)$a['userId'],(string)$b['userId']),
            'referrals_desc'=>($b['referralCount']<=>$a['referralCount'])?:($b['coins']<=>$a['coins']),
            'referrals_asc'=>($a['referralCount']<=>$b['referralCount'])?:($b['coins']<=>$a['coins']),
            'name_desc'=>strcmp((string)$b['displayName'],(string)$a['displayName']),
            'name_asc'=>strcmp((string)$a['displayName'],(string)$b['displayName']),
            default=>($b['lastSeen']<=>$a['lastSeen'])?:strcmp((string)$a['displayName'],(string)$b['displayName']),
        };
    });
    $total=count($rows);$pages=max(1,(int)ceil($total/$perPage));if($page>$pages)$page=$pages;$offset=($page-1)*$perPage;
    $pageRows=array_slice($rows,$offset,$perPage);foreach($pageRows as &$r)unset($r['createdTs'],$r['leagueIndex']);unset($r);
    out(['ok'=>true,'users'=>$pageRows,'pagination'=>['total'=>$total,'page'=>$page,'perPage'=>$perPage,'pages'=>$pages]]);
}

if ($action === 'guest_cleanup') {
    $inactiveHours = max(1,min(720,(int)($in['inactiveHours'] ?? 24)));
    $cutoff = time() - ($inactiveHours * 3600);
    $all = all_users();
    $referredChildren = [];
    foreach ($all as $raw) {
        $parent = clean_email((string)($raw['referredByEmail'] ?? ''));
        if ($parent !== '') $referredChildren[$parent] = ($referredChildren[$parent] ?? 0) + 1;
    }
    $deleted = 0;
    foreach ($all as $guest) {
        if (!is_guest_user($guest)) continue;
        $email = clean_email((string)($guest['email'] ?? ''));
        if ($email === '' || (int)($guest['lastSeen'] ?? 0) >= $cutoff) continue;
        if (!empty($guest['referredByEmail']) || !empty($referredChildren[$email])) continue;
        $game = normalize_game(is_array($guest['game'] ?? null) ? $guest['game'] : []);
        $missionProgress = false;
        foreach (($game['missionLevels'] ?? []) as $level) { if ((int)$level > 0) { $missionProgress = true; break; } }
        $meaningful = (float)$game['coins'] > 0.001
            || (int)$game['taps'] > 0
            || (float)$game['hourlyIncome'] > 0.001
            || (int)$game['tapLevel'] > 1
            || (int)$game['energyLevel'] > 1
            || (int)$game['rechargeLevel'] > 1
            || (int)$game['instantEnergyUsed'] > 0
            || (int)$game['turboUsed'] > 0
            || $missionProgress;
        if ($meaningful) continue;
        delete_tokens_for_email($email);
        delete_guest_user($guest);
        $deleted++;
    }
    append_audit('guest_cleanup',['inactiveHours'=>$inactiveHours,'deleted'=>$deleted]);
    out(['ok'=>true,'deleted'=>$deleted,'inactiveHours'=>$inactiveHours]);
}

if ($action === 'user_detail') {
    $email = clean_email((string)($in['email'] ?? ''));
    $user = find_user_by_email($email);
    if (!$user) out(['ok'=>false,'error'=>'کاربر پیدا نشد'],404);
    $user = ensure_referral_code($user, true);
    $game = settle_game(is_array($user['game']??null)?$user['game']:[]); unset($game['_passiveEarned']);
    $cup = cup_for_coins((float)$game['coins']);
    $ref = referral_summary($user);
    out(['ok'=>true,'user'=>[
        'email'=>$email,'displayName'=>$user['displayName']??$user['username']??'بازیکن','username'=>$user['username']??'',
        'userId'=>$user['userId']??null,'createdAt'=>$user['createdAt']??null,'updatedAt'=>$user['updatedAt']??null,
        'lastSeen'=>(int)($user['lastSeen']??0),'lastLogin'=>(int)($user['lastLogin']??0),'suspended'=>(bool)($user['suspended']??false),
        'coins'=>(float)$game['coins'],'league'=>$cup['fa'],'leagueCode'=>$cup['name'],'energy'=>(float)$game['energy'],'maxEnergy'=>(int)$game['maxEnergy'],
        'power'=>(int)$game['power'],'taps'=>(int)$game['taps'],'hourlyIncome'=>(float)$game['hourlyIncome'],
        'tapLevel'=>(int)$game['tapLevel'],'energyLevel'=>(int)$game['energyLevel'],'rechargeLevel'=>(int)$game['rechargeLevel'],
        'missionLevels'=>$game['missionLevels']??[],'referral'=>$ref,'adminCoinHistory'=>admin_coin_history($email,100),
    ]]);
}

if ($action === 'user_coin_adjust') {
    $email = clean_email((string)($in['email'] ?? ''));
    $operation = (string)($in['operation'] ?? 'add');
    $amount = round((float)($in['amount'] ?? 0));
    $reason = clean_text((string)($in['reason'] ?? ''), 160);
    if (!in_array($operation,['add','subtract'],true)) out(['ok'=>false,'error'=>'نوع عملیات نامعتبر است'],422);
    if ($amount <= 0 || $amount > 1.0e15) out(['ok'=>false,'error'=>'مقدار سکه معتبر نیست'],422);
    if (u_strlen($reason) < 3) out(['ok'=>false,'error'=>'دلیل تغییر سکه را وارد کن'],422);
    $result = with_referral_lock(function() use($email,$operation,$amount,$reason): array {
        $user = find_user_by_email($email);
        if (!$user) out(['ok'=>false,'error'=>'کاربر پیدا نشد'],404);
        $game = settle_game(is_array($user['game']??null)?$user['game']:[]); unset($game['_passiveEarned']);
        $before = (float)$game['coins'];
        if ($operation === 'subtract' && $amount > $before) out(['ok'=>false,'error'=>'موجودی کاربر برای این کاهش کافی نیست'],409);
        $after = $operation === 'add' ? $before + $amount : $before - $amount;
        $game['coins'] = max(0,$after); $game['scoreReachedAt']=time(); $game = normalize_game($game); $user['game']=$game; save_user($user);
        $event=['id'=>'admin:'.bin2hex(random_bytes(8)),'operation'=>$operation,'amount'=>$amount,'reason'=>$reason,'before'=>$before,'after'=>(float)$game['coins'],'admin'=>$_SESSION['admin_user']??'admin','time'=>now_iso()];
        append_jsonl(admin_coin_history_file($email),$event);
        append_audit('user_coin_adjust',['email'=>$email,'operation'=>$operation,'amount'=>$amount,'reason'=>$reason,'before'=>$before,'after'=>$game['coins']]);
        return $event;
    });
    if ($operation === 'add') award_pending_referral_leagues($email);
    out(['ok'=>true,'event'=>$result]);
}

if ($action === 'user_status') {
    $email = clean_email((string)($in['email'] ?? ''));
    $suspended = (bool)($in['suspended'] ?? false);
    $user = find_user_by_email($email);
    if (!$user) out(['ok' => false, 'error' => 'کاربر پیدا نشد'], 404);
    $user['suspended'] = $suspended;
    save_user($user);
    append_audit('user_status', ['email' => $email, 'suspended' => $suspended]);
    out(['ok' => true]);
}

if ($action === 'missions') {
    out(['ok' => true, 'data' => missions_config(true)]);
}

if ($action === 'category_save') {
    $config = missions_config(true);
    $categories = $config['categories'];
    $id = safe_id((string)($in['id'] ?? ''));
    $name = clean_text((string)($in['name'] ?? ''), 50);
    $active = (bool)($in['active'] ?? true);
    $sortOrder = max(-9999, min(9999, (int)($in['sortOrder'] ?? 0)));
    if ($name === '') out(['ok'=>false,'error'=>'نام دسته‌بندی الزامی است'],422);
    foreach ($categories as $category) {
        if (empty($category['deleted']) && ($category['id'] ?? '') !== $id && trim((string)($category['name'] ?? '')) === $name) {
            out(['ok'=>false,'error'=>'دسته‌بندی با این نام قبلاً ساخته شده است'],409);
        }
    }
    if ($id === '') $id = 'category-' . bin2hex(random_bytes(5));
    $found = false;
    foreach ($categories as &$category) {
        if (($category['id'] ?? '') === $id) {
            $category = array_merge($category, ['id'=>$id,'name'=>$name,'active'=>$active,'deleted'=>false,'sortOrder'=>$sortOrder,'updatedAt'=>now_iso()]);
            $found = true; break;
        }
    }
    unset($category);
    if (!$found) $categories[] = ['id'=>$id,'name'=>$name,'active'=>$active,'deleted'=>false,'sortOrder'=>$sortOrder,'createdAt'=>now_iso(),'updatedAt'=>now_iso()];
    save_missions($config['missions'], $categories);
    append_audit('category_save',['id'=>$id,'name'=>$name]);
    out(['ok'=>true,'categoryId'=>$id]);
}

if ($action === 'category_toggle') {
    $config = missions_config(true);
    $categories = $config['categories'];
    $id = safe_id((string)($in['id'] ?? ''));
    $active = (bool)($in['active'] ?? false);
    $found = false;
    foreach ($categories as &$category) {
        if (($category['id'] ?? '') === $id && empty($category['deleted'])) { $category['active']=$active; $category['updatedAt']=now_iso(); $found=true; break; }
    }
    unset($category);
    if (!$found) out(['ok'=>false,'error'=>'دسته‌بندی پیدا نشد'],404);
    save_missions($config['missions'], $categories);
    append_audit('category_toggle',['id'=>$id,'active'=>$active]);
    out(['ok'=>true]);
}

if ($action === 'category_delete') {
    $config = missions_config(true);
    $categories = $config['categories'];
    $missions = $config['missions'];
    $id = safe_id((string)($in['id'] ?? ''));
    $transfer = safe_id((string)($in['transferCategory'] ?? ''));
    $force = (bool)($in['force'] ?? false);
    $found = false;
    foreach ($categories as $category) if (($category['id'] ?? '') === $id && empty($category['deleted'])) { $found=true; break; }
    if (!$found) out(['ok'=>false,'error'=>'دسته‌بندی پیدا نشد'],404);
    if ($transfer === $id) out(['ok'=>false,'error'=>'دسته مقصد باید با دسته حذف‌شونده متفاوت باشد'],422);
    if ($transfer !== '') {
        $target = null;
        foreach ($categories as $category) if (($category['id'] ?? '') === $transfer && empty($category['deleted'])) { $target=$category; break; }
        if (!$target) out(['ok'=>false,'error'=>'دسته‌بندی مقصد معتبر نیست'],422);
    }
    $used = 0;
    foreach ($missions as $mission) if (empty($mission['deleted']) && ($mission['category'] ?? '') === $id) $used++;
    if ($used > 0 && $transfer === '' && !$force) out(['ok'=>false,'error'=>'این دسته‌بندی دارای مأموریت است؛ ابتدا مقصد انتقال را انتخاب کنید','missionCount'=>$used],409);
    foreach ($missions as &$mission) if (($mission['category'] ?? '') === $id) { $mission['category']=$transfer; $mission['updatedAt']=now_iso(); }
    unset($mission);
    foreach ($categories as &$category) if (($category['id'] ?? '') === $id) { $category['active']=false; $category['deleted']=true; $category['updatedAt']=now_iso(); break; }
    unset($category);
    save_missions($missions, $categories);
    append_audit('category_delete',['id'=>$id,'missionCount'=>$used,'transferCategory'=>$transfer,'forced'=>$force]);
    out(['ok'=>true,'moved'=>$used]);
}

if ($action === 'mission_save') {
    $rawId = (string)($in['id'] ?? '');
    $id = safe_id($rawId);
    if ($id === '') $id = 'mission-' . bin2hex(random_bytes(5));
    $title = clean_text((string)($in['title'] ?? ''), 80);
    $description = clean_text((string)($in['description'] ?? ''), 220);
    $category = safe_id((string)($in['category'] ?? ''));
    if ($category !== '') {
        $categoryRow = mission_category_by_id($category, true);
        if (!$categoryRow || !empty($categoryRow['deleted'])) out(['ok'=>false,'error'=>'دسته‌بندی انتخاب‌شده معتبر نیست'],422);
    }
    $image = trim((string)($in['image'] ?? ''));
    $active = (bool)($in['active'] ?? true);
    $sortOrder = max(-9999, min(9999, (int)($in['sortOrder'] ?? 0)));
    $levelsIn = is_array($in['levels'] ?? null) ? $in['levels'] : [];
    if ($title === '') out(['ok' => false, 'error' => 'عنوان مأموریت الزامی است'], 422);
    if (!$levelsIn || count($levelsIn) > 50) out(['ok' => false, 'error' => 'حداقل یک سطح و حداکثر ۵۰ سطح مجاز است'], 422);
    $levels = [];
    $cumulativeIncome = 0.0;
    foreach ($levelsIn as $index => $row) {
        if (!is_array($row)) continue;
        $increment = max(0, min((float)($row['profitIncrement'] ?? $row['hourlyIncome'] ?? 0), 1.0e15));
        $cumulativeIncome += $increment;
        $levels[] = [
            'level' => $index + 1,
            'upgradeCost' => max(0, min((float)($row['upgradeCost'] ?? 0), 1.0e15)),
            'profitIncrement' => $increment,
            'hourlyIncome' => $increment,
            'cumulativeIncome' => $cumulativeIncome,
        ];
    }
    if (!$levels) out(['ok' => false, 'error' => 'سطح‌های مأموریت معتبر نیست'], 422);
    $all = missions_config(true)['missions'];
    $found = false;
    foreach ($all as &$m) {
        if (($m['id'] ?? '') === $id) {
            $found = true;
            $m = array_merge($m, [
                'id' => $id, 'title' => $title, 'description' => $description,
                'category' => $category, 'image' => $image !== '' ? $image : ($m['image'] ?? ''),
                'active' => $active, 'deleted' => false, 'sortOrder' => $sortOrder,
                'maxLevel' => count($levels), 'levels' => $levels, 'updatedAt' => now_iso(),
            ]);
            break;
        }
    }
    unset($m);
    if (!$found) {
        $all[] = [
            'id' => $id, 'title' => $title, 'description' => $description,
            'category' => $category, 'image' => $image, 'active' => $active,
            'deleted' => false, 'sortOrder' => $sortOrder, 'maxLevel' => count($levels),
            'levels' => $levels, 'createdAt' => now_iso(), 'updatedAt' => now_iso(),
        ];
    }
    save_missions($all);
    append_audit('mission_save', ['id' => $id, 'levels' => count($levels)]);
    out(['ok' => true, 'missionId' => $id]);
}

if ($action === 'mission_toggle') {
    $id = safe_id((string)($in['id'] ?? ''));
    $active = (bool)($in['active'] ?? false);
    $all = missions_config(true)['missions'];
    $found = false;
    foreach ($all as &$m) {
        if (($m['id'] ?? '') === $id) { $m['active'] = $active; $m['updatedAt'] = now_iso(); $found = true; break; }
    }
    unset($m);
    if (!$found) out(['ok' => false, 'error' => 'مأموریت پیدا نشد'], 404);
    save_missions($all);
    append_audit('mission_toggle', ['id' => $id, 'active' => $active]);
    out(['ok' => true]);
}

if ($action === 'mission_delete') {
    $id = safe_id((string)($in['id'] ?? ''));
    $all = missions_config(true)['missions'];
    $found = false;
    foreach ($all as &$m) {
        if (($m['id'] ?? '') === $id) { $m['active'] = false; $m['deleted'] = true; $m['updatedAt'] = now_iso(); $found = true; break; }
    }
    unset($m);
    if (!$found) out(['ok' => false, 'error' => 'مأموریت پیدا نشد'], 404);
    save_missions($all);
    append_audit('mission_delete', ['id' => $id]);
    out(['ok' => true]);
}



// ===== Native education app CMS v34 =====
if ($action === 'app_settings') out(['ok'=>true,'config'=>app_config()]);
if ($action === 'app_settings_save') {
    $cfg=['defaultTab'=>'tutorials','gameStatus'=>'coming_soon','comingSoonTitle'=>'','comingSoonText'=>''];
    save_app_config($cfg);out(['ok'=>true,'config'=>app_config()]);
}
if ($action === 'app_dashboard') {
    ensure_real_views_baseline();
    $tc=tutorials_config(true);$ac=app_content(true);$a=app_analytics_stats();
    out(['ok'=>true,'stats'=>array_merge([
        'tutorials'=>count(array_filter($tc['tutorials'],fn($x)=>empty($x['deleted'])&&!empty($x['active']))),
        'categories'=>count(array_filter($tc['categories'],fn($x)=>empty($x['deleted'])&&!empty($x['active'])&&empty($x['parentId']))),
        'sliders'=>count(array_filter($ac['sliders'],fn($x)=>empty($x['deleted'])&&!empty($x['active']))),
        'news'=>count(array_filter($ac['news'],fn($x)=>empty($x['deleted'])&&!empty($x['active']))),
        'tutorialViews'=>array_sum(array_map(fn($x)=>(int)($x['views']??0),$tc['tutorials'])),
        'newsViews'=>array_sum(array_map(fn($x)=>(int)($x['views']??0),$ac['news'])),
    ],$a)]);
}
if ($action === 'tutorial_categories') out(['ok'=>true,'categories'=>tutorials_config(true)['categories']]);
if ($action === 'tutorial_category_save') {
    $cfg=tutorials_config(true);$cats=$cfg['categories'];$id=safe_id((string)($in['id']??''));$name=clean_text((string)($in['name']??''),70);$icon=u_substr(trim((string)($in['icon']??'📘')),0,6);$parent=safe_id((string)($in['parentId']??''));$active=(bool)($in['active']??true);$sort=max(-9999,min(9999,(int)($in['sortOrder']??0)));$description=clean_text((string)($in['description']??''),220);$image=trim((string)($in['image']??''));
    if($name==='')out(['ok'=>false,'error'=>'نام دسته‌بندی الزامی است'],422);if($id==='')$id='tutorial-category-'.bin2hex(random_bytes(5));$found=false;
    foreach($cats as &$c)if(($c['id']??'')===$id){$c=array_merge($c,['id'=>$id,'name'=>$name,'icon'=>$icon,'parentId'=>$parent,'description'=>$description,'image'=>$image,'active'=>$active,'deleted'=>false,'sortOrder'=>$sort,'updatedAt'=>now_iso()]);$found=true;break;}unset($c);
    if(!$found)$cats[]=['id'=>$id,'name'=>$name,'icon'=>$icon,'parentId'=>$parent,'description'=>$description,'image'=>$image,'active'=>$active,'deleted'=>false,'sortOrder'=>$sort,'createdAt'=>now_iso(),'updatedAt'=>now_iso()];save_tutorials($cfg['tutorials'],$cats);append_audit('tutorial_category_save',['id'=>$id]);out(['ok'=>true,'id'=>$id]);
}
if ($action === 'tutorial_category_toggle') {$cfg=tutorials_config(true);$cats=$cfg['categories'];$id=safe_id((string)($in['id']??''));$active=(bool)($in['active']??false);$found=false;foreach($cats as &$c)if(($c['id']??'')===$id){$c['active']=$active;$c['updatedAt']=now_iso();$found=true;break;}unset($c);if(!$found)out(['ok'=>false,'error'=>'دسته‌بندی پیدا نشد'],404);save_tutorials($cfg['tutorials'],$cats);out(['ok'=>true]);}
if ($action === 'tutorial_category_delete') {$cfg=tutorials_config(true);$cats=$cfg['categories'];$items=$cfg['tutorials'];$id=safe_id((string)($in['id']??''));$found=false;foreach($cats as &$c)if(($c['id']??'')===$id){$c['deleted']=true;$c['active']=false;$c['updatedAt']=now_iso();$found=true;break;}unset($c);if(!$found)out(['ok'=>false,'error'=>'دسته‌بندی پیدا نشد'],404);save_tutorials($items,$cats);append_audit('tutorial_category_delete',['id'=>$id]);out(['ok'=>true]);}
if ($action === 'tutorials') {$cfg=tutorials_config(true);out(['ok'=>true,'tutorials'=>$cfg['tutorials'],'categories'=>$cfg['categories']]);}
if ($action === 'tutorial_detail') {$id=safe_id((string)($in['id']??''));$t=tutorial_by_id($id,true);if(!$t)out(['ok'=>false,'error'=>'آموزش پیدا نشد'],404);out(['ok'=>true,'tutorial'=>$t]);}
if ($action === 'tutorial_save') {
    $cfg=tutorials_config(true);$items=$cfg['tutorials'];$id=safe_id((string)($in['id']??''));if($id==='')$id='tutorial-'.bin2hex(random_bytes(6));$title=clean_text((string)($in['title']??''),120);if($title==='')out(['ok'=>false,'error'=>'عنوان آموزش الزامی است'],422);
    $old=null;foreach($items as $x)if(($x['id']??'')===$id){$old=$x;break;}
    $row=['id'=>$id,'title'=>$title,'summary'=>clean_text((string)($in['summary']??''),280),'body'=>trim((string)($in['body']??'')),'categoryId'=>safe_id((string)($in['categoryId']??'faq')),'cover'=>trim((string)($in['cover']??'')),'videoUrl'=>trim((string)($in['videoUrl']??'')),'sourceUrl'=>trim((string)($in['sourceUrl']??'')),'sourceTitle'=>clean_text((string)($in['sourceTitle']??''),80),'level'=>(string)($in['level']??'مبتدی'),'duration'=>(int)($in['duration']??0),'tags'=>is_array($in['tags']??null)?$in['tags']:array_filter(array_map('trim',explode(',',(string)($in['tags']??'')))),'featured'=>(bool)($in['featured']??false),'active'=>(bool)($in['active']??true),'deleted'=>false,'views'=>(int)($old['views']??0),'sortOrder'=>(int)($in['sortOrder']??0),'updatedAt'=>now_iso()];$row=normalize_tutorial($row);
    $found=false;foreach($items as &$t)if(($t['id']??'')===$id){$row['createdAt']=$t['createdAt']??now_iso();$t=array_merge($t,$row);$found=true;break;}unset($t);if(!$found){$row['createdAt']=now_iso();$items[]=$row;}save_tutorials($items,$cfg['categories']);append_audit('tutorial_save',['id'=>$id,'title'=>$title]);out(['ok'=>true,'id'=>$id]);
}
if ($action === 'tutorial_toggle') {$cfg=tutorials_config(true);$items=$cfg['tutorials'];$id=safe_id((string)($in['id']??''));$active=(bool)($in['active']??false);$found=false;foreach($items as &$t)if(($t['id']??'')===$id){$t['active']=$active;$t['updatedAt']=now_iso();$found=true;break;}unset($t);if(!$found)out(['ok'=>false,'error'=>'آموزش پیدا نشد'],404);save_tutorials($items,$cfg['categories']);out(['ok'=>true]);}
if ($action === 'tutorial_delete') {$cfg=tutorials_config(true);$items=$cfg['tutorials'];$id=safe_id((string)($in['id']??''));$found=false;foreach($items as &$t)if(($t['id']??'')===$id){$t['deleted']=true;$t['active']=false;$t['updatedAt']=now_iso();$found=true;break;}unset($t);if(!$found)out(['ok'=>false,'error'=>'آموزش پیدا نشد'],404);save_tutorials($items,$cfg['categories']);append_audit('tutorial_delete',['id'=>$id]);out(['ok'=>true]);}

if ($action === 'sliders') out(['ok'=>true,'sliders'=>app_content(true)['sliders']]);
if ($action === 'slider_save') {
    $cfg=app_content(true);$rows=$cfg['sliders'];$id=safe_id((string)($in['id']??''));if($id==='')$id='slide-'.bin2hex(random_bytes(5));$row=normalize_slider(['id'=>$id,'title'=>$in['title']??'','subtitle'=>$in['subtitle']??'','kicker'=>$in['kicker']??'','buttonText'=>$in['buttonText']??'مشاهده','icon'=>$in['icon']??'🎓','image'=>$in['image']??'','targetType'=>$in['targetType']??'category','targetValue'=>$in['targetValue']??'','active'=>(bool)($in['active']??true),'deleted'=>false,'sortOrder'=>(int)($in['sortOrder']??0),'updatedAt'=>now_iso()]);if(trim((string)$row['image'])==='')out(['ok'=>false,'error'=>'تصویر اسلاید الزامی است'],422);$found=false;foreach($rows as &$x)if(($x['id']??'')===$id){$row['createdAt']=$x['createdAt']??now_iso();$x=array_merge($x,$row);$found=true;break;}unset($x);if(!$found){$row['createdAt']=now_iso();$rows[]=$row;}save_app_content($rows,$cfg['news']);append_audit('slider_save',['id'=>$id]);out(['ok'=>true,'id'=>$id]);
}
if ($action === 'slider_toggle') {$cfg=app_content(true);$rows=$cfg['sliders'];$id=safe_id((string)($in['id']??''));$active=(bool)($in['active']??false);$found=false;foreach($rows as &$x)if(($x['id']??'')===$id){$x['active']=$active;$x['updatedAt']=now_iso();$found=true;break;}unset($x);if(!$found)out(['ok'=>false,'error'=>'اسلاید پیدا نشد'],404);save_app_content($rows,$cfg['news']);out(['ok'=>true]);}
if ($action === 'slider_delete') {$cfg=app_content(true);$rows=$cfg['sliders'];$id=safe_id((string)($in['id']??''));$found=false;foreach($rows as &$x)if(($x['id']??'')===$id){$x['deleted']=true;$x['active']=false;$x['updatedAt']=now_iso();$found=true;break;}unset($x);if(!$found)out(['ok'=>false,'error'=>'اسلاید پیدا نشد'],404);save_app_content($rows,$cfg['news']);append_audit('slider_delete',['id'=>$id]);out(['ok'=>true]);}

if ($action === 'news_admin') out(['ok'=>true,'news'=>app_content(true)['news']]);
if ($action === 'news_detail_admin') {$id=safe_id((string)($in['id']??''));$n=news_by_id($id,true);if(!$n)out(['ok'=>false,'error'=>'خبر پیدا نشد'],404);out(['ok'=>true,'news'=>$n]);}
if ($action === 'news_save') {
    $cfg=app_content(true);$rows=$cfg['news'];$id=safe_id((string)($in['id']??''));if($id==='')$id='news-'.bin2hex(random_bytes(6));$old=null;foreach($rows as $x)if(($x['id']??'')===$id){$old=$x;break;}$row=normalize_news(['id'=>$id,'title'=>$in['title']??'','summary'=>$in['summary']??'','body'=>$in['body']??'','cover'=>$in['cover']??'','sourceTitle'=>$in['sourceTitle']??'','sourceUrl'=>$in['sourceUrl']??'','publishedAt'=>$in['publishedAt']??date('Y-m-d'),'views'=>(int)($old['views']??0),'active'=>(bool)($in['active']??true),'deleted'=>false,'sortOrder'=>(int)($in['sortOrder']??0),'updatedAt'=>now_iso()]);if($row['title']==='')out(['ok'=>false,'error'=>'عنوان خبر الزامی است'],422);$found=false;foreach($rows as &$x)if(($x['id']??'')===$id){$row['createdAt']=$x['createdAt']??now_iso();$x=array_merge($x,$row);$found=true;break;}unset($x);if(!$found){$row['createdAt']=now_iso();$rows[]=$row;}save_app_content($cfg['sliders'],$rows);append_audit('news_save',['id'=>$id]);out(['ok'=>true,'id'=>$id]);
}
if ($action === 'news_toggle') {$cfg=app_content(true);$rows=$cfg['news'];$id=safe_id((string)($in['id']??''));$active=(bool)($in['active']??false);$found=false;foreach($rows as &$x)if(($x['id']??'')===$id){$x['active']=$active;$x['updatedAt']=now_iso();$found=true;break;}unset($x);if(!$found)out(['ok'=>false,'error'=>'خبر پیدا نشد'],404);save_app_content($cfg['sliders'],$rows);out(['ok'=>true]);}
if ($action === 'news_delete') {$cfg=app_content(true);$rows=$cfg['news'];$id=safe_id((string)($in['id']??''));$found=false;foreach($rows as &$x)if(($x['id']??'')===$id){$x['deleted']=true;$x['active']=false;$x['updatedAt']=now_iso();$found=true;break;}unset($x);if(!$found)out(['ok'=>false,'error'=>'خبر پیدا نشد'],404);save_app_content($cfg['sliders'],$rows);append_audit('news_delete',['id'=>$id]);out(['ok'=>true]);}

if ($action === 'change_password') {
    $cfg = admin_config();
    $current = (string)($in['currentPassword'] ?? '');
    $new = (string)($in['newPassword'] ?? '');
    $confirm = (string)($in['confirmPassword'] ?? '');
    if (!password_verify($current, (string)$cfg['passwordHash'])) out(['ok' => false, 'error' => 'رمز فعلی اشتباه است'], 422);
    if (strlen($new) < 10) out(['ok' => false, 'error' => 'رمز جدید باید حداقل ۱۰ کاراکتر باشد'], 422);
    if ($new !== $confirm) out(['ok' => false, 'error' => 'رمز جدید و تکرار آن یکسان نیست'], 422);
    $cfg['passwordHash'] = password_hash($new, PASSWORD_DEFAULT);
    $cfg['updatedAt'] = now_iso();
    write_json_file(admin_file(), $cfg);
    append_audit('password_changed');
    out(['ok' => true]);
}

if ($action === 'audit') {
    $lines = is_file(audit_file()) ? file(audit_file(), FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];
    $rows = [];
    foreach (array_slice(array_reverse($lines ?: []), 0, 100) as $line) {
        $row = json_decode($line, true);
        if (is_array($row)) $rows[] = $row;
    }
    out(['ok' => true, 'rows' => $rows]);
}

if ($action === 'health') {
    out([
        'ok' => true,
        'php' => PHP_VERSION,
        'dataWritable' => is_writable(DATA_DIR),
        'uploadWritable' => is_writable(UPLOAD_DIR),
        'userFiles' => count(all_users()),
        'missionFiles' => count(missions_config(false)['missions']),
        'serverTime' => now_iso(),
    ]);
}

out(['ok' => false, 'error' => 'unknown_action'], 400);
