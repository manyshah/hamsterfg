<?php
require __DIR__ . '/_lib.php';
$in=json_input();$action=$_GET['action']??($in['action']??'config');
ensure_real_views_baseline();

function content_version_now(): string {
    $tc=tutorials_config(false);$ac=app_content(false);
    return sha1((string)($tc['updatedAt']??'').'|'.(string)($ac['updatedAt']??''));
}

if($action==='config')out(['ok'=>true,'config'=>app_config(),'serverTime'=>time(),'apiVersion'=>3,'contentVersion'=>content_version_now()]);

if($action==='bootstrap'){
    $tc=tutorials_config(false);$ac=app_content(false);
    $cats=array_values(array_filter($tc['categories'],fn($c)=>!empty($c['active'])&&empty($c['deleted'])));
    $tuts=array_values(array_filter($tc['tutorials'],fn($t)=>!empty($t['active'])&&empty($t['deleted'])));
    $sliders=array_values(array_filter($ac['sliders'],fn($s)=>!empty($s['active'])&&empty($s['deleted'])&&trim((string)($s['image']??''))!==''));
    usort($sliders,fn($a,$b)=>(int)($a['sortOrder']??0)<=>(int)($b['sortOrder']??0));
    out(['ok'=>true,'categories'=>$cats,'tutorials'=>$tuts,'sliders'=>$sliders,'contentVersion'=>content_version_now(),'serverTime'=>time()]);
}

if($action==='home'){
    $tc=tutorials_config(false);$ac=app_content(false);
    $cats=array_values(array_filter($tc['categories'],fn($c)=>!empty($c['active'])&&empty($c['parentId'])));
    $popular=array_values(array_filter($tc['tutorials'],fn($t)=>!empty($t['active'])));
    usort($popular,function($a,$b){$as=(int)($a['views']??0)+(empty($a['featured'])?0:100000);$bs=(int)($b['views']??0)+(empty($b['featured'])?0:100000);return $bs<=>$as;});
    $popular=array_slice($popular,0,8);$popular=array_map(function($t){unset($t['body']);return $t;},$popular);
    $news=array_values(array_filter($ac['news'],fn($n)=>!empty($n['active'])));
    usort($news,fn($a,$b)=>strcmp((string)($b['publishedAt']??''),(string)($a['publishedAt']??''))?:((int)($a['sortOrder']??0)<=>(int)($b['sortOrder']??0)));
    $news=array_slice($news,0,6);$news=array_map(function($n){unset($n['body']);return $n;},$news);
    $sliders=array_values(array_filter($ac['sliders'],fn($s)=>!empty($s['active'])&&trim((string)($s['image']??''))!==''));
    out(['ok'=>true,'sliders'=>$sliders,'categories'=>$cats,'popular'=>$popular,'news'=>$news,'contentVersion'=>content_version_now()]);
}

if($action==='categories'){
    $cfg=tutorials_config(false);$cats=array_values(array_filter($cfg['categories'],fn($c)=>!empty($c['active'])));
    out(['ok'=>true,'categories'=>$cats,'contentVersion'=>content_version_now()]);
}

if($action==='tutorials'){
    $cfg=tutorials_config(false);$category=safe_id((string)($in['categoryId']??($_GET['categoryId']??'')));$q=clean_text((string)($in['q']??($_GET['q']??'')),100);$featured=(string)($in['featured']??($_GET['featured']??''));
    $rows=array_values(array_filter($cfg['tutorials'],function($t)use($category,$q,$featured){
        if(empty($t['active']))return false;if($category!==''&&($t['categoryId']??'')!==$category)return false;if($featured==='1'&&empty($t['featured']))return false;
        if($q!==''){$hay=(string)($t['title']??'').' '.(string)($t['summary']??'').' '.implode(' ',is_array($t['tags']??null)?$t['tags']:[]);if(function_exists('mb_stripos')){if(mb_stripos($hay,$q,0,'UTF-8')===false)return false;}elseif(stripos($hay,$q)===false)return false;}return true;
    }));
    $sort=(string)($in['sort']??($_GET['sort']??''));if($sort==='popular')usort($rows,fn($a,$b)=>(int)($b['views']??0)<=>(int)($a['views']??0));
    $limit=max(1,min(200,(int)($in['limit']??($_GET['limit']??50))));$offset=max(0,(int)($in['offset']??($_GET['offset']??0)));$total=count($rows);$rows=array_slice($rows,$offset,$limit);
    $rows=array_map(function($t){unset($t['body']);return $t;},$rows);out(['ok'=>true,'tutorials'=>$rows,'total'=>$total,'contentVersion'=>content_version_now()]);
}

if($action==='tutorial'){$id=safe_id((string)($in['id']??($_GET['id']??'')));$t=tutorial_by_id($id,false);if(!$t||empty($t['active']))out(['ok'=>false,'error'=>'آموزش پیدا نشد'],404);out(['ok'=>true,'tutorial'=>$t]);}

if($action==='news'){
    $cfg=app_content(false);$rows=array_values(array_filter($cfg['news'],fn($n)=>!empty($n['active'])));
    usort($rows,fn($a,$b)=>strcmp((string)($b['publishedAt']??''),(string)($a['publishedAt']??''))?:((int)($a['sortOrder']??0)<=>(int)($b['sortOrder']??0)));
    $limit=max(1,min(50,(int)($in['limit']??($_GET['limit']??10))));$offset=max(0,(int)($in['offset']??($_GET['offset']??0)));$total=count($rows);$rows=array_slice($rows,$offset,$limit);$rows=array_map(function($n){unset($n['body']);return $n;},$rows);
    out(['ok'=>true,'news'=>$rows,'total'=>$total,'offset'=>$offset,'limit'=>$limit,'hasMore'=>($offset+count($rows))<$total,'contentVersion'=>content_version_now()]);
}

if($action==='news_detail'){$id=safe_id((string)($in['id']??($_GET['id']??'')));$n=news_by_id($id,false);if(!$n||empty($n['active']))out(['ok'=>false,'error'=>'خبر پیدا نشد'],404);out(['ok'=>true,'news'=>$n]);}

if($action==='view'){$type=(string)($in['type']??'');$id=safe_id((string)($in['id']??''));if(!in_array($type,['tutorial','news'],true)||$id==='')out(['ok'=>false,'error'=>'invalid_view'],422);$views=increment_content_view($type,$id);out(['ok'=>true,'views'=>$views]);}

if($action==='presence'){
    $device=(string)($in['deviceId']??'');$version=(string)($in['version']??'');$event=(string)($in['event']??'heartbeat');
    $r=record_app_presence($device,$version,$event);if(empty($r['ok']))out(['ok'=>false,'error'=>'invalid_device'],422);out($r);
}

out(['ok'=>false,'error'=>'unknown_action'],400);
