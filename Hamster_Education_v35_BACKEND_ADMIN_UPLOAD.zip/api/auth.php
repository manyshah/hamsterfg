<?php
require __DIR__ . '/_lib.php';
$in=json_input();$action=$_GET['action']??($in['action']??'');

function auth_full_response(array $user, string $token, array $extra=[]): void {
    persist_session_cookie($token);
    out(array_merge([
        'ok'=>true,'token'=>$token,'user'=>public_user($user),
        'missions'=>missions_config(false),'cups'=>cups_config(),'boostCosts'=>boost_costs(),'serverTime'=>time()
    ],$extra));
}
function pay_signup_referral_reward(array $user, string $inviteCode): array {
    $inviteCode=clean_referral_code($inviteCode);
    if($inviteCode==='') return $user;
    $inviter=find_user_by_referral_code($inviteCode);
    if(!$inviter)out(['ok'=>false,'error'=>'کد دعوت معتبر نیست'],422);
    if(clean_email((string)$inviter['email'])===clean_email((string)$user['email']))out(['ok'=>false,'error'=>'نمی‌توانی از کد دعوت خودت استفاده کنی'],422);
    $inviter=ensure_referral_code($inviter,false);
    $user['referredByEmail']=clean_email((string)$inviter['email']);
    $user['referredByUserId']=$inviter['userId']??null;
    $user['referralRegisteredAt']=now_iso();
    $user['referralSignupRewardPaid']=true;
    $inviterGame=settle_game(is_array($inviter['game']??null)?$inviter['game']:[]);unset($inviterGame['_passiveEarned']);
    $amount=referral_signup_reward();$inviterGame['coins']+=$amount;$inviterGame['scoreReachedAt']=time();$inviter['game']=normalize_game($inviterGame);
    save_user($inviter);
    append_jsonl(referral_rewards_file((string)$inviter['email']),[
        'id'=>'signup:'.sha1((string)$user['email']),'type'=>'signup','amount'=>$amount,
        'fromEmail'=>$user['email'],'fromUserId'=>$user['userId']??null,
        'fromDisplayName'=>$user['displayName']??$user['username']??'بازیکن','time'=>now_iso()
    ]);
    return $user;
}

if($action==='guest'){
    // First recover the previous server cookie. This prevents a new Ghost account
    // when Android WebView loses localStorage between app launches.
    $existingToken=token_from_header();
    if($existingToken!==''){
        $existing=session_user_from_token($existingToken,true);
        if($existing && empty($existing['suspended'])){
            auth_full_response($existing,$existingToken,[
                'guestCreated'=>false,
                'guestResumed'=>is_guest_user($existing),
                'accountResumed'=>!is_guest_user($existing),
            ]);
        }
    }
    $email=guest_internal_email();$display=guest_display_name();
    $user=[
        'email'=>$email,'username'=>$display,'displayName'=>$display,'isGuest'=>true,
        'userId'=>'HT-'.strtoupper(substr(sha1($email.microtime(true)),0,7)),
        'createdAt'=>now_iso(),'updatedAt'=>now_iso(),'lastSeen'=>time(),'lastLogin'=>time(),
        'suspended'=>false,'game'=>default_game(),'referralRewardedLeagues'=>[]
    ];
    save_user($user);$token=new_token($email);auth_full_response($user,$token,['guestCreated'=>true,'guestResumed'=>false]);
}

if($action==='register'){
    $email=clean_email((string)($in['email']??''));
    $display=clean_display_name((string)($in['displayName']??$in['username']??$in['name']??''));
    $password=(string)($in['password']??'');$confirm=(string)($in['confirmPassword']??'');
    $inviteCode=clean_referral_code((string)($in['inviteCode']??''));
    if(!valid_email($email))out(['ok'=>false,'error'=>'ایمیل معتبر نیست'],422);
    if(!valid_display_name($display))out(['ok'=>false,'error'=>'نام کاربری باید بین ۲ تا ۳۰ کاراکتر باشد'],422);
    if(strlen($password)<8)out(['ok'=>false,'error'=>'رمز عبور باید حداقل ۸ کاراکتر باشد'],422);
    if($password!==$confirm)out(['ok'=>false,'error'=>'رمز عبور و تکرار آن یکسان نیست'],422);
    $created=with_referral_lock(function() use($email,$display,$password,$inviteCode): array {
        if(find_user_by_email($email))out(['ok'=>false,'error'=>'این ایمیل قبلاً ثبت شده است'],409);
        $user=['email'=>$email,'username'=>$display,'displayName'=>$display,'passwordHash'=>password_hash($password,PASSWORD_DEFAULT),'isGuest'=>false,'userId'=>'HT-'.strtoupper(substr(sha1($email.microtime(true)),0,7)),'createdAt'=>now_iso(),'updatedAt'=>now_iso(),'lastSeen'=>time(),'lastLogin'=>time(),'suspended'=>false,'game'=>default_game(),'referralRewardedLeagues'=>[]];
        $user=ensure_referral_code($user,false);$user=pay_signup_referral_reward($user,$inviteCode);save_user($user);return $user;
    });
    if(!empty($created['referredByEmail']))award_pending_referral_leagues((string)$created['referredByEmail']);
    $user=find_user_by_email($email)??$created;$token=new_token($email);auth_full_response($user,$token);
}

if($action==='convert_guest'){
    $guest=auth_user();if(!is_guest_user($guest))out(['ok'=>false,'error'=>'این حساب قبلاً ثبت شده است'],409);
    $email=clean_email((string)($in['email']??''));
    $display=clean_display_name((string)($in['displayName']??$in['username']??$in['name']??''));
    $password=(string)($in['password']??'');$confirm=(string)($in['confirmPassword']??'');
    $inviteCode=clean_referral_code((string)($in['inviteCode']??''));
    if(!valid_email($email))out(['ok'=>false,'error'=>'ایمیل معتبر نیست'],422);
    if(!valid_display_name($display))out(['ok'=>false,'error'=>'نام کاربری باید بین ۲ تا ۳۰ کاراکتر باشد'],422);
    if(strlen($password)<8)out(['ok'=>false,'error'=>'رمز عبور باید حداقل ۸ کاراکتر باشد'],422);
    if($password!==$confirm)out(['ok'=>false,'error'=>'رمز عبور و تکرار آن یکسان نیست'],422);
    $token=token_from_header();$oldEmail=clean_email((string)$guest['email']);
    $converted=with_referral_lock(function() use($guest,$oldEmail,$email,$display,$password,$inviteCode,$token): array {
        if(find_user_by_email($email))out(['ok'=>false,'error'=>'این ایمیل قبلاً ثبت شده است؛ از گزینه ورود استفاده کن'],409);
        $user=$guest;$user['email']=$email;$user['username']=$display;$user['displayName']=$display;
        $user['passwordHash']=password_hash($password,PASSWORD_DEFAULT);$user['isGuest']=false;
        $user['registeredAt']=now_iso();$user['lastLogin']=time();unset($user['guestCreatedAt']);
        $user=ensure_referral_code($user,false);$user=pay_signup_referral_reward($user,$inviteCode);
        save_user($user);update_token_email($token,$email);@unlink(user_file($oldEmail));
        return $user;
    });
    if(!empty($converted['referredByEmail']))award_pending_referral_leagues((string)$converted['referredByEmail']);
    auth_full_response(find_user_by_email($email)??$converted,$token,['converted'=>true]);
}

if($action==='login_guest'){
    $guest=auth_user();if(!is_guest_user($guest))out(['ok'=>false,'error'=>'ابتدا از حساب فعلی خارج شو'],409);
    $email=clean_email((string)($in['email']??''));$password=(string)($in['password']??'');$account=find_user_by_email($email);
    if(!$account||is_guest_user($account)||!password_verify($password,(string)($account['passwordHash']??'')))out(['ok'=>false,'error'=>'ایمیل یا رمز عبور اشتباه است'],401);
    if(!empty($account['suspended']))out(['ok'=>false,'error'=>'این حساب توسط مدیریت غیرفعال شده است'],403);
    $token=token_from_header();$account=save_settled_user($account);$earned=(float)($account['_passiveEarned']??0);unset($account['_passiveEarned']);
    $account['lastLogin']=time();save_user($account);update_token_email($token,$email);delete_guest_user($guest);
    auth_full_response($account,$token,['guestProgressDiscarded'=>true,'passiveEarned'=>$earned]);
}

if($action==='login'){
    $email=clean_email((string)($in['email']??''));$password=(string)($in['password']??'');$user=find_user_by_email($email);
    if(!$user||is_guest_user($user)||!password_verify($password,(string)($user['passwordHash']??'')))out(['ok'=>false,'error'=>'ایمیل یا رمز عبور اشتباه است'],401);
    if(!empty($user['suspended']))out(['ok'=>false,'error'=>'این حساب توسط مدیریت غیرفعال شده است'],403);
    $user=save_settled_user($user);$earned=(float)($user['_passiveEarned']??0);unset($user['_passiveEarned']);$user['lastLogin']=time();save_user($user);$token=new_token($email);auth_full_response($user,$token,['passiveEarned'=>$earned]);
}
if($action==='profile_update'){
    $user=auth_user();
    $display=clean_display_name((string)($in['displayName']??$in['username']??$in['name']??($user['displayName']??'')));
    if(!valid_display_name($display))out(['ok'=>false,'error'=>'نام کاربری باید بین ۲ تا ۳۰ کاراکتر باشد'],422);
    $user['username']=$display;$user['displayName']=$display;save_user($user);
    out(['ok'=>true,'user'=>public_user($user)]);
}
if($action==='logout'){$token=token_from_header();if($token!=='')@unlink(token_file($token));clear_session_cookie();out(['ok'=>true]);}
if($action==='forgot'){
    $email=clean_email((string)($in['email']??''));if(!valid_email($email))out(['ok'=>false,'error'=>'ایمیل معتبر نیست'],422);$user=find_user_by_email($email);
    if($user&&!is_guest_user($user)){$code=(string)random_int(100000,999999);$user['resetCodeHash']=password_hash($code,PASSWORD_DEFAULT);$user['resetExpiresAt']=time()+600;save_user($user);
        $subject='Hamster Talaei password reset';$message="کد بازیابی رمز عبور شما: {$code}\nاعتبار: ۱۰ دقیقه";$headers='Content-Type: text/plain; charset=UTF-8';$sent=@mail($email,$subject,$message,$headers);
        if(!$sent){@file_put_contents(DATA_DIR.'/mail_fallback.log',now_iso().' '.$email.' '.$code.PHP_EOL,FILE_APPEND|LOCK_EX);}
    }
    out(['ok'=>true,'message'=>'اگر ایمیل ثبت شده باشد، کد بازیابی ارسال می‌شود.']);
}
if($action==='reset'){
    $email=clean_email((string)($in['email']??''));$code=trim((string)($in['code']??''));$password=(string)($in['password']??'');$confirm=(string)($in['confirmPassword']??'');
    if(!valid_email($email)||!preg_match('/^\d{6}$/',$code))out(['ok'=>false,'error'=>'اطلاعات بازیابی معتبر نیست'],422);
    if(strlen($password)<8||$password!==$confirm)out(['ok'=>false,'error'=>'رمز جدید معتبر نیست یا با تکرار آن یکسان نیست'],422);
    $user=find_user_by_email($email);if(!$user||is_guest_user($user)||!isset($user['resetCodeHash'],$user['resetExpiresAt'])||(int)$user['resetExpiresAt']<time()||!password_verify($code,(string)$user['resetCodeHash']))out(['ok'=>false,'error'=>'کد بازیابی اشتباه یا منقضی شده است'],422);
    $user['passwordHash']=password_hash($password,PASSWORD_DEFAULT);unset($user['resetCodeHash'],$user['resetExpiresAt']);save_user($user);out(['ok'=>true,'message'=>'رمز عبور با موفقیت تغییر کرد.']);
}
out(['ok'=>false,'error'=>'unknown_action'],400);
