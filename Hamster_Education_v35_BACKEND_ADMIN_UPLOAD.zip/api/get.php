<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

echo json_encode(
    [
        // تبلیغ آنی هر ۲ دقیقه: 120000 میلی‌ثانیه
        'interstitial_reload_time' => '160000',

        // تازه‌سازی بنر هر ۳۰ ثانیه: 30000 میلی‌ثانیه
        'banner_reload_time' => '30000',

        // انتخاب شبکه تبلیغاتی فعلی
        'rand_number' => '1',

        'status' => 'ok',
    ],
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
);
