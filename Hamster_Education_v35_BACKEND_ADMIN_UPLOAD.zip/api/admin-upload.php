<?php
define('API_NO_DEFAULT_HEADERS', true);
require __DIR__ . '/_lib.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
require_admin(true);
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') out(['ok'=>false,'error'=>'method_not_allowed'],405);
if (!isset($_FILES['image']) || !is_array($_FILES['image'])) out(['ok'=>false,'error'=>'فایل تصویر ارسال نشده است'],422);
$file=$_FILES['image'];
$error=(int)($file['error']??UPLOAD_ERR_NO_FILE);
$messages=[
    UPLOAD_ERR_INI_SIZE=>'حجم تصویر از محدودیت تنظیمات هاست بیشتر است',
    UPLOAD_ERR_FORM_SIZE=>'حجم تصویر بیش از حد مجاز است',
    UPLOAD_ERR_PARTIAL=>'فایل به‌صورت ناقص آپلود شد',
    UPLOAD_ERR_NO_FILE=>'فایل تصویر انتخاب نشده است',
    UPLOAD_ERR_NO_TMP_DIR=>'پوشه موقت PHP روی هاست وجود ندارد',
    UPLOAD_ERR_CANT_WRITE=>'هاست اجازه نوشتن فایل را نداد',
    UPLOAD_ERR_EXTENSION=>'یک افزونه PHP آپلود را متوقف کرد',
];
if($error!==UPLOAD_ERR_OK)out(['ok'=>false,'error'=>$messages[$error]??('خطای آپلود با کد '.$error)],422);
$size=(int)($file['size']??0);
if($size<=0||$size>5*1024*1024)out(['ok'=>false,'error'=>'حجم تصویر باید کمتر از ۵ مگابایت باشد'],422);
$tmp=(string)($file['tmp_name']??'');
if($tmp===''||!is_file($tmp))out(['ok'=>false,'error'=>'فایل موقت تصویر پیدا نشد'],422);
$info=@getimagesize($tmp);if(!$info)out(['ok'=>false,'error'=>'فایل انتخاب‌شده تصویر معتبر نیست'],422);
$mime='';
if(class_exists('finfo')){$fi=new finfo(FILEINFO_MIME_TYPE);$mime=(string)($fi->file($tmp)?:'');}
if($mime==='')$mime=(string)($info['mime']??'');
$allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
if(!isset($allowed[$mime]))out(['ok'=>false,'error'=>'فقط JPG، PNG و WebP مجاز است'],422);
if(($info[0]??0)>5000||($info[1]??0)>5000)out(['ok'=>false,'error'=>'ابعاد تصویر نباید بیشتر از ۵۰۰۰ پیکسل باشد'],422);
ensure_storage();
if(!is_dir(UPLOAD_DIR)&&!@mkdir(UPLOAD_DIR,0775,true))out(['ok'=>false,'error'=>'پوشه ذخیره تصاویر ساخته نشد'],500);
if(!is_writable(UPLOAD_DIR))@chmod(UPLOAD_DIR,0775);
if(!is_writable(UPLOAD_DIR))out(['ok'=>false,'error'=>'پوشه uploads/missions دسترسی نوشتن ندارد؛ سطح دسترسی را 0755 یا 0775 تنظیم کن'],500);
$name='mission_'.date('Ymd_His').'_'.bin2hex(random_bytes(6)).'.'.$allowed[$mime];$dest=UPLOAD_DIR.'/'.$name;
$ok=@move_uploaded_file($tmp,$dest);
if(!$ok&&is_uploaded_file($tmp))$ok=@copy($tmp,$dest);
if(!$ok)out(['ok'=>false,'error'=>'انتقال تصویر به پوشه uploads/missions انجام نشد'],500);
@chmod($dest,0644);
if(!is_file($dest)||filesize($dest)<=0){@unlink($dest);out(['ok'=>false,'error'=>'فایل تصویر پس از ذخیره معتبر نبود'],500);}
append_audit('mission_image_upload',['file'=>$name,'size'=>$size,'mime'=>$mime]);
out(['ok'=>true,'path'=>'uploads/missions/'.$name,'url'=>'../uploads/missions/'.$name]);
