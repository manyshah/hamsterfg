<?php
require __DIR__ . '/_lib.php';
$in=json_input();$action=$_GET['action']??($in['action']??'get');$user=auth_user();
$user=save_settled_user($user);$passive=(float)($user['_passiveEarned']??0);unset($user['_passiveEarned']);$game=normalize_game($user['game']??[]);

function game_response(array $user,float $passive=0,array $extra=[]): void {
    out(array_merge(['ok'=>true,'user'=>public_user($user),'missions'=>missions_config(false),'cups'=>cups_config(),'boostCosts'=>boost_costs(),'serverTime'=>time(),'passiveEarned'=>$passive],$extra));
}
if($action==='get'||$action==='heartbeat'){game_response($user,$passive);}
if($action==='tap'){
    $count=max(1,min(25,(int)($in['count']??1)));
    $power=max(1,(int)$game['power']);if(time()<(int)$game['turboUntil'])$power*=2;
    $valid=min($count,(int)floor((float)$game['energy']/$power));
    if($valid<=0)game_response($user,$passive,['applied'=>0,'gain'=>0,'message'=>'energy_insufficient','requiredEnergy'=>$power]);
    $energyCost=$valid*$power;
    $game['coins']+=(float)($valid*$power);$game['scoreReachedAt']=time();$game['energy']-=$energyCost;$game['taps']+=$valid;$game['lastEnergyAt']=time();$game['league']=cup_for_coins((float)$game['coins'])['name'];$user['game']=$game;$user=save_user_with_referral_awards($user);game_response($user,$passive,['applied'=>$valid,'gain'=>$valid*$power,'energyCost'=>$energyCost,'energyPerTap'=>$power]);
}
if($action==='boost_upgrade'){
    $type=(string)($in['type']??'');$map=['power'=>'tapLevel','energy'=>'energyLevel','recharge'=>'rechargeLevel'];if(!isset($map[$type]))out(['ok'=>false,'error'=>'بوست نامعتبر است'],422);
    $key=$map[$type];$level=(int)$game[$key];if($level>=20)out(['ok'=>false,'error'=>'این بوست به حداکثر سطح رسیده است'],422);
    $costs=boost_costs();$cost=(float)$costs[$level-1];if((float)$game['coins']<$cost)out(['ok'=>false,'error'=>'سکه کافی نیست','required'=>$cost,'shortage'=>$cost-(float)$game['coins']],409);
    $game['coins']-=$cost;$game['scoreReachedAt']=time();$game[$key]=$level+1;$game=normalize_game($game);if($type==='energy')$game['energy']=$game['maxEnergy'];$user['game']=$game;$user=save_user_with_referral_awards($user);game_response($user,$passive,['upgraded'=>$type,'cost'=>$cost]);
}
if($action==='quick_boost'){
    $type=(string)($in['type']??'');if(!in_array($type,['energy','turbo'],true))out(['ok'=>false,'error'=>'بوست سریع نامعتبر است'],422);
    $usedKey=$type==='energy'?'instantEnergyUsed':'turboUsed';if((int)$game[$usedKey]>=3)out(['ok'=>false,'error'=>'سهمیه امروز تمام شده است'],409);
    if($type==='energy'){$game['energy']=$game['maxEnergy'];}else{$game['turboUntil']=time()+30;}$game[$usedKey]++;$user['game']=$game;$user=save_user_with_referral_awards($user);game_response($user,$passive,['quickBoost'=>$type]);
}
if($action==='mission_upgrade'){
    $id=safe_id((string)($in['missionId']??''));$mission=mission_by_id($id,true);if(!$mission||!empty($mission['deleted'])||empty($mission['active']))out(['ok'=>false,'error'=>'این مأموریت در دسترس نیست'],404);
    $current=(int)($game['missionLevels'][$id]??0);$levels=is_array($mission['levels']??null)?$mission['levels']:[];$target=$current+1;if($target<1||$target>count($levels))out(['ok'=>false,'error'=>'این مأموریت به حداکثر سطح رسیده است'],422);
    $row=$levels[$target-1];$cost=max(0,(float)($row['upgradeCost']??0));if((float)$game['coins']<$cost)out(['ok'=>false,'error'=>'سکه کافی نیست','required'=>$cost,'shortage'=>$cost-(float)$game['coins']],409);
    $game['coins']-=$cost;$game['scoreReachedAt']=time();$game['missionLevels'][$id]=$target;$game['hourlyIncome']=calculate_hourly_income($game);$game['league']=cup_for_coins((float)$game['coins'])['name'];$user['game']=$game;$user=save_user_with_referral_awards($user);game_response($user,$passive,['missionUpgraded'=>$id,'cost'=>$cost]);
}
if($action==='referral'){
    out(['ok'=>true,'referral'=>referral_summary($user),'user'=>public_user($user)]);
}
if($action==='leaderboard'){
    $cupName=preg_replace('/[^A-Za-z]/','',(string)($in['cup']??'Bronze'))?:'Bronze';$rows=[];
    foreach(all_users() as $u){if(!empty($u['suspended']))continue;$g=settle_game(is_array($u['game']??null)?$u['game']:[]);$coins=(float)$g['coins'];$cup=cup_for_coins($coins);if($cup['name']!==$cupName)continue;$p=public_user($u);$fallback=isset($u['createdAt'])?(strtotime((string)$u['createdAt'])?:PHP_INT_MAX):PHP_INT_MAX;$reached=(int)($g['scoreReachedAt']??0);if($reached<=0)$reached=$fallback;$rows[]=['userId'=>$p['userId'],'username'=>$p['username'],'displayName'=>$p['displayName'],'coins'=>$coins,'cup'=>$cup['name'],'scoreReachedAt'=>$reached,'isMe'=>clean_email((string)($u['email']??''))===clean_email((string)$user['email'])];}
    usort($rows,fn($a,$b)=>($b['coins']<=>$a['coins'])?:($a['scoreReachedAt']<=>$b['scoreReachedAt'])?:strcmp((string)$a['userId'],(string)$b['userId']));$rank=null;$currentUser=null;foreach($rows as $i=>&$r){$r['rank']=$i+1;if($r['isMe']){$rank=$r['rank'];$currentUser=$r;unset($currentUser['scoreReachedAt']);}unset($r['scoreReachedAt']);}unset($r);
    out(['ok'=>true,'cup'=>$cupName,'leaders'=>array_slice($rows,0,50),'currentRank'=>$rank,'currentUser'=>$currentUser,'totalInLeague'=>count($rows)]);
}

out(['ok'=>false,'error'=>'unknown_action'],400);
