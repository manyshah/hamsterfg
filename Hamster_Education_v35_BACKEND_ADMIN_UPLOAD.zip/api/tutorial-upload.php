<?php
require __DIR__ . '/_lib.php';
start_admin_session();require_admin(true);
if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST')out(['ok'=>false,'error'=>'method_not_allowed'],405);
if(empty($_FILES['image'])||!is_uploaded_file($_FILES['image']['tmp_name']))out(['ok'=>false,'error'=>'فایل تصویر ارسال نشده است'],422);
$f=$_FILES['image'];if(($f['error']??UPLOAD_ERR_OK)!==UPLOAD_ERR_OK)out(['ok'=>false,'error'=>'آپلود تصویر ناموفق بود'],422);if((int)($f['size']??0)>6*1024*1024)out(['ok'=>false,'error'=>'حجم تصویر باید کمتر از ۶ مگابایت باشد'],422);
$fi=new finfo(FILEINFO_MIME_TYPE);$mime=$fi->file($f['tmp_name']);$ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime]??'';if($ext==='')out(['ok'=>false,'error'=>'فقط JPG، PNG و WebP مجاز است'],422);
$name='tutorial-'.date('Ymd-His').'-'.bin2hex(random_bytes(4)).'.'.$ext;$dest=tutorial_upload_dir().'/'.$name;if(!@move_uploaded_file($f['tmp_name'],$dest))out(['ok'=>false,'error'=>'ذخیره تصویر ناموفق بود'],500);@chmod($dest,0644);append_audit('tutorial_image_upload',['file'=>$name]);out(['ok'=>true,'path'=>'uploads/tutorials/'.$name]);
